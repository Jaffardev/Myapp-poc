namespace BlazorClient.Models;

public class CardBalance
{
    public string   CardNumber       { get; set; } = string.Empty;
    public string   MaskedNumber     { get; set; } = string.Empty;
    public decimal  AvailableBalance { get; set; }
    public decimal  CurrentBalance   { get; set; }
    public decimal  CreditLimit      { get; set; }
    public string   Currency         { get; set; } = "USD";
    public DateTime LastUpdated      { get; set; }
    public bool     IsFromCache      { get; set; }
}

public class MultiCardBalanceRequest
{
    public List<string> CardNumbers  { get; set; } = new();
    public bool         ForceRefresh { get; set; } = false;
}

public class CustomerCardBalances
{
    public string            CustomerId { get; set; } = string.Empty;
    public List<CardBalance> Balances   { get; set; } = new();
}
