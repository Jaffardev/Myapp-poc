namespace BlazorClient.Models;

public class CardBalance
{
    public string  CardNumber        { get; set; } = string.Empty;
    public string  MaskedNumber      { get; set; } = string.Empty;
    public decimal AvailableBalance  { get; set; }
    public decimal CurrentBalance    { get; set; }
    public decimal CreditLimit       { get; set; }
    public string  Currency          { get; set; } = "USD";
    public DateTime LastUpdated      { get; set; }
    public bool    IsFromCache       { get; set; }
}
