using BlazorClient.Services;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// ── Named HttpClient pointing at your Internal API ───────────────
builder.Services.AddHttpClient("InternalApi", client =>
{
    client.BaseAddress = new Uri(
        builder.Configuration["ApiBaseUrl"] ?? "https://localhost:5001/");

    client.Timeout = TimeSpan.FromSeconds(30);

    // Add auth header for agent authentication
    // client.DefaultRequestHeaders.Authorization =
    //     new AuthenticationHeaderValue("Bearer", token);
});

// ── Register balance service ─────────────────────────────────────
builder.Services.AddScoped<ICardBalanceClientService, CardBalanceClientService>();

await builder.Build().RunAsync();
