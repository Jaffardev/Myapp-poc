using System.Net.Http.Json;
using BlazorClient.Models;

namespace BlazorClient.Services;

public interface ICardBalanceClientService
{
    Task<CardBalance?> GetBalanceAsync(string cardNumber, bool forceRefresh = false);
    Task<List<CardBalance>> GetAllBalancesAsync(List<string> cardNumbers, bool forceRefresh = false);
    Task<List<CardBalance>> GetCustomerBalancesAsync(string customerId, bool forceRefresh = false);
}

public class CardBalanceClientService : ICardBalanceClientService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<CardBalanceClientService> _logger;

    public CardBalanceClientService(
        IHttpClientFactory httpClientFactory,
        ILogger<CardBalanceClientService> logger)
    {
        // Named client configured in Program.cs
        _httpClient = httpClientFactory.CreateClient("InternalApi");
        _logger     = logger;
    }

    // ── Single card ──────────────────────────────────────────────
    public async Task<CardBalance?> GetBalanceAsync(
        string cardNumber,
        bool forceRefresh = false)
    {
        try
        {
            var url = $"api/cardbalance/{cardNumber}?forceRefresh={forceRefresh}";
            var response = await _httpClient.GetAsync(url);

            if (response.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
            {
                _logger.LogWarning("Balance service unavailable for card");
                return null;
            }

            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<CardBalance>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get balance");
            return null;
        }
    }

    // ── Multiple cards (bulk) ────────────────────────────────────
    public async Task<List<CardBalance>> GetAllBalancesAsync(
        List<string> cardNumbers,
        bool forceRefresh = false)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync(
                "api/cardbalance/bulk",
                new { CardNumbers = cardNumbers, ForceRefresh = forceRefresh });

            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<CardBalance>>()
                   ?? new List<CardBalance>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get bulk balances");
            return new List<CardBalance>();
        }
    }

    // ── All cards for a customer ─────────────────────────────────
    public async Task<List<CardBalance>> GetCustomerBalancesAsync(
        string customerId,
        bool forceRefresh = false)
    {
        try
        {
            var url = $"api/cardbalance/customer/{customerId}?forceRefresh={forceRefresh}";
            var result = await _httpClient.GetFromJsonAsync<CustomerCardBalances>(url);
            return result?.Balances ?? new List<CardBalance>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get customer balances");
            return new List<CardBalance>();
        }
    }
}

public class CustomerCardBalances
{
    public string CustomerId         { get; set; } = string.Empty;
    public List<CardBalance> Balances { get; set; } = new();
}
