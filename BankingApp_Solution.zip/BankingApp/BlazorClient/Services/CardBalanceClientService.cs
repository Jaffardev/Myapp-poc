using System.Net.Http.Json;
using BlazorClient.Models;

namespace BlazorClient.Services;

public interface ICardBalanceClientService
{
    Task<CardBalance?> GetBalanceAsync(string cardNumber, bool forceRefresh = false);
    Task<List<CardBalance>> GetAllBalancesAsync(List<string> cardNumbers, bool forceRefresh = false);
    Task<List<CardBalance>> GetCustomerBalancesAsync(string customerId, bool forceRefresh = false);
}

public class CardBalanceClientService : ICardBalanceClientService
{
    private readonly HttpClient _http;
    private readonly ILogger<CardBalanceClientService> _logger;

    public CardBalanceClientService(
        IHttpClientFactory factory,
        ILogger<CardBalanceClientService> logger)
    {
        _http   = factory.CreateClient("InternalApi");
        _logger = logger;
    }

    public async Task<CardBalance?> GetBalanceAsync(
        string cardNumber, bool forceRefresh = false)
    {
        try
        {
            var response = await _http.GetAsync(
                $"api/cardbalance/{cardNumber}?forceRefresh={forceRefresh}");

            if (response.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
            {
                _logger.LogWarning("Balance service unavailable (circuit open)");
                return null;
            }

            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<CardBalance>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get balance for card");
            return null;
        }
    }

    public async Task<List<CardBalance>> GetAllBalancesAsync(
        List<string> cardNumbers, bool forceRefresh = false)
    {
        try
        {
            var response = await _http.PostAsJsonAsync(
                "api/cardbalance/bulk",
                new MultiCardBalanceRequest
                {
                    CardNumbers  = cardNumbers,
                    ForceRefresh = forceRefresh
                });

            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<CardBalance>>()
                   ?? new List<CardBalance>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get bulk balances");
            return new List<CardBalance>();
        }
    }

    public async Task<List<CardBalance>> GetCustomerBalancesAsync(
        string customerId, bool forceRefresh = false)
    {
        try
        {
            var result = await _http.GetFromJsonAsync<CustomerCardBalances>(
                $"api/cardbalance/customer/{customerId}?forceRefresh={forceRefresh}");
            return result?.Balances ?? new List<CardBalance>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get customer balances");
            return new List<CardBalance>();
        }
    }
}
