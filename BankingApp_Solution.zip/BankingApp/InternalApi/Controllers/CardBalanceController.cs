using InternalApi.Infrastructure;
using InternalApi.Models;
using InternalApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Polly.CircuitBreaker;

namespace InternalApi.Controllers;

// ═══════════════════════════════════════════════════════════════
//  CARD BALANCE CONTROLLER
// ═══════════════════════════════════════════════════════════════
[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("soap-limiter")]
public class CardBalanceController : ControllerBase
{
    private readonly ICardBalanceService _balanceService;
    private readonly ILogger<CardBalanceController> _logger;

    public CardBalanceController(
        ICardBalanceService balanceService,
        ILogger<CardBalanceController> logger)
    {
        _balanceService = balanceService;
        _logger         = logger;
    }

    // GET /api/cardbalance/{cardNumber}?forceRefresh=false
    [HttpGet("{cardNumber}")]
    public async Task<ActionResult<CardBalance>> GetBalance(
        string cardNumber,
        [FromQuery] bool forceRefresh = false)
    {
        if (string.IsNullOrWhiteSpace(cardNumber))
            return BadRequest("Card number is required.");

        try
        {
            var balance = await _balanceService.GetBalanceAsync(cardNumber, forceRefresh);
            return Ok(balance);
        }
        catch (BrokenCircuitException)
        {
            return StatusCode(503, new
            {
                Error   = "Balance service temporarily unavailable.",
                Message = "External system is currently unreachable. Please retry shortly."
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching balance");
            return StatusCode(500, new { Error = "Unable to retrieve balance." });
        }
    }

    // POST /api/cardbalance/bulk
    [HttpPost("bulk")]
    public async Task<ActionResult<List<CardBalance>>> GetBulkBalances(
        [FromBody] MultiCardBalanceRequest request)
    {
        if (request.CardNumbers == null || !request.CardNumbers.Any())
            return BadRequest("At least one card number is required.");

        if (request.CardNumbers.Count > 20)
            return BadRequest("Maximum 20 cards per request.");

        try
        {
            var balances = await _balanceService.GetAllBalancesAsync(
                request.CardNumbers, request.ForceRefresh);
            return Ok(balances);
        }
        catch (BrokenCircuitException)
        {
            return StatusCode(503, new { Error = "Balance service temporarily unavailable." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching bulk balances");
            return StatusCode(500, new { Error = "Unable to retrieve balances." });
        }
    }

    // GET /api/cardbalance/customer/{customerId}
    [HttpGet("customer/{customerId}")]
    public async Task<ActionResult<CustomerCardBalances>> GetCustomerBalances(
        string customerId,
        [FromQuery] bool forceRefresh = false)
    {
        // TODO: Replace with EF repository call
        // var cards    = await _cardRepository.GetCardsByCustomerAsync(customerId);
        // var balances = await _balanceService.GetAllBalancesAsync(
        //     cards.Select(c => c.CardNumber).ToList(), forceRefresh);

        return Ok(new CustomerCardBalances
        {
            CustomerId = customerId,
            Balances   = new List<CardBalance>()
        });
    }
}

// ═══════════════════════════════════════════════════════════════
//  DIAGNOSTICS CONTROLLER
//  Use this to verify Singleton is working correctly
//  GET /api/diagnostics/soap-info
// ═══════════════════════════════════════════════════════════════
[ApiController]
[Route("api/[controller]")]
public class DiagnosticsController : ControllerBase
{
    [HttpGet("soap-info")]
    public IActionResult GetSoapInfo()
    {
        // InstanceCount should always be 1 in production
        // If it keeps growing → your DI registration is wrong
        return Ok(new
        {
            SoapClientInstancesCreated = CardSoapClient.InstanceCount,
            TotalSoapCallsMade         = CardSoapClient.TotalCalls,
            ExpectedInstanceCount      = 1,
            IsCorrect                  = CardSoapClient.InstanceCount == 1,
            Message                    = CardSoapClient.InstanceCount == 1
                ? "✅ Singleton working correctly — one instance serving all requests"
                : $"❌ Problem detected — {CardSoapClient.InstanceCount} instances created",
            Timestamp                  = DateTime.UtcNow
        });
    }
}
