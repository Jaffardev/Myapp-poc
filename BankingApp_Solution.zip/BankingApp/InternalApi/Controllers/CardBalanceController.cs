using InternalApi.Models;
using InternalApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace InternalApi.Controllers;

[ApiController]
[Route("api/[controller]")]
// Apply concurrency limiter — max 50 simultaneous SOAP calls
[EnableRateLimiting("soap-limiter")]
public class CardBalanceController : ControllerBase
{
    private readonly ICardBalanceService _balanceService;
    private readonly ILogger<CardBalanceController> _logger;

    public CardBalanceController(
        ICardBalanceService balanceService,
        ILogger<CardBalanceController> logger)
    {
        _balanceService = balanceService;
        _logger = logger;
    }

    // ── GET single card balance ────────────────────────────────────
    // GET /api/cardbalance/{cardNumber}?forceRefresh=false
    [HttpGet("{cardNumber}")]
    public async Task<ActionResult<CardBalance>> GetBalance(
        string cardNumber,
        [FromQuery] bool forceRefresh = false)
    {
        if (string.IsNullOrWhiteSpace(cardNumber))
            return BadRequest("Card number is required");

        try
        {
            var balance = await _balanceService.GetBalanceAsync(cardNumber, forceRefresh);
            return Ok(balance);
        }
        catch (Polly.CircuitBreaker.BrokenCircuitException)
        {
            // Circuit is open — Java API is down
            return StatusCode(503, new
            {
                Error   = "Balance service temporarily unavailable",
                Message = "External system is currently unreachable. Please try again shortly."
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching balance for card");
            return StatusCode(500, new { Error = "Unable to retrieve balance" });
        }
    }

    // ── POST multiple card balances (for multi-card customers) ─────
    // POST /api/cardbalance/bulk
    [HttpPost("bulk")]
    public async Task<ActionResult<List<CardBalance>>> GetBulkBalances(
        [FromBody] MultiCardBalanceRequest request)
    {
        if (request.CardNumbers == null || !request.CardNumbers.Any())
            return BadRequest("At least one card number is required");

        if (request.CardNumbers.Count > 20)
            return BadRequest("Maximum 20 cards per request");

        try
        {
            var balances = await _balanceService.GetAllBalancesAsync(
                request.CardNumbers,
                request.ForceRefresh);

            return Ok(balances);
        }
        catch (Polly.CircuitBreaker.BrokenCircuitException)
        {
            return StatusCode(503, new
            {
                Error = "Balance service temporarily unavailable"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching bulk balances");
            return StatusCode(500, new { Error = "Unable to retrieve balances" });
        }
    }

    // ── GET customer with all card balances ────────────────────────
    // GET /api/cardbalance/customer/{customerId}
    [HttpGet("customer/{customerId}")]
    public async Task<ActionResult<CustomerCardBalances>> GetCustomerBalances(
        string customerId,
        [FromQuery] bool forceRefresh = false)
    {
        // 1. Get customer's cards from your database (Entity Framework)
        // var cards = await _cardRepository.GetCardsByCustomerAsync(customerId);

        // 2. Fetch balances in parallel
        // var balances = await _balanceService.GetAllBalancesAsync(
        //     cards.Select(c => c.CardNumber).ToList(), forceRefresh);

        // Placeholder response for wiring
        return Ok(new CustomerCardBalances
        {
            CustomerId = customerId,
            Balances   = new List<CardBalance>()
        });
    }
}

public class CustomerCardBalances
{
    public string CustomerId       { get; set; } = string.Empty;
    public List<CardBalance> Balances { get; set; } = new();
}
