using System.ServiceModel;
using InternalApi.Models;

namespace InternalApi.Infrastructure;

public interface ICardSoapClient
{
    Task<CardBalance> GetCardBalanceAsync(string cardNumber);
    Task<List<CardBalance>> GetMultipleBalancesAsync(List<string> cardNumbers);
}

public class CardSoapClient : ICardSoapClient, IDisposable
{
    // ── Static counters — for diagnostics & validation ────────────
    private static int  _instanceCount = 0;
    private static long _totalCalls    = 0;

    public static int  InstanceCount => _instanceCount;
    public static long TotalCalls    => Interlocked.Read(ref _totalCalls);

    private readonly int _instanceId;
    private readonly ChannelFactory<IExternalCardService> _channelFactory;
    private readonly ILogger<CardSoapClient> _logger;

    public CardSoapClient(IConfiguration config, ILogger<CardSoapClient> logger)
    {
        _logger     = logger;
        _instanceId = Interlocked.Increment(ref _instanceCount);

        // ── Log every time a new instance is created ──────────────
        // In Singleton mode you should see this ONCE at startup only
        _logger.LogWarning(
            ">>> CardSoapClient INSTANCE #{Id} CREATED (Total instances: {Count})",
            _instanceId, _instanceCount);

        var binding = new BasicHttpBinding
        {
            MaxReceivedMessageSize = 5_000_000,
            MaxBufferSize          = 5_000_000,
            SendTimeout            = TimeSpan.FromSeconds(15),
            ReceiveTimeout         = TimeSpan.FromSeconds(15),
            OpenTimeout            = TimeSpan.FromSeconds(10),
            CloseTimeout           = TimeSpan.FromSeconds(10),
            UseDefaultWebProxy     = false,
            Security               = new BasicHttpSecurity
            {
                Mode = BasicHttpSecurityMode.Transport
            }
        };

        var url = config["SoapApi:BaseUrl"]
            ?? "https://java-soap-api.yourbank.com/CardBalanceService";

        var endpoint    = new EndpointAddress(url);
        _channelFactory = new ChannelFactory<IExternalCardService>(binding, endpoint);

        if (!string.IsNullOrEmpty(config["SoapApi:Username"]))
        {
            _channelFactory.Credentials.UserName.UserName = config["SoapApi:Username"];
            _channelFactory.Credentials.UserName.Password = config["SoapApi:Password"];
        }
    }

    public async Task<CardBalance> GetCardBalanceAsync(string cardNumber)
    {
        Interlocked.Increment(ref _totalCalls);

        _logger.LogDebug(
            "SOAP call #{Calls} via Instance #{Id} for card {Card}",
            TotalCalls, _instanceId, MaskCard(cardNumber));

        var channel = _channelFactory.CreateChannel();
        try
        {
            // ── Replace with your actual generated SOAP method ────
            var response = await channel.GetBalanceAsync(
                new GetBalanceRequest { CardNumber = cardNumber });

            return new CardBalance
            {
                CardNumber       = cardNumber,
                MaskedNumber     = MaskCard(cardNumber),
                AvailableBalance = response.AvailableBalance,
                CurrentBalance   = response.CurrentBalance,
                CreditLimit      = response.CreditLimit,
                Currency         = response.Currency ?? "USD",
                LastUpdated      = DateTime.UtcNow,
                IsFromCache      = false
            };
        }
        finally
        {
            if (channel is IClientChannel ch)
            {
                try   { ch.Close(); }
                catch { ch.Abort(); }
            }
        }
    }

    public async Task<List<CardBalance>> GetMultipleBalancesAsync(List<string> cardNumbers)
    {
        var tasks   = cardNumbers.Select(c => GetCardBalanceAsync(c));
        var results = await Task.WhenAll(tasks);
        return results.ToList();
    }

    private static string MaskCard(string card) =>
        card.Length >= 4 ? $"**** **** **** {card[^4..]}" : "****";

    public void Dispose()
    {
        try   { _channelFactory.Close(); }
        catch { _channelFactory.Abort(); }
    }
}

// ── Replace with your svcutil-generated service contract ──────────
[ServiceContract]
public interface IExternalCardService
{
    [OperationContract]
    Task<GetBalanceResponse> GetBalanceAsync(GetBalanceRequest request);
}

public class GetBalanceRequest
{
    public string CardNumber { get; set; } = string.Empty;
}

public class GetBalanceResponse
{
    public decimal AvailableBalance { get; set; }
    public decimal CurrentBalance   { get; set; }
    public decimal CreditLimit      { get; set; }
    public string? Currency         { get; set; }
}
