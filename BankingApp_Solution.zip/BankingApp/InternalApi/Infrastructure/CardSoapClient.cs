using System.ServiceModel;
using System.ServiceModel.Channels;
using InternalApi.Models;

namespace InternalApi.Infrastructure;

// ─────────────────────────────────────────────────────────────────
// This wraps your Java SOAP API.
// Replace the method bodies with your actual generated SOAP client
// calls (via dotnet-svcutil or Add Service Reference).
// ─────────────────────────────────────────────────────────────────

public interface ICardSoapClient
{
    Task<CardBalance> GetCardBalanceAsync(string cardNumber);
    Task<List<CardBalance>> GetMultipleBalancesAsync(List<string> cardNumbers);
}

public class CardSoapClient : ICardSoapClient, IDisposable
{
    private readonly BasicHttpBinding _binding;
    private readonly EndpointAddress  _endpoint;
    private readonly ILogger<CardSoapClient> _logger;

    // Re-use a single ChannelFactory — very important for performance
    private readonly ChannelFactory<IExternalCardService> _channelFactory;

    public CardSoapClient(IConfiguration config, ILogger<CardSoapClient> logger)
    {
        _logger = logger;

        _binding = new BasicHttpBinding
        {
            // ── Timeouts ──────────────────────────────────────────
            SendTimeout    = TimeSpan.FromSeconds(15),
            ReceiveTimeout = TimeSpan.FromSeconds(15),
            OpenTimeout    = TimeSpan.FromSeconds(10),
            CloseTimeout   = TimeSpan.FromSeconds(10),

            // ── Message size ──────────────────────────────────────
            MaxReceivedMessageSize = 5_000_000,
            MaxBufferSize          = 5_000_000,

            // ── Performance tweaks ────────────────────────────────
            UseDefaultWebProxy = false,

            // Use HTTPS in production
            Security = new BasicHttpSecurity
            {
                Mode = BasicHttpSecurityMode.Transport
            }
        };

        var url = config["SoapApi:BaseUrl"]
            ?? throw new InvalidOperationException("SoapApi:BaseUrl not configured");

        _endpoint       = new EndpointAddress(url);
        _channelFactory = new ChannelFactory<IExternalCardService>(_binding, _endpoint);

        // Add credentials if your Java SOAP API requires them
        _channelFactory.Credentials.UserName.UserName = config["SoapApi:Username"];
        _channelFactory.Credentials.UserName.Password = config["SoapApi:Password"];
    }

    public async Task<CardBalance> GetCardBalanceAsync(string cardNumber)
    {
        var channel = _channelFactory.CreateChannel();
        try
        {
            _logger.LogInformation("Calling SOAP API for card {CardNumber}", MaskCard(cardNumber));

            // ── Replace with your actual SOAP method call ─────────
            var response = await channel.GetBalanceAsync(new GetBalanceRequest
            {
                CardNumber = cardNumber
            });

            return new CardBalance
            {
                CardNumber       = cardNumber,
                MaskedNumber     = MaskCard(cardNumber),
                AvailableBalance = response.AvailableBalance,
                CurrentBalance   = response.CurrentBalance,
                CreditLimit      = response.CreditLimit,
                Currency         = response.Currency,
                LastUpdated      = DateTime.UtcNow,
                IsFromCache      = false
            };
        }
        finally
        {
            // Safely close WCF channel
            if (channel is IClientChannel clientChannel)
            {
                try   { clientChannel.Close(); }
                catch { clientChannel.Abort(); }
            }
        }
    }

    public async Task<List<CardBalance>> GetMultipleBalancesAsync(List<string> cardNumbers)
    {
        // Call SOAP in parallel for multiple cards
        var tasks = cardNumbers.Select(c => GetCardBalanceAsync(c));
        var results = await Task.WhenAll(tasks);
        return results.ToList();
    }

    private static string MaskCard(string card) =>
        card.Length >= 4
            ? $"**** **** **** {card[^4..]}"
            : "****";

    public void Dispose()
    {
        try   { _channelFactory.Close(); }
        catch { _channelFactory.Abort(); }
    }
}

// ── Placeholder interface — replace with your svcutil-generated one ──
[ServiceContract]
public interface IExternalCardService
{
    [OperationContract]
    Task<GetBalanceResponse> GetBalanceAsync(GetBalanceRequest request);
}

public class GetBalanceRequest
{
    public string CardNumber { get; set; } = string.Empty;
}

public class GetBalanceResponse
{
    public decimal AvailableBalance { get; set; }
    public decimal CurrentBalance   { get; set; }
    public decimal CreditLimit      { get; set; }
    public string  Currency         { get; set; } = "USD";
}
