namespace InternalApi.Models;

public class CardBalance
{
    public string  CardNumber        { get; set; } = string.Empty;
    public string  MaskedNumber      { get; set; } = string.Empty;
    public decimal AvailableBalance  { get; set; }
    public decimal CurrentBalance    { get; set; }
    public decimal CreditLimit       { get; set; }
    public string  Currency          { get; set; } = "USD";
    public DateTime LastUpdated      { get; set; }
    public bool    IsFromCache       { get; set; }
}

public class CardInfo
{
    public string   CardNumber  { get; set; } = string.Empty;
    public string   CardType    { get; set; } = string.Empty;
    public string   Status      { get; set; } = string.Empty;
    public DateTime ExpiryDate  { get; set; }
}

public class CustomerCards
{
    public string         CustomerId   { get; set; } = string.Empty;
    public string         CustomerName { get; set; } = string.Empty;
    public List<CardInfo> Cards        { get; set; } = new();
}

public class MultiCardBalanceRequest
{
    public List<string> CardNumbers  { get; set; } = new();
    public bool         ForceRefresh { get; set; } = false;
}

public class CustomerCardBalances
{
    public string            CustomerId { get; set; } = string.Empty;
    public List<CardBalance> Balances   { get; set; } = new();
}
