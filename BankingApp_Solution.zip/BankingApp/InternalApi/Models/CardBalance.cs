namespace InternalApi.Models;

public class CardBalance
{
    public string CardNumber      { get; set; } = string.Empty;
    public string MaskedNumber    { get; set; } = string.Empty; // e.g. **** **** **** 1234
    public decimal AvailableBalance { get; set; }
    public decimal CurrentBalance  { get; set; }
    public decimal CreditLimit    { get; set; }
    public string Currency        { get; set; } = "USD";
    public DateTime LastUpdated   { get; set; }
    public bool   IsFromCache     { get; set; } // helpful for debugging
}

public class CustomerCards
{
    public string CustomerId      { get; set; } = string.Empty;
    public string CustomerName    { get; set; } = string.Empty;
    public List<CardInfo> Cards   { get; set; } = new();
}

public class CardInfo
{
    public string CardNumber      { get; set; } = string.Empty;
    public string CardType        { get; set; } = string.Empty; // Visa, MasterCard
    public string Status          { get; set; } = string.Empty; // Active, Blocked
    public DateTime ExpiryDate    { get; set; }
}

public class BalanceRequest
{
    public string CardNumber      { get; set; } = string.Empty;
    public bool   ForceRefresh    { get; set; } = false; // bypass cache
}

public class MultiCardBalanceRequest
{
    public List<string> CardNumbers { get; set; } = new();
    public bool ForceRefresh        { get; set; } = false;
}
