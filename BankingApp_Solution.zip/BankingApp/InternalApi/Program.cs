using System.Threading.RateLimiting;
using InternalApi.Infrastructure;
using InternalApi.Resilience;
using InternalApi.Services;

var builder = WebApplication.CreateBuilder(args);

// ═══════════════════════════════════════════════════════════════
// 1. CONTROLLERS + SWAGGER
// ═══════════════════════════════════════════════════════════════
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title       = "Banking Card Balance API",
        Version     = "v1",
        Description = "Internal API: Redis caching + SOAP integration"
    });
});

// ═══════════════════════════════════════════════════════════════
// 2. REDIS DISTRIBUTED CACHE
// ═══════════════════════════════════════════════════════════════
var redisConn = builder.Configuration["Redis:ConnectionString"];
if (!string.IsNullOrEmpty(redisConn))
{
    builder.Services.AddStackExchangeRedisCache(options =>
    {
        options.Configuration = redisConn;
        options.InstanceName  = "BankingApp:";
    });
}
else
{
    builder.Services.AddDistributedMemoryCache();
    Console.WriteLine("[Startup] Redis not configured — using in-memory cache");
}

// ═══════════════════════════════════════════════════════════════
// 3. SOAP CLIENT — SINGLETON (critical for CPU reduction)
//    One ChannelFactory shared across ALL requests.
//    NEVER change this to Scoped/Transient.
// ═══════════════════════════════════════════════════════════════
builder.Services.AddSingleton<ICardSoapClient, CardSoapClient>();

// ═══════════════════════════════════════════════════════════════
// 4. BALANCE SERVICE — SCOPED
// ═══════════════════════════════════════════════════════════════
builder.Services.AddScoped<ICardBalanceService, CardBalanceService>();

// ═══════════════════════════════════════════════════════════════
// 5. POLLY: Retry + Circuit Breaker + Timeout
// ═══════════════════════════════════════════════════════════════
builder.Services.AddSoapResiliencePipeline();

// ═══════════════════════════════════════════════════════════════
// 6. RATE LIMITER — max 50 concurrent SOAP calls
// ═══════════════════════════════════════════════════════════════
builder.Services.AddRateLimiter(options =>
{
    options.AddConcurrencyLimiter("soap-limiter", o =>
    {
        o.PermitLimit          = 50;
        o.QueueLimit           = 200;
        o.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
    });
    options.OnRejected = async (ctx, token) =>
    {
        ctx.HttpContext.Response.StatusCode = 429;
        await ctx.HttpContext.Response.WriteAsync("Server busy — please retry shortly.", token);
    };
});

// ═══════════════════════════════════════════════════════════════
// 7. CORS
// ═══════════════════════════════════════════════════════════════
builder.Services.AddCors(options =>
{
    options.AddPolicy("BlazorClient", policy =>
        policy.WithOrigins(
                builder.Configuration["AllowedOrigins"] ?? "https://localhost:7001",
                "https://localhost:5001", "http://localhost:5000")
              .AllowAnyHeader().AllowAnyMethod());
});

// ═══════════════════════════════════════════════════════════════
// 8. HEALTH CHECKS
// ═══════════════════════════════════════════════════════════════
var healthBuilder = builder.Services.AddHealthChecks();
if (!string.IsNullOrEmpty(redisConn))
    healthBuilder.AddRedis(redisConn, name: "redis");

// ── PIPELINE ───────────────────────────────────────────────────
var app = builder.Build();

if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }

app.UseHttpsRedirection();
app.UseCors("BlazorClient");
app.UseRateLimiter();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
