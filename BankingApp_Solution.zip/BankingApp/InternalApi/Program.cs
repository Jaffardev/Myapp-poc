using System.Threading.RateLimiting;
using InternalApi.Infrastructure;
using InternalApi.Resilience;
using InternalApi.Services;

var builder = WebApplication.CreateBuilder(args);

// ════════════════════════════════════════════════════════════════
// 1. CONTROLLERS
// ════════════════════════════════════════════════════════════════
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ════════════════════════════════════════════════════════════════
// 2. REDIS CACHE
//    Single Redis instance caches balance data across all API servers.
//    Even if you have 3 API instances, they share one cache.
// ════════════════════════════════════════════════════════════════
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration         = builder.Configuration["Redis:ConnectionString"];
    options.InstanceName          = "BankingApp:";

    // Connection pooling for Redis
    options.ConfigurationOptions  = StackExchange.Redis.ConfigurationOptions.Parse(
        builder.Configuration["Redis:ConnectionString"] ?? "localhost:6379");
    options.ConfigurationOptions.AbortOnConnectFail = false; // degrade gracefully
    options.ConfigurationOptions.ConnectTimeout     = 3000;
    options.ConfigurationOptions.SyncTimeout        = 2000;
});

// Fallback: in-memory cache if Redis unavailable (single server only)
builder.Services.AddMemoryCache();

// ════════════════════════════════════════════════════════════════
// 3. SOAP CLIENT — Singleton for connection reuse
//    Creating a new SOAP client per request is the #1 CPU killer.
//    Singleton means ONE client shared across all requests.
// ════════════════════════════════════════════════════════════════
builder.Services.AddSingleton<ICardSoapClient, CardSoapClient>();

// ════════════════════════════════════════════════════════════════
// 4. BALANCE SERVICE — Scoped (per request)
// ════════════════════════════════════════════════════════════════
builder.Services.AddScoped<ICardBalanceService, CardBalanceService>();

// ════════════════════════════════════════════════════════════════
// 5. POLLY RESILIENCE PIPELINE
//    Retry + Circuit Breaker + Timeout
// ════════════════════════════════════════════════════════════════
builder.Services.AddSoapResiliencePipeline();

// ════════════════════════════════════════════════════════════════
// 6. RATE LIMITER — Concurrency limiter on outbound SOAP calls
//
//    PermitLimit = 50   → max 50 simultaneous SOAP calls
//    QueueLimit  = 200  → up to 200 more requests wait in queue
//
//    This prevents your 1000 agents from opening 1000 simultaneous
//    connections to the Java API (which would overwhelm it).
// ════════════════════════════════════════════════════════════════
builder.Services.AddRateLimiter(options =>
{
    options.AddConcurrencyLimiter("soap-limiter", o =>
    {
        o.PermitLimit            = 50;
        o.QueueLimit             = 200;
        o.QueueProcessingOrder   = QueueProcessingOrder.OldestFirst;
    });

    // What to return when queue is full
    options.OnRejected = async (context, token) =>
    {
        context.HttpContext.Response.StatusCode = 429;
        await context.HttpContext.Response.WriteAsync(
            "Too many concurrent requests. Please retry shortly.", token);
    };
});

// ════════════════════════════════════════════════════════════════
// 7. CORS — allow Blazor frontend
// ════════════════════════════════════════════════════════════════
builder.Services.AddCors(options =>
{
    options.AddPolicy("BlazorClient", policy =>
    {
        policy
            .WithOrigins(builder.Configuration["AllowedOrigins"] ?? "https://localhost:7001")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

// ════════════════════════════════════════════════════════════════
// 8. HEALTH CHECKS
// ════════════════════════════════════════════════════════════════
builder.Services.AddHealthChecks()
    .AddRedis(builder.Configuration["Redis:ConnectionString"] ?? "localhost:6379",
              name: "redis", tags: new[] { "cache" });

// ════════════════════════════════════════════════════════════════
// PIPELINE
// ════════════════════════════════════════════════════════════════
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("BlazorClient");
app.UseRateLimiter();         // must be before MapControllers
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
