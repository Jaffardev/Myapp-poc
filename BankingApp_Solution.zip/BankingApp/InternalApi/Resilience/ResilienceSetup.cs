using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;
using Polly.Timeout;

namespace InternalApi.Resilience;

public static class ResilienceSetup
{
    public static IServiceCollection AddSoapResiliencePipeline(
        this IServiceCollection services)
    {
        services.AddResiliencePipeline("soap-pipeline", builder =>
        {
            builder

                // ── 1. Timeout: fail fast if Java API is slow ──────────
                .AddTimeout(new TimeoutStrategyOptions
                {
                    Timeout = TimeSpan.FromSeconds(10)
                })

                // ── 2. Retry: transient failures (network blip etc.) ───
                .AddRetry(new RetryStrategyOptions
                {
                    MaxRetryAttempts = 2,
                    Delay            = TimeSpan.FromMilliseconds(300),
                    BackoffType      = DelayBackoffType.Exponential,
                    UseJitter        = true, // avoids retry storms
                    ShouldHandle     = args => args.Outcome.Exception is
                        HttpRequestException or TimeoutRejectedException
                        ? PredicateResult.True()
                        : PredicateResult.False()
                })

                // ── 3. Circuit breaker: stop hammering a failing API ───
                //    After 50% failures in 10s window → open for 30s
                //    During open: requests fail immediately (no waiting)
                //    This alone can save massive CPU during outages
                .AddCircuitBreaker(new CircuitBreakerStrategyOptions
                {
                    FailureRatio       = 0.5,
                    MinimumThroughput  = 10,  // need at least 10 calls to trip
                    SamplingDuration   = TimeSpan.FromSeconds(10),
                    BreakDuration      = TimeSpan.FromSeconds(30),
                    OnOpened = args =>
                    {
                        // Log when circuit opens — alert your ops team here
                        Console.WriteLine(
                            $"[Circuit Breaker] OPEN — Java SOAP API appears down. " +
                            $"Breaking for {args.BreakDuration.TotalSeconds}s");
                        return ValueTask.CompletedTask;
                    },
                    OnClosed = args =>
                    {
                        Console.WriteLine("[Circuit Breaker] CLOSED — Java SOAP API recovered");
                        return ValueTask.CompletedTask;
                    }
                });
        });

        return services;
    }
}
