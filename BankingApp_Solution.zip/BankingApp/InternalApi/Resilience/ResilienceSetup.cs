using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;
using Polly.Timeout;

namespace InternalApi.Resilience;

public static class ResilienceSetup
{
    public static IServiceCollection AddSoapResiliencePipeline(
        this IServiceCollection services)
    {
        services.AddResiliencePipeline("soap-pipeline", builder =>
        {
            builder
                // 1. Timeout: kill slow SOAP calls quickly
                .AddTimeout(new TimeoutStrategyOptions
                {
                    Timeout = TimeSpan.FromSeconds(10)
                })

                // 2. Retry: handle transient network failures
                .AddRetry(new RetryStrategyOptions
                {
                    MaxRetryAttempts = 2,
                    Delay            = TimeSpan.FromMilliseconds(300),
                    BackoffType      = DelayBackoffType.Exponential,
                    UseJitter        = true,
                    ShouldHandle     = args =>
                        args.Outcome.Exception is HttpRequestException
                            or TimeoutRejectedException
                            ? PredicateResult.True()
                            : PredicateResult.False()
                })

                // 3. Circuit Breaker: stop hammering a failing Java API
                //    50% failures in 10s window → open circuit for 30s
                //    Open circuit = requests fail immediately (saves CPU)
                .AddCircuitBreaker(new CircuitBreakerStrategyOptions
                {
                    FailureRatio      = 0.5,
                    MinimumThroughput = 10,
                    SamplingDuration  = TimeSpan.FromSeconds(10),
                    BreakDuration     = TimeSpan.FromSeconds(30),
                    OnOpened = args =>
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(
                            $"[CircuitBreaker] OPEN — Java API appears down. " +
                            $"Breaking for {args.BreakDuration.TotalSeconds}s");
                        Console.ResetColor();
                        return ValueTask.CompletedTask;
                    },
                    OnClosed = args =>
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("[CircuitBreaker] CLOSED — Java API recovered");
                        Console.ResetColor();
                        return ValueTask.CompletedTask;
                    },
                    OnHalfOpened = args =>
                    {
                        Console.WriteLine("[CircuitBreaker] HALF-OPEN — probing Java API...");
                        return ValueTask.CompletedTask;
                    }
                });
        });

        return services;
    }
}
