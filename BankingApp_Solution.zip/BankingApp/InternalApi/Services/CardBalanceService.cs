using System.Text.Json;
using InternalApi.Infrastructure;
using InternalApi.Models;
using Microsoft.Extensions.Caching.Distributed;

namespace InternalApi.Services;

public interface ICardBalanceService
{
    Task<CardBalance> GetBalanceAsync(string cardNumber, bool forceRefresh = false);
    Task<List<CardBalance>> GetAllBalancesAsync(List<string> cardNumbers, bool forceRefresh = false);
}

public class CardBalanceService : ICardBalanceService
{
    private readonly ICardSoapClient    _soapClient;
    private readonly IDistributedCache  _cache;
    private readonly ILogger<CardBalanceService> _logger;
    private readonly ResiliencePipelineProvider  _resilience;

    // Per-card locks to prevent cache stampede
    // Different cards get different locks — no unnecessary blocking
    private readonly LockPool _lockPool = new(poolSize: 100);

    // How long to cache balance — short for banking (real-time feel)
    private static readonly TimeSpan CacheTtl = TimeSpan.FromSeconds(30);

    public CardBalanceService(
        ICardSoapClient soapClient,
        IDistributedCache cache,
        ILogger<CardBalanceService> logger,
        ResiliencePipelineProvider resilience)
    {
        _soapClient = soapClient;
        _cache      = cache;
        _logger     = logger;
        _resilience = resilience;
    }

    // ── Single card balance ────────────────────────────────────────
    public async Task<CardBalance> GetBalanceAsync(
        string cardNumber,
        bool forceRefresh = false)
    {
        var cacheKey = $"balance:{cardNumber}";

        // 1. Skip cache if agent explicitly requests fresh data
        if (!forceRefresh)
        {
            var cached = await TryGetFromCacheAsync(cacheKey);
            if (cached != null)
            {
                _logger.LogDebug("Cache HIT for card {Card}", MaskCard(cardNumber));
                cached.IsFromCache = true;
                return cached;
            }
        }

        // 2. Acquire per-card lock to prevent stampede
        //    (100 agents checking same card → only 1 SOAP call)
        var semaphore = _lockPool.GetLock(cardNumber);
        await semaphore.WaitAsync();
        try
        {
            // 3. Double-check cache after acquiring lock
            if (!forceRefresh)
            {
                var cached = await TryGetFromCacheAsync(cacheKey);
                if (cached != null)
                {
                    cached.IsFromCache = true;
                    return cached;
                }
            }

            // 4. Call SOAP with resilience pipeline
            var pipeline = _resilience.GetPipeline("soap-pipeline");
            var balance  = await pipeline.ExecuteAsync(
                async ct => await _soapClient.GetCardBalanceAsync(cardNumber));

            // 5. Store in cache
            await SetCacheAsync(cacheKey, balance);

            _logger.LogInformation(
                "SOAP call completed for {Card}, Balance: {Balance}",
                MaskCard(cardNumber), balance.AvailableBalance);

            return balance;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get balance for card {Card}", MaskCard(cardNumber));
            throw;
        }
        finally
        {
            semaphore.Release();
        }
    }

    // ── Multiple cards in parallel ─────────────────────────────────
    public async Task<List<CardBalance>> GetAllBalancesAsync(
        List<string> cardNumbers,
        bool forceRefresh = false)
    {
        // Fetch all cards concurrently — each independently cached
        var tasks = cardNumbers.Select(c => GetBalanceAsync(c, forceRefresh));
        var results = await Task.WhenAll(tasks);
        return results.ToList();
    }

    // ── Cache helpers ──────────────────────────────────────────────
    private async Task<CardBalance?> TryGetFromCacheAsync(string key)
    {
        try
        {
            var data = await _cache.GetStringAsync(key);
            if (data == null) return null;
            return JsonSerializer.Deserialize<CardBalance>(data);
        }
        catch (Exception ex)
        {
            // Cache failure should NOT break the app — degrade gracefully
            _logger.LogWarning(ex, "Cache read failed for key {Key}, will call SOAP", key);
            return null;
        }
    }

    private async Task SetCacheAsync(string key, CardBalance balance)
    {
        try
        {
            var json = JsonSerializer.Serialize(balance);
            await _cache.SetStringAsync(key, json, new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = CacheTtl
            });
        }
        catch (Exception ex)
        {
            // Cache write failure is non-fatal
            _logger.LogWarning(ex, "Cache write failed for key {Key}", key);
        }
    }

    private static string MaskCard(string card) =>
        card.Length >= 4 ? $"****{card[^4..]}" : "****";
}

// ── Lock pool — avoids single bottleneck across all cards ──────────
public class LockPool
{
    private readonly SemaphoreSlim[] _locks;

    public LockPool(int poolSize)
    {
        _locks = Enumerable
            .Range(0, poolSize)
            .Select(_ => new SemaphoreSlim(1, 1))
            .ToArray();
    }

    public SemaphoreSlim GetLock(string key)
    {
        // Distribute cards across pool using hash
        var index = Math.Abs(key.GetHashCode() % _locks.Length);
        return _locks[index];
    }
}

// ── Placeholder for DI wiring ──────────────────────────────────────
public class ResiliencePipelineProvider
{
    private readonly Polly.ResiliencePipeline _pipeline;

    public ResiliencePipelineProvider(Polly.ResiliencePipeline pipeline)
    {
        _pipeline = pipeline;
    }

    public Polly.ResiliencePipeline GetPipeline(string name) => _pipeline;
}
