using System.Text.Json;
using InternalApi.Infrastructure;
using InternalApi.Models;
using Microsoft.Extensions.Caching.Distributed;

namespace InternalApi.Services;

public interface ICardBalanceService
{
    Task<CardBalance> GetBalanceAsync(string cardNumber, bool forceRefresh = false);
    Task<List<CardBalance>> GetAllBalancesAsync(List<string> cardNumbers, bool forceRefresh = false);
}

public class CardBalanceService : ICardBalanceService
{
    private readonly ICardSoapClient   _soapClient;
    private readonly IDistributedCache _cache;
    private readonly ILogger<CardBalanceService> _logger;

    // 100-slot lock pool — different cards get different locks
    // Prevents single bottleneck while still blocking stampede per card
    private static readonly LockPool _lockPool = new(poolSize: 100);

    // 30 seconds is safe for banking — short enough to feel live,
    // long enough to absorb bursts from 1000 agents on same card
    private static readonly TimeSpan CacheTtl = TimeSpan.FromSeconds(30);

    public CardBalanceService(
        ICardSoapClient soapClient,
        IDistributedCache cache,
        ILogger<CardBalanceService> logger)
    {
        _soapClient = soapClient;
        _cache      = cache;
        _logger     = logger;
    }

    public async Task<CardBalance> GetBalanceAsync(
        string cardNumber,
        bool forceRefresh = false)
    {
        var cacheKey = $"balance:{cardNumber}";

        // ── Step 1: Check cache (skip if agent wants fresh data) ──
        if (!forceRefresh)
        {
            var cached = await TryGetFromCacheAsync(cacheKey);
            if (cached != null)
            {
                _logger.LogDebug("Cache HIT for {Card}", Mask(cardNumber));
                cached.IsFromCache = true;
                return cached;
            }
        }

        // ── Step 2: Acquire per-card lock (prevents stampede) ─────
        var semaphore = _lockPool.GetLock(cardNumber);
        await semaphore.WaitAsync();
        try
        {
            // ── Step 3: Double-check after lock acquired ───────────
            if (!forceRefresh)
            {
                var cached = await TryGetFromCacheAsync(cacheKey);
                if (cached != null)
                {
                    cached.IsFromCache = true;
                    return cached;
                }
            }

            // ── Step 4: Call SOAP ──────────────────────────────────
            var balance = await _soapClient.GetCardBalanceAsync(cardNumber);

            // ── Step 5: Write to cache ─────────────────────────────
            await SetCacheAsync(cacheKey, balance);

            _logger.LogInformation(
                "SOAP fetched balance for {Card}: {Balance} (Instance#{Count})",
                Mask(cardNumber), balance.AvailableBalance, CardSoapClient.InstanceCount);

            return balance;
        }
        finally
        {
            semaphore.Release();
        }
    }

    public async Task<List<CardBalance>> GetAllBalancesAsync(
        List<string> cardNumbers,
        bool forceRefresh = false)
    {
        var tasks   = cardNumbers.Select(c => GetBalanceAsync(c, forceRefresh));
        var results = await Task.WhenAll(tasks);
        return results.ToList();
    }

    private async Task<CardBalance?> TryGetFromCacheAsync(string key)
    {
        try
        {
            var data = await _cache.GetStringAsync(key);
            if (data == null) return null;
            return JsonSerializer.Deserialize<CardBalance>(data);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Cache read failed for {Key} — falling through to SOAP", key);
            return null;
        }
    }

    private async Task SetCacheAsync(string key, CardBalance balance)
    {
        try
        {
            var json = JsonSerializer.Serialize(balance);
            await _cache.SetStringAsync(key, json, new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = CacheTtl
            });
        }
        catch (Exception ex)
        {
            // Cache write failure is non-fatal — app continues
            _logger.LogWarning(ex, "Cache write failed for {Key}", key);
        }
    }

    private static string Mask(string card) =>
        card.Length >= 4 ? $"****{card[^4..]}" : "****";
}

// ── LockPool: 100 independent semaphores distributed by card hash ─
public class LockPool
{
    private readonly SemaphoreSlim[] _locks;

    public LockPool(int poolSize)
    {
        _locks = Enumerable
            .Range(0, poolSize)
            .Select(_ => new SemaphoreSlim(1, 1))
            .ToArray();
    }

    public SemaphoreSlim GetLock(string key)
    {
        var index = Math.Abs(key.GetHashCode() % _locks.Length);
        return _locks[index];
    }
}
