# Banking Card Balance — High Performance Architecture

## Project Structure

```
BankingApp/
├── InternalApi/                        ← ASP.NET Core 8 API
│   ├── Controllers/
│   │   └── CardBalanceController.cs   ← Endpoints (single + bulk)
│   ├── Services/
│   │   └── CardBalanceService.cs      ← Cache logic + LockPool
│   ├── Infrastructure/
│   │   └── CardSoapClient.cs          ← Java SOAP wrapper (Singleton)
│   ├── Resilience/
│   │   └── ResilienceSetup.cs         ← Polly: retry + CB + timeout
│   ├── Models/
│   │   └── CardBalance.cs             ← DTOs
│   └── Program.cs                     ← Full DI wiring
│
└── BlazorClient/                       ← Blazor WebAssembly
    ├── Pages/
    │   └── CardBalances.razor         ← Agent UI
    ├── Services/
    │   └── CardBalanceClientService.cs ← HTTP calls to Internal API
    ├── Models/
    │   └── CardBalance.cs
    └── Program.cs                     ← HttpClient setup


## How Each Layer Reduces CPU / Latency

┌──────────────────────────────────────────────────────────────────┐
│  1000 Call Center Agents (Blazor)                                │
└─────────────────────────┬────────────────────────────────────────┘
                          │ HTTP
┌─────────────────────────▼────────────────────────────────────────┐
│  ASP.NET Core 8 — Internal API                                   │
│                                                                  │
│  ┌──────────────────┐    ┌──────────────────────────────────┐    │
│  │ Rate Limiter     │    │ CardBalanceService               │    │
│  │ Max 50 SOAP      │    │                                  │    │
│  │ concurrent calls │    │  1. Check Redis cache            │    │
│  └──────────────────┘    │  2. SemaphoreSlim (per card)     │    │
│                          │  3. Polly pipeline               │    │
│  ┌──────────────────┐    │  4. SOAP call if miss            │    │
│  │ Redis Cache      │◄───│  5. Write back to cache          │    │
│  │ 30s TTL          │    └──────────────────────────────────┘    │
│  └──────────────────┘                                            │
│                                       │                          │
└───────────────────────────────────────┼──────────────────────────┘
                                        │ SOAP (controlled)
┌───────────────────────────────────────▼──────────────────────────┐
│  Java SOAP API (External)                                        │
│  Receives max 50 concurrent calls instead of 1000               │
└──────────────────────────────────────────────────────────────────┘


## Key Performance Decisions

| Decision                | Why                                          |
|-------------------------|----------------------------------------------|
| Singleton SoapClient    | Reuses TCP connections, avoids setup cost     |
| Redis 30s cache         | 1000 agents → same cards → 1 SOAP call       |
| LockPool (100 slots)    | Prevents stampede without a single bottleneck|
| Concurrency limiter 50  | Java API gets controlled load, not a flood   |
| Parallel multi-card     | 5 cards = 1 parallel batch, not 5 sequential |
| Circuit breaker         | Java outage → fail fast, no thread pile-up   |
| forceRefresh flag       | Post-transaction agents can bypass cache     |


## Setup Steps

### 1. Redis
```bash
# Docker (local dev)
docker run -d -p 6379:6379 redis:alpine

# Azure Cache for Redis (production)
# Add connection string to appsettings.json → Redis:ConnectionString
```

### 2. SOAP Client Generation
```bash
# Generate typed client from your Java WSDL
dotnet tool install --global dotnet-svcutil
dotnet-svcutil https://java-soap-api.yourbank.com/CardBalanceService?wsdl

# Replace IExternalCardService interface in CardSoapClient.cs
# with the generated Reference.cs client
```

### 3. Configuration (appsettings.json)
```json
{
  "SoapApi": {
    "BaseUrl":  "https://java-soap-api.yourbank.com/CardBalanceService",
    "Username": "...",
    "Password": "..."
  },
  "Redis": {
    "ConnectionString": "your-redis:6379,password=...,ssl=true"
  }
}
```

### 4. NuGet Packages Needed (Internal API)
```xml
<PackageReference Include="Microsoft.Extensions.Caching.StackExchangeRedis" Version="8.*" />
<PackageReference Include="Polly.Extensions" Version="8.*" />
<PackageReference Include="Microsoft.Extensions.Http.Resilience" Version="8.*" />
<PackageReference Include="System.ServiceModel.Http" Version="6.*" />
```


## Expected Results After Implementation

| Metric         | Before   | After (estimated)  |
|----------------|----------|--------------------|
| CPU Usage      | 70–80%   | 20–30%             |
| SOAP calls/min | 1000     | 50–100             |
| Response time  | 800ms+   | 50ms (cache hit)   |
| Fault handling | Crash    | Graceful 503       |
