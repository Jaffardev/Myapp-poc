# BankingApp — High Performance Card Balance System

## Quick Start

### Prerequisites
- Visual Studio 2022 or VS Code with C# extension
- .NET 8 SDK
- Redis (optional for dev — falls back to in-memory)

### Run the Internal API
```bash
cd InternalApi
dotnet run
# Swagger UI: https://localhost:5001/swagger
# Health check: https://localhost:5001/health
```

### Run the Blazor Client
```bash
cd BlazorClient
dotnet run
```

---

## Before Running — 2 Steps Required

### 1. Generate your SOAP client
```bash
dotnet tool install --global dotnet-svcutil
dotnet-svcutil https://java-soap-api.yourbank.com/CardBalanceService?wsdl --outputDir InternalApi/Infrastructure
```
Then replace `IExternalCardService` in `CardSoapClient.cs` with the generated class.

### 2. Fill in appsettings.json
```json
{
  "SoapApi": {
    "BaseUrl":  "https://java-soap-api.yourbank.com/CardBalanceService",
    "Username": "your-username",
    "Password": "your-password"
  },
  "Redis": {
    "ConnectionString": "your-redis:6379,password=xxx,ssl=true"
  }
}
```

---

## Validate Singleton is Working

After running, hit this endpoint from Postman or browser:
```
GET https://localhost:5001/api/diagnostics/soap-info
```

Expected response:
```json
{
  "soapClientInstancesCreated": 1,
  "isCorrect": true,
  "message": "✅ Singleton working correctly"
}
```

---

## Solution Structure

```
BankingApp.sln
├── InternalApi/                    ASP.NET Core 8 Web API
│   ├── Controllers/
│   │   └── CardBalanceController.cs    Endpoints + DiagnosticsController
│   ├── Services/
│   │   └── CardBalanceService.cs       Cache-aside + LockPool
│   ├── Infrastructure/
│   │   └── CardSoapClient.cs           Singleton SOAP wrapper
│   ├── Resilience/
│   │   └── ResilienceSetup.cs          Polly pipeline
│   ├── Models/
│   │   └── CardBalance.cs
│   └── Program.cs                      DI wiring
│
└── BlazorClient/                   Blazor WebAssembly
    ├── Pages/
    │   └── CardBalances.razor          Agent UI
    ├── Services/
    │   └── CardBalanceClientService.cs HTTP client
    └── Models/
        └── CardBalance.cs
```
