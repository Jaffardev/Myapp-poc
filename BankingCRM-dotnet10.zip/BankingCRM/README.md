# BankingCRM — .NET 10 High-Concurrency Web API
### Senior Architect Reference · Clean Architecture · OpenTelemetry · Pooled EF Core

---

## Solution Structure

```
BankingCRM/
├── scaffold.sh                         ← Run this first (dotnet new commands)
├── docker-compose.yml                  ← SQL Server + Jaeger + Prometheus + Grafana
├── ALL_CSPROJ_FILES.xml                ← Copy each <Project> block to its .csproj
│
├── src/
│   ├── BankingCRM.Domain/              ← LAYER 1 — Pure C#, zero dependencies
│   │   └── Domain.cs
│   │       ├── Common/          AggregateRoot, IDomainEvent
│   │       ├── Entities/        Lead (aggregate root)
│   │       ├── ValueObjects/    Email, PhoneNumber, Money
│   │       ├── Enums/           LeadStatus
│   │       ├── Events/          LeadCreatedEvent, LeadAssignedEvent, LeadClosedEvent
│   │       └── Repositories/    ILeadRepository, IUnitOfWork  (interfaces only)
│   │
│   ├── BankingCRM.Application/         ← LAYER 2 — Use cases, orchestration
│   │   └── Application.cs
│   │       ├── DTOs/            LeadDto, CreateLeadRequest, BankingCrmJsonContext ◄─ STJ
│   │       ├── Mapping/         LeadMapper (extension methods)
│   │       ├── Commands/        CreateLeadCommand, AssignLeadCommand + Handlers
│   │       ├── Queries/         GetLeadQuery + Handler
│   │       ├── Behaviours/      ValidationBehaviour, LoggingBehaviour
│   │       └── Services/        LeadDistributionService  ◄─ SemaphoreSlim throttle
│   │
│   ├── BankingCRM.Infrastructure/      ← LAYER 3 — EF Core, SQL Server, IDbContextFactory
│   │   └── Infrastructure.cs
│   │       ├── Persistence/     BankingCrmDbContext, UnitOfWork
│   │       └── Repositories/    LeadRepository
│   │
│   └── BankingCRM.API/                 ← LAYER 4 — Minimal API host
│       ├── Program.cs                  ← Full wiring: OTel, STJ, DI, Endpoints
│       ├── appsettings.json
│       └── appsettings.Development.json
│
├── tests/
│   ├── BankingCRM.UnitTests/
│   │   └── UnitTests.cs                ← Lead aggregate, SemaphoreSlim, ValidationBehaviour
│   └── BankingCRM.IntegrationTests/
│       └── IntegrationTests.cs         ← WebApplicationFactory, full HTTP pipeline
│
└── infra/
    └── prometheus.yml
```

---

## Dependency Flow (Clean Architecture)

```
  ┌─────────────────────────────────────────────────────────┐
  │  BankingCRM.API  (Minimal API host)                     │
  │  • Program.cs wires DI, OTel, STJ, health checks        │
  │  • Maps HTTP verbs → MediatR commands/queries           │
  └────────────────────┬────────────────────────────────────┘
                       │  references
  ┌────────────────────▼────────────────────────────────────┐
  │  BankingCRM.Infrastructure                              │
  │  • AddPooledDbContextFactory<BankingCrmDbContext>       │
  │  • UnitOfWork (resolves context from pool per scope)    │
  │  • LeadRepository (EF Core queries)                     │
  └────────────────────┬────────────────────────────────────┘
                       │  references
  ┌────────────────────▼────────────────────────────────────┐
  │  BankingCRM.Application                                 │
  │  • CQRS Commands/Queries (MediatR)                      │
  │  • ValidationBehaviour + LoggingBehaviour pipelines     │
  │  • LeadDistributionService (BackgroundService)          │
  │    ↳ SemaphoreSlim(4, 4) — concurrency throttle        │
  │  • BankingCrmJsonContext (STJ source generator)         │
  └────────────────────┬────────────────────────────────────┘
                       │  references
  ┌────────────────────▼────────────────────────────────────┐
  │  BankingCRM.Domain  (no outbound references)            │
  │  • Lead aggregate root + domain events                  │
  │  • Value objects: Email, PhoneNumber, Money             │
  │  • ILeadRepository, IUnitOfWork (interfaces)            │
  └─────────────────────────────────────────────────────────┘
```

---

## Key Design Decisions

### 1. `AddPooledDbContextFactory` — Why and How

```csharp
// Infrastructure.cs
services.AddPooledDbContextFactory<BankingCrmDbContext>(
    options => options.UseSqlServer(connectionString, sql =>
    {
        sql.EnableRetryOnFailure(maxRetryCount: 5, ...);
        sql.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
    }),
    poolSize: 128);   // ← match your SQL Server MaxPoolSize
```

| Concern | `AddDbContext` | `AddPooledDbContextFactory` |
|---|---|---|
| Instance creation | New on every scope | Reused from pool |
| SQL connection | Opened per request | Pre-warmed, reused |
| Model compilation | Every startup | Once, then cached |
| Suitable for | Simple CRUD | High-concurrency APIs |

---

### 2. `SemaphoreSlim` in `LeadDistributionService`

```csharp
private const int MaxConcurrentDbOps = 4;
private readonly SemaphoreSlim _throttle = new(MaxConcurrentDbOps, MaxConcurrentDbOps);

private async Task AssignWithThrottleAsync(Guid leadId, CancellationToken ct)
{
    await _throttle.WaitAsync(ct);          // ← async wait, no thread blocked
    try
    {
        var lead = await uow.Leads.GetByIdAsync(leadId, ct);
        lead.AssignToAgent(agentId);
        await uow.CommitAsync(ct);
    }
    finally
    {
        _throttle.Release();                // ← always release, even on exception
    }
}
```

**Tuning guide:**

| `MaxConcurrentDbOps` | Effect |
|---|---|
| 1–2 | Serialised — safe, but slow |
| 4–8 | Recommended starting point |
| = pool size | No throttle benefit |
| > pool size | Connection exhaustion risk |

---

### 3. STJ Source Generators (WCF/SOAP Replacement Pattern)

```csharp
[JsonSerializable(typeof(LeadDto))]
[JsonSerializable(typeof(CreateLeadRequest))]
[JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase)]
public partial class BankingCrmJsonContext : JsonSerializerContext;

// Plug into ASP.NET Core pipeline
builder.Services.Configure<JsonOptions>(opt =>
    opt.SerializerOptions.TypeInfoResolverChain.Insert(
        0, BankingCrmJsonContext.Default));
```

Benefits: zero runtime IL, AOT/NativeAOT compatible, ~3–4× faster throughput.

---

### 4. OpenTelemetry — Three Signals

```
  .NET App
   ├─ Traces  ──OTLP/gRPC──► Jaeger :4317  → UI :16686
   ├─ Metrics ──OTLP/gRPC──► Prometheus
   └─ Logs    ──OTLP/gRPC──► Loki / any OTLP backend
```

---

## Getting Started

```bash
# 1. Infrastructure
docker compose up -d

# 2. Scaffold projects
chmod +x scaffold.sh && ./scaffold.sh

# 3. EF Core migrations
cd src/BankingCRM.API
dotnet ef migrations add InitialCreate \
  --project ../BankingCRM.Infrastructure \
  --startup-project .
dotnet ef database update

# 4. Run
dotnet run --project src/BankingCRM.API
# Scalar UI → https://localhost:5001/scalar/v1
# Jaeger    → http://localhost:16686
# Health    → https://localhost:5001/health

# 5. Test
dotnet test
```

---

## Performance Checklist

- [ ] `poolSize` matches SQL `Max Pool Size` connection string setting
- [ ] `MaxConcurrentDbOps` tuned for your DB tier (start at 4)
- [ ] `JsonSerializerIsReflectionEnabledByDefault=false` in API `.csproj`
- [ ] `NoTrackingWithIdentityResolution` on read-heavy contexts
- [ ] `SetDbStatementForText = false` in OTel SQL instrumentation (PII guard)
- [ ] `RowVersion` optimistic concurrency on `Lead` entity
- [ ] Health checks wired to K8s liveness/readiness probes
- [ ] Domain events cleared before `SaveChangesAsync` (no double-dispatch)
