#!/usr/bin/env bash
# ============================================================
#  BankingCRM — .NET 10 Solution Scaffold
#  Run from the directory where you want the solution root.
# ============================================================
set -euo pipefail

SLN="BankingCRM"

# ── 1. Solution ──────────────────────────────────────────────
dotnet new sln -n $SLN
mkdir -p src tests

# ── 2. Projects ─────────────────────────────────────────────
dotnet new classlib  -n BankingCRM.Domain          -f net10.0 -o src/BankingCRM.Domain
dotnet new classlib  -n BankingCRM.Application     -f net10.0 -o src/BankingCRM.Application
dotnet new classlib  -n BankingCRM.Infrastructure  -f net10.0 -o src/BankingCRM.Infrastructure
dotnet new webapi    -n BankingCRM.API             -f net10.0 -o src/BankingCRM.API --use-minimal-apis

dotnet new xunit     -n BankingCRM.UnitTests       -f net10.0 -o tests/BankingCRM.UnitTests
dotnet new xunit     -n BankingCRM.IntegrationTests -f net10.0 -o tests/BankingCRM.IntegrationTests

# ── 3. Add to solution ───────────────────────────────────────
dotnet sln add src/BankingCRM.Domain/BankingCRM.Domain.csproj
dotnet sln add src/BankingCRM.Application/BankingCRM.Application.csproj
dotnet sln add src/BankingCRM.Infrastructure/BankingCRM.Infrastructure.csproj
dotnet sln add src/BankingCRM.API/BankingCRM.API.csproj
dotnet sln add tests/BankingCRM.UnitTests/BankingCRM.UnitTests.csproj
dotnet sln add tests/BankingCRM.IntegrationTests/BankingCRM.IntegrationTests.csproj

# ── 4. Project references ────────────────────────────────────
dotnet add src/BankingCRM.Application/BankingCRM.Application.csproj     reference src/BankingCRM.Domain/BankingCRM.Domain.csproj
dotnet add src/BankingCRM.Infrastructure/BankingCRM.Infrastructure.csproj reference src/BankingCRM.Application/BankingCRM.Application.csproj
dotnet add src/BankingCRM.API/BankingCRM.API.csproj                      reference src/BankingCRM.Infrastructure/BankingCRM.Infrastructure.csproj

dotnet add tests/BankingCRM.UnitTests/BankingCRM.UnitTests.csproj                   reference src/BankingCRM.Application/BankingCRM.Application.csproj
dotnet add tests/BankingCRM.IntegrationTests/BankingCRM.IntegrationTests.csproj     reference src/BankingCRM.API/BankingCRM.API.csproj

# ── 5. NuGet packages ────────────────────────────────────────

## Infrastructure — EF Core + SQL Server
dotnet add src/BankingCRM.Infrastructure/BankingCRM.Infrastructure.csproj package Microsoft.EntityFrameworkCore.SqlServer
dotnet add src/BankingCRM.Infrastructure/BankingCRM.Infrastructure.csproj package Microsoft.EntityFrameworkCore.Design

## OpenTelemetry (API + Infrastructure share the abstractions)
for proj in src/BankingCRM.API/BankingCRM.API.csproj src/BankingCRM.Infrastructure/BankingCRM.Infrastructure.csproj; do
  dotnet add "$proj" package OpenTelemetry.Extensions.Hosting
  dotnet add "$proj" package OpenTelemetry.Instrumentation.AspNetCore
  dotnet add "$proj" package OpenTelemetry.Instrumentation.Http
  dotnet add "$proj" package OpenTelemetry.Instrumentation.SqlClient
  dotnet add "$proj" package OpenTelemetry.Exporter.OpenTelemetryProtocol
  dotnet add "$proj" package OpenTelemetry.Exporter.Console
done

## MediatR (CQRS in Application layer)
dotnet add src/BankingCRM.Application/BankingCRM.Application.csproj package MediatR
dotnet add src/BankingCRM.API/BankingCRM.API.csproj package MediatR.Extensions.Microsoft.DependencyInjection

## FluentValidation
dotnet add src/BankingCRM.Application/BankingCRM.Application.csproj package FluentValidation
dotnet add src/BankingCRM.Application/BankingCRM.Application.csproj package FluentValidation.DependencyInjectionExtensions

## Problem Details / Resilience
dotnet add src/BankingCRM.API/BankingCRM.API.csproj package Microsoft.AspNetCore.OpenApi
dotnet add src/BankingCRM.API/BankingCRM.API.csproj package Scalar.AspNetCore

echo ""
echo "✅  Solution scaffold complete."
echo "    Next: copy the generated source files then run 'dotnet build'."
