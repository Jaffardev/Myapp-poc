// =============================================================
//  BankingCRM.API  —  Program.cs
//  .NET 10 Minimal API · OpenTelemetry · Source-gen JSON
// =============================================================

using BankingCRM.Application;
using BankingCRM.Application.Commands;
using BankingCRM.Application.DTOs;
using BankingCRM.Application.Queries;
using BankingCRM.Infrastructure;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http.Json;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System.Diagnostics;
using System.Net;
using System.Text.Json;

// ────────────────────────────────────────────────────────────────────────────
//  1.  BUILDER
// ────────────────────────────────────────────────────────────────────────────

var builder = WebApplication.CreateBuilder(args);

// ── Service name / version (propagated to every OTel signal) ────────────────
const string ServiceName    = "BankingCRM.API";
const string ServiceVersion = "1.0.0";

var resourceBuilder = ResourceBuilder.CreateDefault()
    .AddService(ServiceName, serviceVersion: ServiceVersion)
    .AddTelemetrySdk()
    .AddEnvironmentVariableDetector();

// ────────────────────────────────────────────────────────────────────────────
//  2.  SOURCE-GENERATED JSON  (replaces reflection-based serializer)
//      Equivalent of the WCF DataContractSerializer performance contract —
//      all types are known at compile time; no runtime IL emit.
// ────────────────────────────────────────────────────────────────────────────

builder.Services.Configure<JsonOptions>(opt =>
{
    opt.SerializerOptions.TypeInfoResolverChain.Insert(
        0, BankingCrmJsonContext.Default);   // source-generated resolver, highest priority
    opt.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    opt.SerializerOptions.WriteIndented        = false;
});

// Make the same context available for manual serialization needs
builder.Services.AddSingleton(BankingCrmJsonContext.Default);

// ────────────────────────────────────────────────────────────────────────────
//  3.  OPENTELEMETRY
//      Traces  → Jaeger (OTLP/gRPC on :4317)
//      Metrics → Prometheus / OTEL Collector (OTLP/gRPC on :4317)
//      Logs    → OTLP (structured, correlated with trace IDs)
// ────────────────────────────────────────────────────────────────────────────

var otlpEndpoint = builder.Configuration["OpenTelemetry:OtlpEndpoint"]
                ?? "http://localhost:4317";

builder.Services.AddOpenTelemetry()
    .WithTracing(tracing => tracing
        .SetResourceBuilder(resourceBuilder)
        .AddSource(ServiceName)
        .AddSource("BankingCRM.LeadDistribution")  // background service spans
        .AddAspNetCoreInstrumentation(opt =>
        {
            opt.RecordException = true;
            // Enrich spans with HTTP body size, user-agent, etc.
            opt.EnrichWithHttpRequest  = (activity, req)  => activity.SetTag("http.client_ip", req.HttpContext.Connection.RemoteIpAddress);
            opt.EnrichWithHttpResponse = (activity, resp) => activity.SetTag("http.response_size", resp.ContentLength);
        })
        .AddHttpClientInstrumentation()
        .AddSqlClientInstrumentation(opt =>
        {
            opt.RecordException      = true;
            opt.SetDbStatementForText = false; // never log raw SQL in prod (PII risk)
        })
        .AddOtlpExporter(opt =>
        {
            opt.Endpoint = new Uri(otlpEndpoint);
            opt.Protocol = OpenTelemetry.Exporter.OtlpExportProtocol.Grpc;
        })
        // Console exporter is useful for local development; disable in production.
        .AddConsoleExporter())

    .WithMetrics(metrics => metrics
        .SetResourceBuilder(resourceBuilder)
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddRuntimeInstrumentation()           // GC, thread pool, memory
        .AddMeter("BankingCRM.LeadDistribution")
        .AddOtlpExporter(opt => opt.Endpoint = new Uri(otlpEndpoint)));

// OTel Logging bridge — correlates ILogger output with the active trace
builder.Logging.AddOpenTelemetry(logging =>
{
    logging.SetResourceBuilder(resourceBuilder);
    logging.AddOtlpExporter(opt => opt.Endpoint = new Uri(otlpEndpoint));
    logging.IncludeScopes    = true;
    logging.IncludeFormattedMessage = true;
});

// ────────────────────────────────────────────────────────────────────────────
//  4.  DOMAIN LAYERS
// ────────────────────────────────────────────────────────────────────────────

builder.Services
    .AddApplicationServices()
    .AddInfrastructureServices(builder.Configuration);

// ────────────────────────────────────────────────────────────────────────────
//  5.  API INFRASTRUCTURE
// ────────────────────────────────────────────────────────────────────────────

builder.Services.AddOpenApi();              // Scalar / Swagger UI
builder.Services.AddProblemDetails();      // RFC 9457 structured errors
builder.Services.AddHealthChecks()
    .AddSqlServer(
        builder.Configuration.GetConnectionString("SqlServer")!,
        name:    "sqlserver",
        timeout: TimeSpan.FromSeconds(5));

// ────────────────────────────────────────────────────────────────────────────
//  6.  BUILD & MIDDLEWARE PIPELINE
// ────────────────────────────────────────────────────────────────────────────

var app = builder.Build();

// ── Exception handler — returns RFC 9457 ProblemDetails ────────────────────
app.UseExceptionHandler(errApp => errApp.Run(async ctx =>
{
    var feature = ctx.Features.Get<IExceptionHandlerFeature>();
    var ex      = feature?.Error;

    var (status, title) = ex switch
    {
        ValidationException => (400, "Validation Failed"),
        KeyNotFoundException => (404, "Not Found"),
        DbUpdateConcurrencyException => (409, "Conflict — resource modified by another request"),
        _ => (500, "An unexpected error occurred")
    };

    ctx.Response.StatusCode  = status;
    ctx.Response.ContentType = "application/problem+json";

    var problem = new ProblemDetails
    {
        Status   = status,
        Title    = title,
        Detail   = app.Environment.IsDevelopment() ? ex?.Message : null,
        Instance = ctx.Request.Path,
    };

    if (ex is ValidationException ve)
        problem.Extensions["errors"] = ve.Errors.Select(e => new { e.PropertyName, e.ErrorMessage });

    await ctx.Response.WriteAsJsonAsync(problem, BankingCrmJsonContext.Default.ProblemDetails);
}));

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();   // http://localhost:5000/scalar/v1
}

app.UseHttpsRedirection();

// ────────────────────────────────────────────────────────────────────────────
//  7.  ENDPOINT DEFINITIONS  (Minimal API)
// ────────────────────────────────────────────────────────────────────────────

var leads = app.MapGroup("/api/v1/leads")
              .WithTags("Leads")
              .WithOpenApi();

// POST /api/v1/leads
leads.MapPost("/", async (
    CreateLeadRequest req,
    IMediator mediator,
    CancellationToken ct) =>
{
    var cmd    = new CreateLeadCommand(req.FirstName, req.LastName, req.Email,
                                       req.EstimatedValue, req.Currency, req.Phone);
    var result = await mediator.Send(cmd, ct);
    return Results.Created($"/api/v1/leads/{result.Id}", result);
})
.Produces<LeadDto>(201)
.ProducesProblem(400)
.WithName("CreateLead");

// GET /api/v1/leads/{id}
leads.MapGet("/{id:guid}", async (
    Guid id,
    IMediator mediator,
    CancellationToken ct) =>
{
    var result = await mediator.Send(new GetLeadQuery(id), ct);
    return result is null ? Results.NotFound() : Results.Ok(result);
})
.Produces<LeadDto>()
.ProducesProblem(404)
.WithName("GetLead");

// PUT /api/v1/leads/{id}/assign
leads.MapPut("/{id:guid}/assign", async (
    Guid id,
    AssignLeadRequest req,
    IMediator mediator,
    CancellationToken ct) =>
{
    var result = await mediator.Send(new AssignLeadCommand(id, req.AgentId), ct);
    return Results.Ok(result);
})
.Produces<LeadDto>()
.ProducesProblem(400)
.ProducesProblem(404)
.ProducesProblem(409)
.WithName("AssignLead");

// ── Health & Observability endpoints ────────────────────────────────────────
app.MapHealthChecks("/health");
app.MapHealthChecks("/health/ready",    new() { Predicate = r => r.Tags.Contains("ready") });
app.MapHealthChecks("/health/live",     new() { Predicate = _ => false }); // liveness: always 200 if process is up

// ── Minimal ActivitySource for custom spans ──────────────────────────────────
var activitySource = new ActivitySource(ServiceName);
app.MapGet("/api/v1/ping", (HttpContext ctx) =>
{
    using var activity = activitySource.StartActivity("Ping");
    activity?.SetTag("user.agent", ctx.Request.Headers.UserAgent.ToString());
    return Results.Ok(new { message = "pong", timestamp = DateTimeOffset.UtcNow });
}).WithTags("Health");

// ────────────────────────────────────────────────────────────────────────────
//  8.  RUN
// ────────────────────────────────────────────────────────────────────────────

app.Run();

// Required for integration test host creation
public partial class Program;
