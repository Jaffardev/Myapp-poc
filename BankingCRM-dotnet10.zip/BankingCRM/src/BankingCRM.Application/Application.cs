// =============================================================
//  BankingCRM.Application
//  CQRS Commands/Queries (MediatR), Behaviours, Services
// =============================================================

// ── DTOs & Serialization Context ─────────────────────────────────────────────

namespace BankingCRM.Application.DTOs;

using System.Text.Json.Serialization;

public sealed record LeadDto(
    Guid   Id,
    string FirstName,
    string LastName,
    string Email,
    string Status,
    decimal EstimatedValue,
    string  Currency,
    Guid?   AssignedAgentId,
    DateTimeOffset CreatedAt,
    DateTimeOffset? UpdatedAt);

public sealed record CreateLeadRequest(
    string FirstName,
    string LastName,
    string Email,
    decimal EstimatedValue,
    string Currency = "USD",
    string? Phone   = null);

public sealed record AssignLeadRequest(Guid AgentId);

public sealed record PaginatedResult<T>(
    IReadOnlyList<T> Items,
    int TotalCount,
    int Page,
    int PageSize);

/// <summary>
///  Source-generated JSON context — replaces runtime reflection.
///  Equivalent of the old WCF DataContractSerializer, but zero-allocation.
/// </summary>
[JsonSerializable(typeof(LeadDto))]
[JsonSerializable(typeof(CreateLeadRequest))]
[JsonSerializable(typeof(AssignLeadRequest))]
[JsonSerializable(typeof(PaginatedResult<LeadDto>))]
[JsonSerializable(typeof(List<LeadDto>))]
[JsonSourceGenerationOptions(
    PropertyNamingPolicy      = JsonKnownNamingPolicy.CamelCase,
    DefaultIgnoreCondition    = JsonIgnoreCondition.WhenWritingNull,
    WriteIndented             = false)]
public partial class BankingCrmJsonContext : JsonSerializerContext;

// ── Mapping ───────────────────────────────────────────────────────────────────

namespace BankingCRM.Application.Mapping;

using BankingCRM.Application.DTOs;
using BankingCRM.Domain.Entities;

public static class LeadMapper
{
    public static LeadDto ToDto(this Lead lead) => new(
        lead.Id,
        lead.FirstName,
        lead.LastName,
        lead.Email,
        lead.Status.ToString(),
        lead.EstimatedValue.Amount,
        lead.EstimatedValue.Currency,
        lead.AssignedAgentId,
        lead.CreatedAt,
        lead.UpdatedAt);
}

// ── Commands ──────────────────────────────────────────────────────────────────

namespace BankingCRM.Application.Commands;

using BankingCRM.Application.DTOs;
using BankingCRM.Application.Mapping;
using BankingCRM.Domain.Entities;
using BankingCRM.Domain.Repositories;
using BankingCRM.Domain.ValueObjects;
using FluentValidation;
using MediatR;

// Create Lead
public sealed record CreateLeadCommand(
    string FirstName, string LastName, string Email,
    decimal EstimatedValue, string Currency, string? Phone)
    : IRequest<LeadDto>;

public sealed class CreateLeadCommandValidator : AbstractValidator<CreateLeadCommand>
{
    public CreateLeadCommandValidator()
    {
        RuleFor(x => x.FirstName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.LastName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.EstimatedValue).GreaterThan(0);
        RuleFor(x => x.Currency).Length(3);
    }
}

public sealed class CreateLeadCommandHandler(IUnitOfWork uow)
    : IRequestHandler<CreateLeadCommand, LeadDto>
{
    public async Task<LeadDto> Handle(CreateLeadCommand cmd, CancellationToken ct)
    {
        var lead = Lead.Create(
            cmd.FirstName,
            cmd.LastName,
            new Email(cmd.Email),
            new Money(cmd.EstimatedValue, cmd.Currency),
            cmd.Phone is null ? null : new PhoneNumber(cmd.Phone));

        uow.Leads.Add(lead);
        await uow.CommitAsync(ct);
        return lead.ToDto();
    }
}

// Assign Lead
public sealed record AssignLeadCommand(Guid LeadId, Guid AgentId) : IRequest<LeadDto>;

public sealed class AssignLeadCommandHandler(IUnitOfWork uow)
    : IRequestHandler<AssignLeadCommand, LeadDto>
{
    public async Task<LeadDto> Handle(AssignLeadCommand cmd, CancellationToken ct)
    {
        var lead = await uow.Leads.GetByIdAsync(cmd.LeadId, ct)
            ?? throw new KeyNotFoundException($"Lead {cmd.LeadId} not found.");

        lead.AssignToAgent(cmd.AgentId);
        await uow.CommitAsync(ct);
        return lead.ToDto();
    }
}

// ── Queries ───────────────────────────────────────────────────────────────────

namespace BankingCRM.Application.Queries;

using BankingCRM.Application.DTOs;
using BankingCRM.Application.Mapping;
using BankingCRM.Domain.Repositories;
using MediatR;

public sealed record GetLeadQuery(Guid Id) : IRequest<LeadDto?>;

public sealed class GetLeadQueryHandler(IUnitOfWork uow)
    : IRequestHandler<GetLeadQuery, LeadDto?>
{
    public async Task<LeadDto?> Handle(GetLeadQuery q, CancellationToken ct)
    {
        var lead = await uow.Leads.GetByIdAsync(q.Id, ct);
        return lead?.ToDto();
    }
}

// ── Pipeline Behaviours ───────────────────────────────────────────────────────

namespace BankingCRM.Application.Behaviours;

using FluentValidation;
using MediatR;
using Microsoft.Extensions.Logging;

/// <summary>Validates every command/query before it reaches the handler.</summary>
public sealed class ValidationBehaviour<TRequest, TResponse>(
    IEnumerable<IValidator<TRequest>> validators,
    ILogger<ValidationBehaviour<TRequest, TResponse>> logger)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        if (!validators.Any()) return await next(ct);

        var context = new ValidationContext<TRequest>(request);
        var failures = validators
            .Select(v => v.Validate(context))
            .SelectMany(r => r.Errors)
            .Where(f => f is not null)
            .ToList();

        if (failures.Count > 0)
        {
            logger.LogWarning("Validation failed for {Request}: {Errors}",
                typeof(TRequest).Name, string.Join("; ", failures.Select(f => f.ErrorMessage)));
            throw new ValidationException(failures);
        }

        return await next(ct);
    }
}

/// <summary>Structured logging around every MediatR request.</summary>
public sealed class LoggingBehaviour<TRequest, TResponse>(
    ILogger<LoggingBehaviour<TRequest, TResponse>> logger)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        var name = typeof(TRequest).Name;
        logger.LogInformation("→ Handling {Request}", name);
        var sw = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            var response = await next(ct);
            logger.LogInformation("← Handled {Request} in {Elapsed}ms", name, sw.ElapsedMilliseconds);
            return response;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "✗ {Request} failed after {Elapsed}ms", name, sw.ElapsedMilliseconds);
            throw;
        }
    }
}

// ── LeadDistributionService ───────────────────────────────────────────────────

namespace BankingCRM.Application.Services;

using BankingCRM.Domain.Repositories;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Diagnostics.Metrics;

/// <summary>
///  Distributes unassigned leads to available agents during high-concurrency bursts.
///
///  Design decisions
///  ────────────────
///  • SemaphoreSlim(maxConcurrent)  — caps the number of goroutine-like tasks
///    that can hit the DB at once, preventing CPU spikes from thundering herds.
///  • IDbContextFactory is injected into the repository via Infrastructure;
///    this service only depends on the domain interface (Application layer stays clean).
///  • Backpressure: tasks beyond the semaphore threshold queue and are released
///    as slots free up — no work is dropped, just rate-limited.
///  • OpenTelemetry Activity + Meter instruments every batch for tracing/metrics.
/// </summary>
public sealed class LeadDistributionService(
    IUnitOfWork uow,
    ILogger<LeadDistributionService> logger,
    IMeterFactory meterFactory)
    : BackgroundService
{
    // ── Concurrency knob ─────────────────────────────────────────────────────
    //   Allow at most 4 concurrent DB "fetch + assign" operations.
    //   Tune based on SQL Server connection pool size and CPU profile.
    private const int MaxConcurrentDbOps = 4;
    private const int BatchSize          = 20;
    private const int PollingIntervalMs  = 5_000;

    private readonly SemaphoreSlim _throttle = new(MaxConcurrentDbOps, MaxConcurrentDbOps);

    // ── OTel instruments ─────────────────────────────────────────────────────
    private static readonly ActivitySource ActivitySource =
        new("BankingCRM.LeadDistribution", "1.0.0");

    private readonly Meter   _meter             = meterFactory.Create("BankingCRM.LeadDistribution");
    private          Counter<long>? _assigned;
    private          Histogram<double>? _batchDuration;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _assigned      = _meter.CreateCounter<long>("leads.assigned.total",   "leads",  "Total leads assigned");
        _batchDuration = _meter.CreateHistogram<double>("leads.batch.duration", "ms",   "Distribution batch duration");

        logger.LogInformation(
            "LeadDistributionService started. Throttle={Max}, Batch={Batch}",
            MaxConcurrentDbOps, BatchSize);

        while (!stoppingToken.IsCancellationRequested)
        {
            await RunDistributionBatchAsync(stoppingToken);
            await Task.Delay(PollingIntervalMs, stoppingToken);
        }
    }

    private async Task RunDistributionBatchAsync(CancellationToken ct)
    {
        using var activity = ActivitySource.StartActivity("LeadDistribution.Batch");

        var sw = Stopwatch.StartNew();
        try
        {
            var unassigned = await uow.Leads.GetUnassignedAsync(BatchSize, ct);
            activity?.SetTag("leads.found", unassigned.Count);

            if (unassigned.Count == 0)
            {
                logger.LogDebug("No unassigned leads in this cycle.");
                return;
            }

            // Fan out with bounded concurrency via SemaphoreSlim
            var tasks = unassigned.Select(lead => AssignWithThrottleAsync(lead.Id, ct));
            await Task.WhenAll(tasks);

            _batchDuration?.Record(sw.Elapsed.TotalMilliseconds);
        }
        catch (OperationCanceledException) { /* graceful shutdown */ }
        catch (Exception ex)
        {
            logger.LogError(ex, "Distribution batch failed.");
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
        }
    }

    /// <summary>
    ///  Each lead assignment acquires a semaphore slot before touching the DB.
    ///  This is the primary CPU-spike throttle under burst conditions.
    /// </summary>
    private async Task AssignWithThrottleAsync(Guid leadId, CancellationToken ct)
    {
        await _throttle.WaitAsync(ct);           // ← blocks if MaxConcurrentDbOps reached
        try
        {
            using var activity = ActivitySource.StartActivity("LeadDistribution.AssignLead");
            activity?.SetTag("lead.id", leadId);

            // In a real system, fetch next available agent from an AgentPool service.
            var agentId = await ResolveNextAvailableAgentAsync(ct);
            if (agentId is null)
            {
                logger.LogWarning("No agents available; lead {LeadId} skipped.", leadId);
                return;
            }

            var lead = await uow.Leads.GetByIdAsync(leadId, ct);
            if (lead is null) return;

            lead.AssignToAgent(agentId.Value);
            await uow.CommitAsync(ct);

            _assigned?.Add(1);
            logger.LogInformation("Lead {LeadId} assigned to agent {AgentId}.", leadId, agentId);
        }
        finally
        {
            _throttle.Release();                  // ← always release, even on exception
        }
    }

    /// <summary>Stub — replace with round-robin / skill-based agent resolver.</summary>
    private static Task<Guid?> ResolveNextAvailableAgentAsync(CancellationToken _)
        => Task.FromResult<Guid?>(Guid.NewGuid()); // placeholder

    public override void Dispose()
    {
        _throttle.Dispose();
        _meter.Dispose();
        base.Dispose();
    }
}

// ── DI Registration ───────────────────────────────────────────────────────────

namespace BankingCRM.Application;

using BankingCRM.Application.Behaviours;
using BankingCRM.Application.Services;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

public static class ApplicationServiceExtensions
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        var assembly = Assembly.GetExecutingAssembly();

        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(assembly);
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(LoggingBehaviour<,>));
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));
        });

        services.AddValidatorsFromAssembly(assembly);
        services.AddHostedService<LeadDistributionService>();

        return services;
    }
}
