// =============================================================
//  BankingCRM.Domain  —  Entities, Value Objects, Domain Events
// =============================================================

namespace BankingCRM.Domain.Common;

/// <summary>Base class for all Aggregate Roots.</summary>
public abstract class AggregateRoot
{
    private readonly List<IDomainEvent> _domainEvents = [];

    public Guid Id { get; protected init; } = Guid.CreateVersion7();
    public DateTimeOffset CreatedAt { get; protected init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? UpdatedAt { get; protected set; }

    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    protected void AddDomainEvent(IDomainEvent @event) => _domainEvents.Add(@event);
    public void ClearDomainEvents() => _domainEvents.Clear();
}

/// <summary>Marker interface — domain events are dispatched after DB commit.</summary>
public interface IDomainEvent;

// ── Value Objects ─────────────────────────────────────────────────────────────

namespace BankingCRM.Domain.ValueObjects;

public sealed record Money(decimal Amount, string Currency)
{
    public static Money Zero(string currency = "USD") => new(0m, currency);

    public Money Add(Money other)
    {
        if (Currency != other.Currency)
            throw new InvalidOperationException($"Currency mismatch: {Currency} vs {other.Currency}");
        return this with { Amount = Amount + other.Amount };
    }
}

public sealed record Email
{
    public string Value { get; }

    public Email(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || !value.Contains('@'))
            throw new ArgumentException("Invalid email address.", nameof(value));
        Value = value.Trim().ToLowerInvariant();
    }

    public static implicit operator string(Email e) => e.Value;
    public override string ToString() => Value;
}

public sealed record PhoneNumber
{
    public string Value { get; }

    public PhoneNumber(string value)
    {
        var digits = new string(value.Where(char.IsDigit).ToArray());
        if (digits.Length is < 7 or > 15)
            throw new ArgumentException("Invalid phone number.", nameof(value));
        Value = digits;
    }

    public override string ToString() => Value;
}

// ── Lead Aggregate ────────────────────────────────────────────────────────────

namespace BankingCRM.Domain.Entities;

using BankingCRM.Domain.Common;
using BankingCRM.Domain.Enums;
using BankingCRM.Domain.Events;
using BankingCRM.Domain.ValueObjects;

public sealed class Lead : AggregateRoot
{
    private Lead() { } // EF Core

    public string FirstName { get; private set; } = default!;
    public string LastName  { get; private set; } = default!;
    public Email  Email     { get; private set; } = default!;
    public PhoneNumber? Phone { get; private set; }
    public LeadStatus Status { get; private set; } = LeadStatus.New;
    public Money EstimatedValue { get; private set; } = Money.Zero();
    public Guid? AssignedAgentId { get; private set; }
    public string? Notes { get; private set; }
    public byte[] RowVersion { get; private set; } = default!; // Optimistic concurrency

    public static Lead Create(
        string firstName,
        string lastName,
        Email email,
        Money estimatedValue,
        PhoneNumber? phone = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(firstName);
        ArgumentException.ThrowIfNullOrWhiteSpace(lastName);

        var lead = new Lead
        {
            FirstName      = firstName,
            LastName       = lastName,
            Email          = email,
            EstimatedValue = estimatedValue,
            Phone          = phone,
        };

        lead.AddDomainEvent(new LeadCreatedEvent(lead.Id, email));
        return lead;
    }

    public void AssignToAgent(Guid agentId)
    {
        if (Status == LeadStatus.Closed)
            throw new InvalidOperationException("Cannot assign a closed lead.");

        AssignedAgentId = agentId;
        Status          = LeadStatus.Assigned;
        UpdatedAt       = DateTimeOffset.UtcNow;

        AddDomainEvent(new LeadAssignedEvent(Id, agentId));
    }

    public void UpdateNotes(string notes)
    {
        Notes     = notes;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void Close()
    {
        Status    = LeadStatus.Closed;
        UpdatedAt = DateTimeOffset.UtcNow;
        AddDomainEvent(new LeadClosedEvent(Id));
    }
}

// ── Enums ─────────────────────────────────────────────────────────────────────

namespace BankingCRM.Domain.Enums;

public enum LeadStatus { New, Assigned, InProgress, Closed }

// ── Domain Events ─────────────────────────────────────────────────────────────

namespace BankingCRM.Domain.Events;

using BankingCRM.Domain.Common;
using BankingCRM.Domain.ValueObjects;

public sealed record LeadCreatedEvent(Guid LeadId, Email Email)  : IDomainEvent;
public sealed record LeadAssignedEvent(Guid LeadId, Guid AgentId) : IDomainEvent;
public sealed record LeadClosedEvent(Guid LeadId)                 : IDomainEvent;

// ── Repository Interfaces (Dependency Inversion) ──────────────────────────────

namespace BankingCRM.Domain.Repositories;

using BankingCRM.Domain.Entities;
using BankingCRM.Domain.Enums;

public interface ILeadRepository
{
    Task<Lead?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<Lead>> GetUnassignedAsync(int maxCount, CancellationToken ct = default);
    void Add(Lead lead);
    void Update(Lead lead);
    Task<int> SaveChangesAsync(CancellationToken ct = default);
}

public interface IUnitOfWork
{
    ILeadRepository Leads { get; }
    Task<int> CommitAsync(CancellationToken ct = default);
}
