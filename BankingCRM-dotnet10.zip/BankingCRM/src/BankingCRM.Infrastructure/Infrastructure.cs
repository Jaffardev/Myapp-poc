// =============================================================
//  BankingCRM.Infrastructure
//  EF Core, Pooled DbContext Factory, Repository, UoW, OTel
// =============================================================

// ── EF Core DbContext ─────────────────────────────────────────────────────────

namespace BankingCRM.Infrastructure.Persistence;

using BankingCRM.Domain.Entities;
using BankingCRM.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

/// <summary>
///  The DbContext is intentionally lean — no constructor injection of heavy services.
///  IDbContextFactory (pooled) creates and returns contexts from a pool, avoiding
///  the overhead of opening a new SQL connection on every request.
/// </summary>
public sealed class BankingCrmDbContext(DbContextOptions<BankingCrmDbContext> options)
    : DbContext(options)
{
    public DbSet<Lead> Leads => Set<Lead>();

    protected override void OnModelCreating(ModelBuilder model)
    {
        // ── Lead ──────────────────────────────────────────────────────────────
        model.Entity<Lead>(b =>
        {
            b.ToTable("Leads", "crm");
            b.HasKey(l => l.Id);

            b.Property(l => l.Id)
             .ValueGeneratedNever(); // Guid.CreateVersion7() in domain

            // Value object: Email — stored as varchar
            b.Property(l => l.Email)
             .HasConversion(
                 e => e.Value,
                 v => new Email(v))
             .HasMaxLength(320)
             .IsRequired();

            // Value object: PhoneNumber
            b.Property(l => l.Phone)
             .HasConversion(
                 p => p == null ? null : p.Value,
                 v => v == null ? null : new PhoneNumber(v))
             .HasMaxLength(20);

            // Owned entity: Money (stored as two columns)
            b.OwnsOne(l => l.EstimatedValue, m =>
            {
                m.Property(x => x.Amount).HasColumnName("EstimatedAmount")
                 .HasPrecision(18, 4).IsRequired();
                m.Property(x => x.Currency).HasColumnName("EstimatedCurrency")
                 .HasMaxLength(3).IsRequired();
            });

            b.Property(l => l.FirstName).HasMaxLength(100).IsRequired();
            b.Property(l => l.LastName).HasMaxLength(100).IsRequired();
            b.Property(l => l.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(l => l.Notes).HasMaxLength(4000);

            // Optimistic concurrency token
            b.Property(l => l.RowVersion)
             .IsRowVersion()
             .IsConcurrencyToken();

            // Indexes
            b.HasIndex(l => l.Email).IsUnique();
            b.HasIndex(l => l.Status);
            b.HasIndex(l => l.AssignedAgentId);
        });

        base.OnModelCreating(model);
    }
}

// ── Repository ────────────────────────────────────────────────────────────────

namespace BankingCRM.Infrastructure.Persistence.Repositories;

using BankingCRM.Domain.Entities;
using BankingCRM.Domain.Enums;
using BankingCRM.Domain.Repositories;
using Microsoft.EntityFrameworkCore;

/// <summary>
///  Uses a pre-resolved DbContext (injected by the UoW), NOT IDbContextFactory directly.
///  The factory is used at the UoW / service scope boundary instead — this keeps the
///  repository simple and testable.
/// </summary>
public sealed class LeadRepository(BankingCrmDbContext context) : ILeadRepository
{
    public Task<Lead?> GetByIdAsync(Guid id, CancellationToken ct)
        => context.Leads.FirstOrDefaultAsync(l => l.Id == id, ct);

    public Task<IReadOnlyList<Lead>> GetUnassignedAsync(int maxCount, CancellationToken ct)
        => context.Leads
                  .Where(l => l.Status == LeadStatus.New)
                  .OrderBy(l => l.CreatedAt)
                  .Take(maxCount)
                  .ToListAsync(ct)
                  .ContinueWith<IReadOnlyList<Lead>>(t => t.Result, ct);

    public void Add(Lead lead)    => context.Leads.Add(lead);
    public void Update(Lead lead) => context.Leads.Update(lead);

    public Task<int> SaveChangesAsync(CancellationToken ct)
        => context.SaveChangesAsync(ct);
}

// ── Unit of Work ──────────────────────────────────────────────────────────────

namespace BankingCRM.Infrastructure.Persistence;

using BankingCRM.Domain.Common;
using BankingCRM.Domain.Repositories;
using BankingCRM.Infrastructure.Persistence.Repositories;
using MediatR;
using Microsoft.EntityFrameworkCore;

/// <summary>
///  The UoW resolves a context from the pool via IDbContextFactory.
///  This is the correct pattern for high-concurrency: one pooled context
///  per logical unit of work (HTTP request / background task), not one
///  per service lifetime.
/// </summary>
public sealed class UnitOfWork : IUnitOfWork, IAsyncDisposable
{
    private readonly BankingCrmDbContext _context;
    private readonly IMediator           _mediator;

    // Lazy-init repositories
    private ILeadRepository? _leads;
    public ILeadRepository Leads => _leads ??= new LeadRepository(_context);

    public UnitOfWork(
        IDbContextFactory<BankingCrmDbContext> factory,
        IMediator mediator)
    {
        _context  = factory.CreateDbContext(); // ← from the pool
        _mediator = mediator;
    }

    public async Task<int> CommitAsync(CancellationToken ct = default)
    {
        // Dispatch domain events before saving (can also do after — your call)
        var aggregates = _context.ChangeTracker
            .Entries<AggregateRoot>()
            .Select(e => e.Entity)
            .Where(a => a.DomainEvents.Count > 0)
            .ToList();

        var events = aggregates.SelectMany(a => a.DomainEvents).ToList();
        aggregates.ForEach(a => a.ClearDomainEvents());

        var result = await _context.SaveChangesAsync(ct);

        foreach (var @event in events)
            await _mediator.Publish((INotification)@event, ct);

        return result;
    }

    public async ValueTask DisposeAsync()
    {
        await _context.DisposeAsync(); // returns context to pool
    }
}

// ── DI Registration ───────────────────────────────────────────────────────────

namespace BankingCRM.Infrastructure;

using BankingCRM.Domain.Repositories;
using BankingCRM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public static class InfrastructureServiceExtensions
{
    public static IServiceCollection AddInfrastructureServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("SqlServer")
            ?? throw new InvalidOperationException("ConnectionStrings:SqlServer is required.");

        // ── Pooled DbContext Factory ──────────────────────────────────────────
        //  AddPooledDbContextFactory maintains an internal pool of DbContext instances.
        //  Each call to IDbContextFactory<T>.CreateDbContext() retrieves an already-
        //  initialized instance (with compiled model, interceptors wired) from the pool
        //  instead of constructing a new one — dramatically reducing allocations under load.
        //
        //  Pool size is bounded by the SQL Server connection pool (default: 100).
        //  Set poolSize to match your MaxPoolSize connection-string setting.
        services.AddPooledDbContextFactory<BankingCrmDbContext>(
            options => options
                .UseSqlServer(connectionString, sql =>
                {
                    sql.EnableRetryOnFailure(maxRetryCount: 5,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null);
                    sql.CommandTimeout(30);
                    sql.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
                })
                .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTrackingWithIdentityResolution),
            poolSize: 128);

        // UoW is scoped — one per HTTP request or background task scope
        services.AddScoped<IUnitOfWork, UnitOfWork>();

        return services;
    }
}
