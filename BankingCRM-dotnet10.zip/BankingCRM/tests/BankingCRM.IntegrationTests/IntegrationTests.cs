// =============================================================
//  BankingCRM.IntegrationTests
//  Tests the full HTTP pipeline: routing → MediatR → EF Core.
//  Uses WebApplicationFactory with an in-memory SQLite substitute
//  so no real SQL Server is needed in CI.
// =============================================================

namespace BankingCRM.IntegrationTests.Api;

using BankingCRM.Application.DTOs;
using BankingCRM.Infrastructure.Persistence;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

// ── Test WebApplication Factory ───────────────────────────────────────────────

/// <summary>
///  Overrides the SQL Server DbContext factory with an in-memory SQLite one.
///  This keeps integration tests self-contained and fast.
/// </summary>
public sealed class CrmApiFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureServices(services =>
        {
            // Remove the real pooled SQL Server factory
            services.RemoveAll<IDbContextFactory<BankingCrmDbContext>>();
            services.RemoveAll<DbContextOptions<BankingCrmDbContext>>();

            // Replace with SQLite in-memory (unique DB per test run)
            var dbName = $"CrmTest_{Guid.NewGuid():N}";
            services.AddPooledDbContextFactory<BankingCrmDbContext>(opts =>
                opts.UseSqlite($"DataSource={dbName};Mode=Memory;Cache=Shared")
                    .EnableSensitiveDataLogging());

            // Ensure schema is created
            var sp = services.BuildServiceProvider();
            using var scope = sp.CreateScope();
            var factory = scope.ServiceProvider
                .GetRequiredService<IDbContextFactory<BankingCrmDbContext>>();
            using var ctx = factory.CreateDbContext();
            ctx.Database.EnsureCreated();
        });
    }
}

// ── Fixture ───────────────────────────────────────────────────────────────────

public sealed class LeadApiTests(CrmApiFactory factory)
    : IClassFixture<CrmApiFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    // Reuse the source-generated context for deserialization
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        TypeInfoResolver       = BankingCrmJsonContext.Default,
        PropertyNameCaseInsensitive = true,
    };

    // ── POST /api/v1/leads ────────────────────────────────────────────────────

    [Fact]
    public async Task CreateLead_Returns201_WithLeadDto()
    {
        var req = new CreateLeadRequest(
            "Alice", "Smith", "alice@bank.com", 75_000m, "USD", "+1 555 000 1234");

        var resp = await _client.PostAsJsonAsync(
            "/api/v1/leads", req, BankingCrmJsonContext.Default.CreateLeadRequest);

        Assert.Equal(HttpStatusCode.Created, resp.StatusCode);

        var body = await resp.Content.ReadFromJsonAsync<LeadDto>(JsonOpts);
        Assert.NotNull(body);
        Assert.Equal("Alice",           body!.FirstName);
        Assert.Equal("New",             body.Status);
        Assert.Equal(75_000m,           body.EstimatedValue);
        Assert.NotEqual(Guid.Empty,     body.Id);
        Assert.NotNull(resp.Headers.Location);
    }

    [Fact]
    public async Task CreateLead_Returns400_WhenValidationFails()
    {
        var bad = new CreateLeadRequest("", "", "not-an-email", -1m, "XX");

        var resp = await _client.PostAsJsonAsync(
            "/api/v1/leads", bad, BankingCrmJsonContext.Default.CreateLeadRequest);

        Assert.Equal(HttpStatusCode.BadRequest, resp.StatusCode);

        var problem = await resp.Content.ReadFromJsonAsync<ProblemDetails>(JsonOpts);
        Assert.Equal(400, problem?.Status);
    }

    // ── GET /api/v1/leads/{id} ────────────────────────────────────────────────

    [Fact]
    public async Task GetLead_Returns200_ForExistingLead()
    {
        // Arrange — create first
        var created = await CreateLeadAndGetDto("bob@bank.com");

        // Act
        var resp = await _client.GetAsync($"/api/v1/leads/{created.Id}");

        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        var dto = await resp.Content.ReadFromJsonAsync<LeadDto>(JsonOpts);
        Assert.Equal(created.Id, dto!.Id);
    }

    [Fact]
    public async Task GetLead_Returns404_ForUnknownId()
    {
        var resp = await _client.GetAsync($"/api/v1/leads/{Guid.NewGuid()}");
        Assert.Equal(HttpStatusCode.NotFound, resp.StatusCode);
    }

    // ── PUT /api/v1/leads/{id}/assign ─────────────────────────────────────────

    [Fact]
    public async Task AssignLead_Returns200_WithAssignedStatus()
    {
        var created = await CreateLeadAndGetDto("carol@bank.com");
        var agentId = Guid.NewGuid();

        var resp = await _client.PutAsJsonAsync(
            $"/api/v1/leads/{created.Id}/assign",
            new AssignLeadRequest(agentId),
            BankingCrmJsonContext.Default.AssignLeadRequest);

        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        var dto = await resp.Content.ReadFromJsonAsync<LeadDto>(JsonOpts);
        Assert.Equal("Assigned", dto!.Status);
        Assert.Equal(agentId,    dto.AssignedAgentId);
    }

    [Fact]
    public async Task AssignLead_Returns404_ForMissingLead()
    {
        var resp = await _client.PutAsJsonAsync(
            $"/api/v1/leads/{Guid.NewGuid()}/assign",
            new AssignLeadRequest(Guid.NewGuid()),
            BankingCrmJsonContext.Default.AssignLeadRequest);

        Assert.Equal(HttpStatusCode.NotFound, resp.StatusCode);
    }

    // ── Health ────────────────────────────────────────────────────────────────

    [Fact]
    public async Task Health_ReturnsOk()
    {
        var resp = await _client.GetAsync("/health");
        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
    }

    [Fact]
    public async Task Ping_ReturnsOk()
    {
        var resp = await _client.GetAsync("/api/v1/ping");
        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private async Task<LeadDto> CreateLeadAndGetDto(string email)
    {
        var req  = new CreateLeadRequest("Test", "User", email, 10_000m, "USD");
        var resp = await _client.PostAsJsonAsync(
            "/api/v1/leads", req, BankingCrmJsonContext.Default.CreateLeadRequest);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<LeadDto>(JsonOpts))!;
    }
}

// Minimal ProblemDetails record (avoid taking a dep on ASP.NET Core in test project)
file sealed record ProblemDetails(int? Status, string? Title, string? Detail);
