// =============================================================
//  BankingCRM.UnitTests
//  Tests: Lead aggregate, SemaphoreSlim throttle behaviour,
//         ValidationBehaviour pipeline, LeadMapper
// =============================================================

// ── Lead Aggregate Tests ──────────────────────────────────────────────────────

namespace BankingCRM.UnitTests.Domain;

using BankingCRM.Domain.Entities;
using BankingCRM.Domain.Enums;
using BankingCRM.Domain.Events;
using BankingCRM.Domain.ValueObjects;
using Xunit;

public sealed class LeadAggregateTests
{
    private static Lead BuildLead(string email = "jane@bank.com") =>
        Lead.Create("Jane", "Doe", new Email(email), new Money(50_000m, "USD"));

    [Fact]
    public void Create_SetsDefaultStatus_New()
    {
        var lead = BuildLead();
        Assert.Equal(LeadStatus.New, lead.Status);
    }

    [Fact]
    public void Create_RaisesLeadCreatedEvent()
    {
        var lead = BuildLead();
        Assert.Single(lead.DomainEvents);
        Assert.IsType<LeadCreatedEvent>(lead.DomainEvents.First());
    }

    [Fact]
    public void AssignToAgent_ChangesStatusToAssigned()
    {
        var lead    = BuildLead();
        var agentId = Guid.NewGuid();

        lead.AssignToAgent(agentId);

        Assert.Equal(LeadStatus.Assigned, lead.Status);
        Assert.Equal(agentId, lead.AssignedAgentId);
    }

    [Fact]
    public void AssignToAgent_RaisesLeadAssignedEvent()
    {
        var lead = BuildLead();
        lead.ClearDomainEvents();
        lead.AssignToAgent(Guid.NewGuid());

        var evt = Assert.Single(lead.DomainEvents);
        Assert.IsType<LeadAssignedEvent>(evt);
    }

    [Fact]
    public void AssignToAgent_ThrowsWhenLeadIsClosed()
    {
        var lead = BuildLead();
        lead.Close();

        Assert.Throws<InvalidOperationException>(() => lead.AssignToAgent(Guid.NewGuid()));
    }

    [Fact]
    public void Close_SetsStatusToClosed_AndRaisesEvent()
    {
        var lead = BuildLead();
        lead.ClearDomainEvents();
        lead.Close();

        Assert.Equal(LeadStatus.Closed, lead.Status);
        Assert.IsType<LeadClosedEvent>(lead.DomainEvents.Single());
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("notanemail")]
    public void Email_ValueObject_ThrowsOnInvalidInput(string bad)
    {
        Assert.Throws<ArgumentException>(() => new Email(bad));
    }

    [Theory]
    [InlineData("123")]          // too short
    [InlineData("1234567890123456")] // too long (>15 digits)
    public void PhoneNumber_ValueObject_ThrowsOnInvalidInput(string bad)
    {
        Assert.Throws<ArgumentException>(() => new PhoneNumber(bad));
    }

    [Fact]
    public void Money_Add_ThrowsOnCurrencyMismatch()
    {
        var usd = new Money(100m, "USD");
        var eur = new Money(100m, "EUR");
        Assert.Throws<InvalidOperationException>(() => usd.Add(eur));
    }
}

// ── SemaphoreSlim Throttle Behaviour Tests ────────────────────────────────────

namespace BankingCRM.UnitTests.Application;

using System.Collections.Concurrent;
using System.Diagnostics;
using Xunit;

/// <summary>
///  Verifies that the SemaphoreSlim throttle pattern used inside
///  LeadDistributionService correctly limits concurrency without
///  dropping work or deadlocking.
/// </summary>
public sealed class SemaphoreThrottleTests
{
    /// <summary>
    ///  Simulates the exact pattern from LeadDistributionService:
    ///  fan out N tasks, limit concurrency to MaxSlots, ensure all
    ///  tasks complete and the observed peak concurrency never exceeds the cap.
    /// </summary>
    [Theory]
    [InlineData(20, 4)]   // 20 leads, 4 concurrent DB slots
    [InlineData(50, 8)]
    [InlineData(1,  4)]   // fewer tasks than slots
    public async Task Throttle_NeverExceedsMaxConcurrency(int taskCount, int maxSlots)
    {
        var semaphore       = new SemaphoreSlim(maxSlots, maxSlots);
        var concurrentCount = 0;
        var peakConcurrent  = 0;
        var completed       = new ConcurrentBag<int>();
        var lockObj         = new object();

        async Task SimulateDbWork(int id)
        {
            await semaphore.WaitAsync();
            try
            {
                var current = Interlocked.Increment(ref concurrentCount);
                lock (lockObj) peakConcurrent = Math.Max(peakConcurrent, current);

                await Task.Delay(10); // simulate DB latency

                completed.Add(id);
            }
            finally
            {
                Interlocked.Decrement(ref concurrentCount);
                semaphore.Release();
            }
        }

        var tasks = Enumerable.Range(0, taskCount).Select(SimulateDbWork);
        await Task.WhenAll(tasks);

        Assert.Equal(taskCount, completed.Count);
        Assert.True(peakConcurrent <= maxSlots,
            $"Peak concurrency {peakConcurrent} exceeded max slots {maxSlots}");
    }

    [Fact]
    public async Task Throttle_ReleasesSlotEvenOnException()
    {
        var semaphore  = new SemaphoreSlim(1, 1);
        var faultCount = 0;

        async Task FaultyWork()
        {
            await semaphore.WaitAsync();
            try
            {
                await Task.Delay(5);
                throw new InvalidOperationException("Simulated DB failure");
            }
            finally
            {
                semaphore.Release();
            }
        }

        // Run 3 tasks that all throw; semaphore must remain usable
        for (var i = 0; i < 3; i++)
        {
            try { await FaultyWork(); }
            catch (InvalidOperationException) { faultCount++; }
        }

        Assert.Equal(3, faultCount);
        // Semaphore should still have its initial count available
        Assert.Equal(1, semaphore.CurrentCount);
    }

    [Fact]
    public async Task Throttle_CancellationPropagatesCorrectly()
    {
        var semaphore = new SemaphoreSlim(1, 1);
        using var cts = new CancellationTokenSource();

        // Occupy the only slot
        await semaphore.WaitAsync();

        // This task should be cancelled while waiting
        var waitTask = semaphore.WaitAsync(cts.Token);
        cts.Cancel();

        await Assert.ThrowsAnyAsync<OperationCanceledException>(
            async () => await waitTask);

        // Slot still held by first acquire; release it
        semaphore.Release();
        Assert.Equal(1, semaphore.CurrentCount);
    }
}

// ── Validation Behaviour Tests ────────────────────────────────────────────────

namespace BankingCRM.UnitTests.Application;

using BankingCRM.Application.Behaviours;
using BankingCRM.Application.Commands;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

public sealed class ValidationBehaviourTests
{
    private static ValidationBehaviour<CreateLeadCommand, LeadDto> BuildBehaviour(
        params IValidator<CreateLeadCommand>[] validators)
        => new(validators, NullLogger<ValidationBehaviour<CreateLeadCommand, LeadDto>>.Instance);

    [Fact]
    public async Task Handle_PassesThrough_WhenNoValidators()
    {
        var behaviour = BuildBehaviour();
        var called    = false;

        RequestHandlerDelegate<LeadDto> next = (_) =>
        {
            called = true;
            return Task.FromResult(new LeadDto(Guid.NewGuid(), "A", "B", "a@b.com",
                "New", 1000m, "USD", null, DateTimeOffset.UtcNow, null));
        };

        await behaviour.Handle(ValidCommand(), next, CancellationToken.None);
        Assert.True(called);
    }

    [Fact]
    public async Task Handle_ThrowsValidationException_WhenRuleFails()
    {
        var behaviour = BuildBehaviour(new CreateLeadCommandValidator());

        RequestHandlerDelegate<LeadDto> next = (_) =>
            Task.FromResult<LeadDto>(null!);

        var badCmd = new CreateLeadCommand("", "", "not-an-email", -1m, "XX", null);

        await Assert.ThrowsAsync<ValidationException>(
            () => behaviour.Handle(badCmd, next, CancellationToken.None));
    }

    [Fact]
    public async Task Handle_DoesNotCallNext_WhenValidationFails()
    {
        var behaviour = BuildBehaviour(new CreateLeadCommandValidator());
        var called    = false;

        RequestHandlerDelegate<LeadDto> next = (_) =>
        {
            called = true;
            return Task.FromResult<LeadDto>(null!);
        };

        var badCmd = new CreateLeadCommand("", "", "bad", -1m, "XX", null);

        try { await behaviour.Handle(badCmd, next, CancellationToken.None); }
        catch (ValidationException) { }

        Assert.False(called);
    }

    private static CreateLeadCommand ValidCommand() =>
        new("Jane", "Doe", "jane@bank.com", 50_000m, "USD", null);
}

// Import needed for LeadDto reference in tests above
using BankingCRM.Application.DTOs;
