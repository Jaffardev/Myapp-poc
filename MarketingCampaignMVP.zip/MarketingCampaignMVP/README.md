# Marketing Campaign & Call Center Management System - MVP

## 🏗️ Solution Structure

```
MarketingCampaign.sln
│
├── src/
│   ├── MarketingCampaign.Domain/              # Core business entities
│   ├── MarketingCampaign.Application/          # Application services, DTOs
│   ├── MarketingCampaign.Infrastructure/       # EF Core, Repositories
│   ├── MarketingCampaign.API/                  # ASP.NET Core Web API
│   └── MarketingCampaign.BlazorWasm/          # Blazor WebAssembly UI
│
└── docs/
    └── database-schema.md
```

## 🎯 Architecture

- **Clean Architecture** with clear separation of concerns
- **ABP-style layering**: Domain → Application → Infrastructure → API
- **Repository Pattern** via EF Core
- **DTO Pattern** for API communication
- **Blazor WASM** client communicating via HTTP API only

## 🗄️ Tech Stack

### Backend
- .NET 8+ (ready for .NET 10)
- ASP.NET Core Web API
- Entity Framework Core
- PostgreSQL

### Frontend
- Blazor WebAssembly
- Bootstrap 5
- HttpClient for API communication

## 📦 Core Modules

1. **Campaign Management** - Create and manage marketing campaigns
2. **Product Management** - Manage products and link to campaigns
3. **Target Customer Lists** - Upload and manage customer data
4. **Call Center (Lead Assignment)** - Distribute customers to agents
5. **Follow-Up Tracking** - Track contact status and notes
6. **Sales Handoff** - Forward interested leads to sales

## 🚀 Getting Started

### Prerequisites
- .NET 8 SDK or later
- PostgreSQL 14+
- Node.js (for Blazor WASM tooling)

### Database Setup

1. Update connection string in `appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Host=localhost;Database=MarketingCampaignDB;Username=postgres;Password=yourpassword"
}
```

2. Run migrations:
```bash
cd src/MarketingCampaign.API
dotnet ef database update
```

### Running the Application

1. Start the API:
```bash
cd src/MarketingCampaign.API
dotnet run
```

2. Start the Blazor WASM app:
```bash
cd src/MarketingCampaign.BlazorWasm
dotnet run
```

3. Navigate to `https://localhost:5001` for the Blazor UI
4. API Swagger documentation at `https://localhost:7001/swagger`

## 📝 MVP Scope

### ✅ Included in MVP
- Campaign CRUD operations
- Product management
- Customer target list management
- Agent assignment and distribution
- Contact status tracking
- Basic lead handoff to sales

### 🔮 Future Enhancements (Post-MVP)
- Authentication & Authorization (JWT, Role-based)
- Multi-tenant SaaS architecture
- WhatsApp/SMS integration
- Email automation
- Advanced reporting & dashboards
- Real-time notifications (SignalR)
- File import/export (Excel, CSV)
- Advanced analytics

## 🗂️ Database Schema

See `docs/database-schema.md` for complete entity relationships and field definitions.

## 🔐 Security Notes (MVP)

⚠️ **This is an MVP without authentication.** For production:
- Add JWT authentication
- Implement role-based authorization
- Add data validation and sanitization
- Implement rate limiting
- Add audit logging
- Secure sensitive data

## 📞 Support

This is an MVP demonstration project. Extend as needed for production use.
