# API Endpoints Documentation

Base URL: `https://localhost:7001/api`

## 📊 Campaigns

### Get All Campaigns
```http
GET /api/campaigns
```
**Response:** `List<CampaignDto>`

### Get Campaign by ID
```http
GET /api/campaigns/{id}
```
**Response:** `CampaignDto`

### Create Campaign
```http
POST /api/campaigns
Content-Type: application/json

{
  "name": "Q1 2026 Tech Solutions",
  "description": "Targeting small businesses",
  "startDate": "2026-01-01T00:00:00",
  "endDate": "2026-03-31T23:59:59",
  "productIds": [
    "guid-1",
    "guid-2"
  ]
}
```
**Response:** `CampaignDto`

### Update Campaign
```http
PUT /api/campaigns/{id}
Content-Type: application/json

{
  "id": "campaign-guid",
  "name": "Updated Name",
  "description": "Updated description",
  "startDate": "2026-01-01T00:00:00",
  "endDate": "2026-03-31T23:59:59",
  "status": 1,
  "productIds": ["guid-1"]
}
```
**Response:** `CampaignDto`

### Delete Campaign
```http
DELETE /api/campaigns/{id}
```
**Response:** `204 No Content`

---

## 📦 Products

### Get All Products
```http
GET /api/products
```
**Response:** `List<ProductDto>`

### Get Product by ID
```http
GET /api/products/{id}
```
**Response:** `ProductDto`

### Create Product
```http
POST /api/products
Content-Type: application/json

{
  "name": "Premium CRM Software",
  "description": "Advanced customer relationship management",
  "price": 999.99
}
```
**Response:** `ProductDto`

### Update Product
```http
PUT /api/products/{id}
Content-Type: application/json

{
  "id": "product-guid",
  "name": "Updated Product Name",
  "description": "Updated description",
  "price": 1299.99
}
```
**Response:** `ProductDto`

### Delete Product
```http
DELETE /api/products/{id}
```
**Response:** `204 No Content`

---

## 👥 Customers & Target Lists

### Get All Target Lists
```http
GET /api/customers/target-lists
```
**Response:** `List<TargetListDto>`

### Get Target Lists by Campaign
```http
GET /api/customers/campaigns/{campaignId}/target-lists
```
**Response:** `List<TargetListDto>`

### Get Target List by ID
```http
GET /api/customers/target-lists/{id}
```
**Response:** `TargetListDto`

### Create Target List
```http
POST /api/customers/target-lists
Content-Type: application/json

{
  "name": "Small Business Tech Leads",
  "description": "Compiled list of small businesses",
  "campaignId": "campaign-guid"
}
```
**Response:** `TargetListDto`

### Delete Target List
```http
DELETE /api/customers/target-lists/{id}
```
**Response:** `204 No Content`

### Get Customers by Target List
```http
GET /api/customers/target-lists/{targetListId}/customers
```
**Response:** `List<CustomerDto>`

### Create Single Customer
```http
POST /api/customers
Content-Type: application/json

{
  "name": "John Smith",
  "phone": "+1-555-0101",
  "email": "john.smith@example.com",
  "targetListId": "target-list-guid"
}
```
**Response:** `CustomerDto`

### Bulk Create Customers
```http
POST /api/customers/bulk
Content-Type: application/json

{
  "targetListId": "target-list-guid",
  "customers": [
    {
      "name": "John Smith",
      "phone": "+1-555-0101",
      "email": "john.smith@example.com"
    },
    {
      "name": "Jane Doe",
      "phone": "+1-555-0102",
      "email": "jane.doe@example.com"
    }
  ]
}
```
**Response:** `List<CustomerDto>`

### Delete Customer
```http
DELETE /api/customers/{id}
```
**Response:** `204 No Content`

---

## 👔 Agents & Assignments

### Get All Agents
```http
GET /api/agents
```
**Response:** `List<CallCenterAgentDto>`

### Get Agent by ID
```http
GET /api/agents/{id}
```
**Response:** `CallCenterAgentDto`

### Create Agent
```http
POST /api/agents
Content-Type: application/json

{
  "name": "Agent Alice Cooper",
  "email": "alice.cooper@callcenter.com",
  "phone": "+1-555-1001"
}
```
**Response:** `CallCenterAgentDto`

### Update Agent
```http
PUT /api/agents/{id}
Content-Type: application/json

{
  "id": "agent-guid",
  "name": "Agent Alice Cooper",
  "email": "alice.cooper@callcenter.com",
  "phone": "+1-555-1001",
  "isActive": true
}
```
**Response:** `CallCenterAgentDto`

### Delete Agent
```http
DELETE /api/agents/{id}
```
**Response:** `204 No Content`

### Get Assignments by Agent
```http
GET /api/agents/{agentId}/assignments
```
**Response:** `List<CustomerAssignmentDto>`

### Get Assignment by ID
```http
GET /api/agents/assignments/{assignmentId}
```
**Response:** `CustomerAssignmentDto`

### Assign Customers to Agents (Even Distribution)
```http
POST /api/agents/assignments
Content-Type: application/json

{
  "targetListId": "target-list-guid",
  "agentIds": [
    "agent-guid-1",
    "agent-guid-2",
    "agent-guid-3"
  ],
  "distributeEvenly": true
}
```
**Response:** `List<CustomerAssignmentDto>`

**Distribution Logic:**
- `distributeEvenly: true` - Distributes customers evenly across agents
  - Example: 10 customers, 3 agents → 4, 3, 3 distribution
- `distributeEvenly: false` - Simple round-robin distribution

### Update Assignment (Agent Follow-up)
```http
PUT /api/agents/assignments/{assignmentId}
Content-Type: application/json

{
  "assignmentId": "assignment-guid",
  "contactStatus": 2,
  "contactMethod": 0,
  "notes": "Very interested in CRM solution, scheduled demo",
  "markAsWonLead": true
}
```
**Response:** `CustomerAssignmentDto`

**ContactStatus Values:**
- `0` - NotContacted
- `1` - Contacted
- `2` - Interested
- `3` - NotInterested
- `4` - NoResponse

**ContactMethod Values:**
- `0` - Phone
- `1` - SMS
- `2` - Email

---

## Error Responses

### 400 Bad Request
```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "errors": {
    "Name": ["The Name field is required."]
  }
}
```

### 404 Not Found
```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404
}
```

### 500 Internal Server Error
```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.6.1",
  "title": "An error occurred while processing your request.",
  "status": 500
}
```

---

## Swagger Documentation

When running in development mode, full interactive API documentation is available at:

```
https://localhost:7001/swagger
```

This provides:
- Full API specification
- Request/response schemas
- Try-it-out functionality
- Model definitions
