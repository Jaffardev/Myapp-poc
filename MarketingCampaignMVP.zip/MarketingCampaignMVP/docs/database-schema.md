# Database Schema Documentation

## Overview
PostgreSQL database with 7 core tables following clean architecture principles.

## Entity Relationship Diagram (ERD)

```
┌─────────────────┐         ┌──────────────────┐
│    Campaign     │         │     Product      │
├─────────────────┤         ├──────────────────┤
│ Id (PK)         │◄───┐    │ Id (PK)          │◄───┐
│ Name            │    │    │ Name             │    │
│ Description     │    │    │ Description      │    │
│ StartDate       │    │    │ Price            │    │
│ EndDate         │    │    └──────────────────┘    │
│ Status          │    │                            │
│ CreatedAt       │    │    ┌──────────────────┐    │
│ UpdatedAt       │    └────┤ CampaignProduct  │────┘
└─────────────────┘         ├──────────────────┤
        │                   │ Id (PK)          │
        │                   │ CampaignId (FK)  │
        │                   │ ProductId (FK)   │
        │                   └──────────────────┘
        │
        │ 1:N
        ▼
┌─────────────────┐
│   TargetList    │
├─────────────────┤
│ Id (PK)         │
│ Name            │
│ Description     │
│ CampaignId (FK) │◄───┐
│ CreatedAt       │    │
└─────────────────┘    │
        │              │
        │ 1:N          │
        ▼              │
┌─────────────────┐    │
│    Customer     │    │
├─────────────────┤    │
│ Id (PK)         │    │
│ Name            │    │
│ Phone           │    │
│ Email           │    │
│ CampaignId (FK) │────┘
│ TargetListId(FK)│
│ CreatedAt       │
└─────────────────┘
        │
        │ 1:N
        ▼
┌─────────────────────────┐         ┌─────────────────────┐
│  CustomerAssignment     │   N:1   │  CallCenterAgent    │
├─────────────────────────┤────────►├─────────────────────┤
│ Id (PK)                 │         │ Id (PK)             │
│ CustomerId (FK)         │         │ Name                │
│ AgentId (FK)            │         │ Email               │
│ AssignedAt              │         │ Phone               │
│ ContactStatus           │         │ IsActive            │
│ ContactMethod           │         │ CreatedAt           │
│ LastContactedAt         │         │ UpdatedAt           │
│ Notes                   │         └─────────────────────┘
│ IsWonLead               │
│ WonLeadAt               │
│ CreatedAt               │
│ UpdatedAt               │
└─────────────────────────┘
```

## Table Definitions

### Campaign
Marketing campaign entity.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| Name | VARCHAR(200) | NOT NULL | Campaign name |
| Description | VARCHAR(1000) | | Campaign details |
| StartDate | TIMESTAMP | NOT NULL | Campaign start date |
| EndDate | TIMESTAMP | NOT NULL | Campaign end date |
| Status | INT | NOT NULL | 0=Draft, 1=Active, 2=Completed, 3=Cancelled |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |
| UpdatedAt | TIMESTAMP | | Last update time |

**Indexes:**
- PRIMARY KEY (Id)
- INDEX (Status)
- INDEX (StartDate)

---

### Product
Products that can be associated with campaigns.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| Name | VARCHAR(200) | NOT NULL | Product name |
| Description | VARCHAR(1000) | | Product details |
| Price | DECIMAL(18,2) | | Product price (optional) |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |
| UpdatedAt | TIMESTAMP | | Last update time |

**Indexes:**
- PRIMARY KEY (Id)

---

### CampaignProduct
Junction table for Campaign-Product many-to-many relationship.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| CampaignId | GUID | FK, NOT NULL | Reference to Campaign |
| ProductId | GUID | FK, NOT NULL | Reference to Product |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |

**Indexes:**
- PRIMARY KEY (Id)
- UNIQUE INDEX (CampaignId, ProductId)

**Foreign Keys:**
- CampaignId → Campaign.Id (CASCADE DELETE)
- ProductId → Product.Id (CASCADE DELETE)

---

### TargetList
Customer target lists for campaigns.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| Name | VARCHAR(200) | NOT NULL | Target list name |
| Description | VARCHAR(1000) | | List description |
| CampaignId | GUID | FK, NOT NULL | Reference to Campaign |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |

**Indexes:**
- PRIMARY KEY (Id)

**Foreign Keys:**
- CampaignId → Campaign.Id (CASCADE DELETE)

---

### Customer
Customers in target lists.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| Name | VARCHAR(200) | NOT NULL | Customer name |
| Phone | VARCHAR(50) | | Phone number |
| Email | VARCHAR(200) | | Email address |
| CampaignId | GUID | FK, NOT NULL | Reference to Campaign |
| TargetListId | GUID | FK, NOT NULL | Reference to TargetList |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |

**Indexes:**
- PRIMARY KEY (Id)
- INDEX (Email)
- INDEX (Phone)

**Foreign Keys:**
- CampaignId → Campaign.Id (CASCADE DELETE)
- TargetListId → TargetList.Id (CASCADE DELETE)

---

### CallCenterAgent
Call center agents who handle customer contacts.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| Name | VARCHAR(200) | NOT NULL | Agent name |
| Email | VARCHAR(200) | NOT NULL, UNIQUE | Agent email |
| Phone | VARCHAR(50) | | Agent phone |
| IsActive | BOOLEAN | NOT NULL | Agent active status |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |
| UpdatedAt | TIMESTAMP | | Last update time |

**Indexes:**
- PRIMARY KEY (Id)
- UNIQUE INDEX (Email)

---

### CustomerAssignment
Assignment of customers to agents with follow-up tracking.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| Id | GUID | PK | Unique identifier |
| CustomerId | GUID | FK, NOT NULL | Reference to Customer |
| AgentId | GUID | FK, NOT NULL | Reference to CallCenterAgent |
| AssignedAt | TIMESTAMP | NOT NULL | Assignment timestamp |
| ContactStatus | INT | NOT NULL | 0=NotContacted, 1=Contacted, 2=Interested, 3=NotInterested, 4=NoResponse |
| ContactMethod | INT | | 0=Phone, 1=SMS, 2=Email |
| LastContactedAt | TIMESTAMP | | Last contact timestamp |
| Notes | VARCHAR(2000) | | Agent notes |
| IsWonLead | BOOLEAN | NOT NULL | Marked as won lead flag |
| WonLeadAt | TIMESTAMP | | Won lead timestamp |
| CreatedAt | TIMESTAMP | NOT NULL | Record creation time |
| UpdatedAt | TIMESTAMP | | Last update time |

**Indexes:**
- PRIMARY KEY (Id)
- INDEX (ContactStatus)
- INDEX (IsWonLead)
- INDEX (CustomerId, AgentId)

**Foreign Keys:**
- CustomerId → Customer.Id (CASCADE DELETE)
- AgentId → CallCenterAgent.Id (RESTRICT DELETE)

---

## Enumerations

### CampaignStatus
- `0` - Draft
- `1` - Active
- `2` - Completed
- `3` - Cancelled

### ContactStatus
- `0` - NotContacted
- `1` - Contacted
- `2` - Interested
- `3` - NotInterested
- `4` - NoResponse

### ContactMethod
- `0` - Phone
- `1` - SMS
- `2` - Email

---

## Sample Queries

### Get all active campaigns with product count
```sql
SELECT c.*, COUNT(cp.ProductId) as ProductCount
FROM "Campaigns" c
LEFT JOIN "CampaignProducts" cp ON c."Id" = cp."CampaignId"
WHERE c."Status" = 1
GROUP BY c."Id";
```

### Get agent workload (assignments per agent)
```sql
SELECT a."Name", 
       COUNT(ca."Id") as TotalAssignments,
       SUM(CASE WHEN ca."ContactStatus" != 0 THEN 1 ELSE 0 END) as CompletedContacts
FROM "CallCenterAgents" a
LEFT JOIN "CustomerAssignments" ca ON a."Id" = ca."AgentId"
GROUP BY a."Id", a."Name";
```

### Get won leads for sales handoff
```sql
SELECT ca.*, c."Name" as CustomerName, cmp."Name" as CampaignName
FROM "CustomerAssignments" ca
JOIN "Customers" c ON ca."CustomerId" = c."Id"
JOIN "Campaigns" cmp ON c."CampaignId" = cmp."Id"
WHERE ca."IsWonLead" = true
ORDER BY ca."WonLeadAt" DESC;
```

---

## Future Enhancements

When adding authentication:
- Add `Users` table
- Link `CallCenterAgent.UserId` to `Users.Id`
- Add role-based permissions table

When adding multi-tenancy:
- Add `TenantId` to all tables
- Add `Tenants` table
- Implement row-level security
