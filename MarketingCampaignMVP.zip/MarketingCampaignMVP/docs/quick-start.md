# Quick Start Guide

## Prerequisites

Before you begin, ensure you have the following installed:

- **.NET 8 SDK** or later ([Download](https://dotnet.microsoft.com/download))
- **PostgreSQL 14+** ([Download](https://www.postgresql.org/download/))
- **Visual Studio 2022** or **VS Code** (optional but recommended)
- **Node.js** (for Blazor WASM tooling - optional)

## Step 1: Clone/Download the Project

If you received this as a ZIP file, extract it. Otherwise:

```bash
git clone <repository-url>
cd MarketingCampaignMVP
```

## Step 2: Setup PostgreSQL Database

### Option A: Using psql
```sql
CREATE DATABASE MarketingCampaignDB;
CREATE USER marketinguser WITH PASSWORD 'YourSecurePassword123';
GRANT ALL PRIVILEGES ON DATABASE MarketingCampaignDB TO marketinguser;
```

### Option B: Using pgAdmin
1. Open pgAdmin
2. Create new database: `MarketingCampaignDB`
3. (Optional) Create a dedicated user with appropriate permissions

## Step 3: Configure Connection String

Edit `src/MarketingCampaign.API/appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Database=MarketingCampaignDB;Username=postgres;Password=YourPassword"
  }
}
```

Replace with your PostgreSQL credentials.

## Step 4: Run Database Migrations

Navigate to the API project:

```bash
cd src/MarketingCampaign.API
```

Apply migrations:

```bash
dotnet ef migrations add InitialCreate --project ../MarketingCampaign.Infrastructure
dotnet ef database update
```

**Note:** The database will be automatically seeded with sample data on first run.

## Step 5: Run the API

From `src/MarketingCampaign.API`:

```bash
dotnet run
```

The API should start at:
- HTTPS: `https://localhost:7001`
- HTTP: `http://localhost:5001`

Open Swagger documentation:
```
https://localhost:7001/swagger
```

## Step 6: Run the Blazor WASM Frontend

Open a **new terminal** and navigate to the Blazor project:

```bash
cd src/MarketingCampaign.BlazorWasm
dotnet run
```

The Blazor app should start at:
- HTTPS: `https://localhost:7002`
- HTTP: `http://localhost:5002`

## Step 7: Verify Everything Works

### Test the API (Swagger)
1. Go to `https://localhost:7001/swagger`
2. Try the `GET /api/campaigns` endpoint
3. You should see the seeded sample campaigns

### Test the Blazor UI
1. Go to `https://localhost:7002`
2. Click on "Campaigns" in the sidebar
3. You should see the seeded campaigns
4. Try creating a new campaign

## Using the Application

### 1. Create a Campaign
1. Navigate to **Campaigns** → **Create Campaign**
2. Fill in campaign details
3. Select products to associate
4. Click **Create Campaign**

### 2. Create a Target List
1. Navigate to **Target Lists**
2. Click **Create Target List**
3. Select the campaign
4. Add customers manually or use bulk import

### 3. Assign Customers to Agents
1. Navigate to **Agents**
2. Ensure you have active agents (sample data includes 4 agents)
3. Go to **Assignments** → **Create Assignment**
4. Select target list
5. Select agents (multiple)
6. Click **Assign** - customers will be distributed evenly

### 4. Agent Dashboard
1. Navigate to **Agents**
2. Click on an agent's dashboard
3. View assigned customers
4. Update contact status
5. Add notes
6. Mark interested customers as "Won Leads"

## Sample Data

The database is seeded with:
- **5 Products** (CRM, Email Marketing, Analytics, etc.)
- **3 Campaigns** (Q1 2026, Enterprise CRM, Spring Marketing)
- **2 Target Lists**
- **12 Sample Customers**
- **4 Call Center Agents**
- **6 Sample Assignments** (various statuses)

## Common Issues & Solutions

### Issue: "Cannot connect to PostgreSQL"
**Solution:** 
- Verify PostgreSQL is running: `pg_isready`
- Check connection string in `appsettings.json`
- Ensure database exists

### Issue: "Migration not found"
**Solution:**
```bash
cd src/MarketingCampaign.API
dotnet ef migrations add InitialCreate --project ../MarketingCampaign.Infrastructure
dotnet ef database update
```

### Issue: "CORS error in browser"
**Solution:** 
- Verify API is running on `https://localhost:7001`
- Check Blazor `Program.cs` has correct API base URL
- Ensure API CORS policy includes Blazor origin

### Issue: "Blazor app shows loading forever"
**Solution:**
- Open browser console (F12) to check for errors
- Verify API is running and accessible
- Check network tab for failed requests

## Development Tips

### Running Both Projects Simultaneously

#### Using Visual Studio
1. Right-click solution → **Set Startup Projects**
2. Select **Multiple startup projects**
3. Set both `MarketingCampaign.API` and `MarketingCampaign.BlazorWasm` to **Start**

#### Using Terminal (Recommended)
Terminal 1 (API):
```bash
cd src/MarketingCampaign.API
dotnet watch run
```

Terminal 2 (Blazor):
```bash
cd src/MarketingCampaign.BlazorWasm
dotnet watch run
```

**`dotnet watch`** enables hot reload - changes are automatically reflected.

### Viewing Database

**Using pgAdmin:**
1. Connect to PostgreSQL server
2. Navigate to `MarketingCampaignDB`
3. Browse tables under `public` schema

**Using psql:**
```bash
psql -U postgres -d MarketingCampaignDB
\dt  # List tables
SELECT * FROM "Campaigns";
```

### Resetting Database

To start fresh:

```bash
cd src/MarketingCampaign.API
dotnet ef database drop
dotnet ef database update
```

The database will be re-seeded automatically on next run.

## Next Steps

Now that your MVP is running, you can:

1. **Explore the codebase** - Follow clean architecture layers
2. **Add new features** - Extend entities, add services
3. **Customize UI** - Modify Blazor pages with Bootstrap
4. **Add authentication** - Implement JWT + Identity
5. **Add integrations** - WhatsApp, Email, SMS providers
6. **Deploy to production** - Azure, AWS, or your preferred cloud

## Need Help?

- Check `docs/database-schema.md` for database details
- Check `docs/api-endpoints.md` for API reference
- Review `README.md` for architecture overview
- Use Swagger UI for interactive API testing

Happy coding! 🚀
