using MarketingCampaign.Application.DTOs.Agents;
using MarketingCampaign.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarketingCampaign.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AgentsController : ControllerBase
{
    private readonly IAgentService _agentService;

    public AgentsController(IAgentService agentService)
    {
        _agentService = agentService;
    }

    #region Call Center Agents

    /// <summary>
    /// Get all call center agents
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<CallCenterAgentDto>>> GetAllAgents()
    {
        var agents = await _agentService.GetAllAgentsAsync();
        return Ok(agents);
    }

    /// <summary>
    /// Get agent by ID
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<CallCenterAgentDto>> GetAgentById(Guid id)
    {
        var agent = await _agentService.GetAgentByIdAsync(id);
        if (agent == null)
            return NotFound();

        return Ok(agent);
    }

    /// <summary>
    /// Create a new call center agent
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<CallCenterAgentDto>> CreateAgent([FromBody] CreateCallCenterAgentDto dto)
    {
        var agent = await _agentService.CreateAgentAsync(dto);
        return CreatedAtAction(nameof(GetAgentById), new { id = agent.Id }, agent);
    }

    /// <summary>
    /// Update an existing agent
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult<CallCenterAgentDto>> UpdateAgent(Guid id, [FromBody] UpdateCallCenterAgentDto dto)
    {
        if (id != dto.Id)
            return BadRequest("ID mismatch");

        var agent = await _agentService.UpdateAgentAsync(dto);
        if (agent == null)
            return NotFound();

        return Ok(agent);
    }

    /// <summary>
    /// Delete an agent
    /// </summary>
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteAgent(Guid id)
    {
        var result = await _agentService.DeleteAgentAsync(id);
        if (!result)
            return NotFound();

        return NoContent();
    }

    #endregion

    #region Customer Assignments

    /// <summary>
    /// Get all assignments for a specific agent
    /// </summary>
    [HttpGet("{agentId}/assignments")]
    public async Task<ActionResult<List<CustomerAssignmentDto>>> GetAssignmentsByAgent(Guid agentId)
    {
        var assignments = await _agentService.GetAssignmentsByAgentAsync(agentId);
        return Ok(assignments);
    }

    /// <summary>
    /// Get a specific assignment by ID
    /// </summary>
    [HttpGet("assignments/{assignmentId}")]
    public async Task<ActionResult<CustomerAssignmentDto>> GetAssignmentById(Guid assignmentId)
    {
        var assignment = await _agentService.GetAssignmentByIdAsync(assignmentId);
        if (assignment == null)
            return NotFound();

        return Ok(assignment);
    }

    /// <summary>
    /// Assign customers from a target list to agents (even distribution)
    /// </summary>
    [HttpPost("assignments")]
    public async Task<ActionResult<List<CustomerAssignmentDto>>> AssignCustomers([FromBody] AssignCustomersDto dto)
    {
        try
        {
            var assignments = await _agentService.AssignCustomersToAgentsAsync(dto);
            return Ok(assignments);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(ex.Message);
        }
    }

    /// <summary>
    /// Update assignment status and notes (agent follow-up)
    /// </summary>
    [HttpPut("assignments/{assignmentId}")]
    public async Task<ActionResult<CustomerAssignmentDto>> UpdateAssignment(
        Guid assignmentId, 
        [FromBody] UpdateAssignmentDto dto)
    {
        if (assignmentId != dto.AssignmentId)
            return BadRequest("ID mismatch");

        var assignment = await _agentService.UpdateAssignmentAsync(dto);
        if (assignment == null)
            return NotFound();

        return Ok(assignment);
    }

    #endregion
}
