using MarketingCampaign.Application.DTOs.Campaigns;
using MarketingCampaign.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarketingCampaign.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CampaignsController : ControllerBase
{
    private readonly ICampaignService _campaignService;

    public CampaignsController(ICampaignService campaignService)
    {
        _campaignService = campaignService;
    }

    /// <summary>
    /// Get all campaigns
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<CampaignDto>>> GetAll()
    {
        var campaigns = await _campaignService.GetAllAsync();
        return Ok(campaigns);
    }

    /// <summary>
    /// Get campaign by ID
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<CampaignDto>> GetById(Guid id)
    {
        var campaign = await _campaignService.GetByIdAsync(id);
        if (campaign == null)
            return NotFound();

        return Ok(campaign);
    }

    /// <summary>
    /// Create a new campaign
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<CampaignDto>> Create([FromBody] CreateCampaignDto dto)
    {
        var campaign = await _campaignService.CreateAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = campaign.Id }, campaign);
    }

    /// <summary>
    /// Update an existing campaign
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult<CampaignDto>> Update(Guid id, [FromBody] UpdateCampaignDto dto)
    {
        if (id != dto.Id)
            return BadRequest("ID mismatch");

        var campaign = await _campaignService.UpdateAsync(dto);
        if (campaign == null)
            return NotFound();

        return Ok(campaign);
    }

    /// <summary>
    /// Delete a campaign
    /// </summary>
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var result = await _campaignService.DeleteAsync(id);
        if (!result)
            return NotFound();

        return NoContent();
    }
}
