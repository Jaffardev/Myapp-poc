using MarketingCampaign.Application.DTOs.Customers;
using MarketingCampaign.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarketingCampaign.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CustomersController : ControllerBase
{
    private readonly ICustomerService _customerService;

    public CustomersController(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    #region Target Lists

    /// <summary>
    /// Get all target lists
    /// </summary>
    [HttpGet("target-lists")]
    public async Task<ActionResult<List<TargetListDto>>> GetAllTargetLists()
    {
        var targetLists = await _customerService.GetAllTargetListsAsync();
        return Ok(targetLists);
    }

    /// <summary>
    /// Get target lists by campaign
    /// </summary>
    [HttpGet("campaigns/{campaignId}/target-lists")]
    public async Task<ActionResult<List<TargetListDto>>> GetTargetListsByCampaign(Guid campaignId)
    {
        var targetLists = await _customerService.GetTargetListsByCampaignAsync(campaignId);
        return Ok(targetLists);
    }

    /// <summary>
    /// Get target list by ID
    /// </summary>
    [HttpGet("target-lists/{id}")]
    public async Task<ActionResult<TargetListDto>> GetTargetListById(Guid id)
    {
        var targetList = await _customerService.GetTargetListByIdAsync(id);
        if (targetList == null)
            return NotFound();

        return Ok(targetList);
    }

    /// <summary>
    /// Create a new target list
    /// </summary>
    [HttpPost("target-lists")]
    public async Task<ActionResult<TargetListDto>> CreateTargetList([FromBody] CreateTargetListDto dto)
    {
        var targetList = await _customerService.CreateTargetListAsync(dto);
        return CreatedAtAction(nameof(GetTargetListById), new { id = targetList.Id }, targetList);
    }

    /// <summary>
    /// Delete a target list
    /// </summary>
    [HttpDelete("target-lists/{id}")]
    public async Task<IActionResult> DeleteTargetList(Guid id)
    {
        var result = await _customerService.DeleteTargetListAsync(id);
        if (!result)
            return NotFound();

        return NoContent();
    }

    #endregion

    #region Customers

    /// <summary>
    /// Get customers by target list
    /// </summary>
    [HttpGet("target-lists/{targetListId}/customers")]
    public async Task<ActionResult<List<CustomerDto>>> GetCustomersByTargetList(Guid targetListId)
    {
        var customers = await _customerService.GetCustomersByTargetListAsync(targetListId);
        return Ok(customers);
    }

    /// <summary>
    /// Create a single customer
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<CustomerDto>> CreateCustomer([FromBody] CreateCustomerDto dto)
    {
        var customer = await _customerService.CreateCustomerAsync(dto);
        return Ok(customer);
    }

    /// <summary>
    /// Bulk create customers (for CSV import, etc.)
    /// </summary>
    [HttpPost("bulk")]
    public async Task<ActionResult<List<CustomerDto>>> BulkCreateCustomers([FromBody] BulkCreateCustomersDto dto)
    {
        var customers = await _customerService.BulkCreateCustomersAsync(dto);
        return Ok(customers);
    }

    /// <summary>
    /// Delete a customer
    /// </summary>
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCustomer(Guid id)
    {
        var result = await _customerService.DeleteCustomerAsync(id);
        if (!result)
            return NotFound();

        return NoContent();
    }

    #endregion
}
