using MarketingCampaign.Domain.Enums;

namespace MarketingCampaign.Application.DTOs.Agents;

public class CallCenterAgentDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public int TotalAssignments { get; set; }
    public int CompletedContacts { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateCallCenterAgentDto
{
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
}

public class UpdateCallCenterAgentDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool IsActive { get; set; }
}

public class CustomerAssignmentDto
{
    public Guid Id { get; set; }
    public Guid CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public Guid AgentId { get; set; }
    public string AgentName { get; set; } = string.Empty;
    public DateTime AssignedAt { get; set; }
    public ContactStatus ContactStatus { get; set; }
    public ContactMethod? ContactMethod { get; set; }
    public DateTime? LastContactedAt { get; set; }
    public string Notes { get; set; } = string.Empty;
    public bool IsWonLead { get; set; }
    public DateTime? WonLeadAt { get; set; }
    public string CampaignName { get; set; } = string.Empty;
}

public class AssignCustomersDto
{
    public Guid TargetListId { get; set; }
    public List<Guid> AgentIds { get; set; } = new();
    public bool DistributeEvenly { get; set; } = true;
}

public class UpdateAssignmentDto
{
    public Guid AssignmentId { get; set; }
    public ContactStatus ContactStatus { get; set; }
    public ContactMethod? ContactMethod { get; set; }
    public string Notes { get; set; } = string.Empty;
    public bool MarkAsWonLead { get; set; }
}
