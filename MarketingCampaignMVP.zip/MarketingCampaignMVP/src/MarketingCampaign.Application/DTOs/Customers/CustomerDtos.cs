namespace MarketingCampaign.Application.DTOs.Customers;

public class TargetListDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
    public string CampaignName { get; set; } = string.Empty;
    public int TotalCustomers { get; set; }
    public int AssignedCustomers { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateTargetListDto
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
}

public class CustomerDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
    public Guid TargetListId { get; set; }
    public string CampaignName { get; set; } = string.Empty;
    public string TargetListName { get; set; } = string.Empty;
    public bool IsAssigned { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateCustomerDto
{
    public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public Guid TargetListId { get; set; }
}

public class BulkCreateCustomersDto
{
    public Guid TargetListId { get; set; }
    public List<CreateCustomerDto> Customers { get; set; } = new();
}
