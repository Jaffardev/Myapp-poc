using MarketingCampaign.Application.DTOs.Agents;
using MarketingCampaign.Domain.Entities;
using MarketingCampaign.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace MarketingCampaign.Application.Services;

public interface IAgentService
{
    Task<List<CallCenterAgentDto>> GetAllAgentsAsync();
    Task<CallCenterAgentDto?> GetAgentByIdAsync(Guid id);
    Task<CallCenterAgentDto> CreateAgentAsync(CreateCallCenterAgentDto dto);
    Task<CallCenterAgentDto?> UpdateAgentAsync(UpdateCallCenterAgentDto dto);
    Task<bool> DeleteAgentAsync(Guid id);
    
    Task<List<CustomerAssignmentDto>> GetAssignmentsByAgentAsync(Guid agentId);
    Task<CustomerAssignmentDto?> GetAssignmentByIdAsync(Guid assignmentId);
    Task<List<CustomerAssignmentDto>> AssignCustomersToAgentsAsync(AssignCustomersDto dto);
    Task<CustomerAssignmentDto?> UpdateAssignmentAsync(UpdateAssignmentDto dto);
}

public class AgentService : IAgentService
{
    private readonly IApplicationDbContext _context;

    public AgentService(IApplicationDbContext context)
    {
        _context = context;
    }

    // Agent Methods
    public async Task<List<CallCenterAgentDto>> GetAllAgentsAsync()
    {
        var agents = await _context.CallCenterAgents
            .Include(a => a.Assignments)
            .OrderByDescending(a => a.CreatedAt)
            .ToListAsync();

        return agents.Select(MapAgentToDto).ToList();
    }

    public async Task<CallCenterAgentDto?> GetAgentByIdAsync(Guid id)
    {
        var agent = await _context.CallCenterAgents
            .Include(a => a.Assignments)
            .FirstOrDefaultAsync(a => a.Id == id);

        return agent == null ? null : MapAgentToDto(agent);
    }

    public async Task<CallCenterAgentDto> CreateAgentAsync(CreateCallCenterAgentDto dto)
    {
        var agent = new CallCenterAgent
        {
            Name = dto.Name,
            Email = dto.Email,
            Phone = dto.Phone,
            IsActive = true
        };

        _context.CallCenterAgents.Add(agent);
        await _context.SaveChangesAsync();

        return MapAgentToDto(agent);
    }

    public async Task<CallCenterAgentDto?> UpdateAgentAsync(UpdateCallCenterAgentDto dto)
    {
        var agent = await _context.CallCenterAgents.FindAsync(dto.Id);
        if (agent == null) return null;

        agent.Name = dto.Name;
        agent.Email = dto.Email;
        agent.Phone = dto.Phone;
        agent.IsActive = dto.IsActive;
        agent.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return await GetAgentByIdAsync(agent.Id);
    }

    public async Task<bool> DeleteAgentAsync(Guid id)
    {
        var agent = await _context.CallCenterAgents.FindAsync(id);
        if (agent == null) return false;

        _context.CallCenterAgents.Remove(agent);
        await _context.SaveChangesAsync();
        return true;
    }

    // Assignment Methods
    public async Task<List<CustomerAssignmentDto>> GetAssignmentsByAgentAsync(Guid agentId)
    {
        var assignments = await _context.CustomerAssignments
            .Include(a => a.Customer)
                .ThenInclude(c => c.Campaign)
            .Include(a => a.Agent)
            .Where(a => a.AgentId == agentId)
            .OrderByDescending(a => a.AssignedAt)
            .ToListAsync();

        return assignments.Select(MapAssignmentToDto).ToList();
    }

    public async Task<CustomerAssignmentDto?> GetAssignmentByIdAsync(Guid assignmentId)
    {
        var assignment = await _context.CustomerAssignments
            .Include(a => a.Customer)
                .ThenInclude(c => c.Campaign)
            .Include(a => a.Agent)
            .FirstOrDefaultAsync(a => a.Id == assignmentId);

        return assignment == null ? null : MapAssignmentToDto(assignment);
    }

    public async Task<List<CustomerAssignmentDto>> AssignCustomersToAgentsAsync(AssignCustomersDto dto)
    {
        // Get unassigned customers from the target list
        var unassignedCustomers = await _context.Customers
            .Include(c => c.Assignments)
            .Where(c => c.TargetListId == dto.TargetListId && !c.Assignments.Any())
            .ToListAsync();

        if (!unassignedCustomers.Any())
            throw new InvalidOperationException("No unassigned customers found in the target list");

        var agents = await _context.CallCenterAgents
            .Where(a => dto.AgentIds.Contains(a.Id) && a.IsActive)
            .ToListAsync();

        if (!agents.Any())
            throw new InvalidOperationException("No active agents found");

        var assignments = new List<CustomerAssignment>();

        if (dto.DistributeEvenly)
        {
            // Even distribution logic
            var customersPerAgent = unassignedCustomers.Count / agents.Count;
            var remainingCustomers = unassignedCustomers.Count % agents.Count;

            var customerIndex = 0;
            for (int i = 0; i < agents.Count; i++)
            {
                var agent = agents[i];
                var assignmentCount = customersPerAgent + (i < remainingCustomers ? 1 : 0);

                for (int j = 0; j < assignmentCount && customerIndex < unassignedCustomers.Count; j++)
                {
                    var assignment = new CustomerAssignment
                    {
                        CustomerId = unassignedCustomers[customerIndex].Id,
                        AgentId = agent.Id
                    };
                    assignments.Add(assignment);
                    customerIndex++;
                }
            }
        }
        else
        {
            // Simple round-robin distribution
            for (int i = 0; i < unassignedCustomers.Count; i++)
            {
                var agent = agents[i % agents.Count];
                var assignment = new CustomerAssignment
                {
                    CustomerId = unassignedCustomers[i].Id,
                    AgentId = agent.Id
                };
                assignments.Add(assignment);
            }
        }

        _context.CustomerAssignments.AddRange(assignments);
        await _context.SaveChangesAsync();

        // Reload with navigation properties
        var assignmentIds = assignments.Select(a => a.Id).ToList();
        var loadedAssignments = await _context.CustomerAssignments
            .Include(a => a.Customer)
                .ThenInclude(c => c.Campaign)
            .Include(a => a.Agent)
            .Where(a => assignmentIds.Contains(a.Id))
            .ToListAsync();

        return loadedAssignments.Select(MapAssignmentToDto).ToList();
    }

    public async Task<CustomerAssignmentDto?> UpdateAssignmentAsync(UpdateAssignmentDto dto)
    {
        var assignment = await _context.CustomerAssignments
            .Include(a => a.Customer)
            .FirstOrDefaultAsync(a => a.Id == dto.AssignmentId);

        if (assignment == null) return null;

        assignment.ContactStatus = dto.ContactStatus;
        assignment.ContactMethod = dto.ContactMethod;
        assignment.Notes = dto.Notes;
        assignment.LastContactedAt = DateTime.UtcNow;

        // Handle won lead marking
        if (dto.MarkAsWonLead && dto.ContactStatus == ContactStatus.Interested)
        {
            assignment.IsWonLead = true;
            assignment.WonLeadAt = DateTime.UtcNow;
        }

        assignment.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        return await GetAssignmentByIdAsync(assignment.Id);
    }

    private static CallCenterAgentDto MapAgentToDto(CallCenterAgent agent)
    {
        return new CallCenterAgentDto
        {
            Id = agent.Id,
            Name = agent.Name,
            Email = agent.Email,
            Phone = agent.Phone,
            IsActive = agent.IsActive,
            TotalAssignments = agent.Assignments.Count,
            CompletedContacts = agent.Assignments.Count(a => a.ContactStatus != ContactStatus.NotContacted),
            CreatedAt = agent.CreatedAt
        };
    }

    private static CustomerAssignmentDto MapAssignmentToDto(CustomerAssignment assignment)
    {
        return new CustomerAssignmentDto
        {
            Id = assignment.Id,
            CustomerId = assignment.CustomerId,
            CustomerName = assignment.Customer.Name,
            CustomerPhone = assignment.Customer.Phone,
            CustomerEmail = assignment.Customer.Email,
            AgentId = assignment.AgentId,
            AgentName = assignment.Agent.Name,
            AssignedAt = assignment.AssignedAt,
            ContactStatus = assignment.ContactStatus,
            ContactMethod = assignment.ContactMethod,
            LastContactedAt = assignment.LastContactedAt,
            Notes = assignment.Notes,
            IsWonLead = assignment.IsWonLead,
            WonLeadAt = assignment.WonLeadAt,
            CampaignName = assignment.Customer.Campaign?.Name ?? ""
        };
    }
}
