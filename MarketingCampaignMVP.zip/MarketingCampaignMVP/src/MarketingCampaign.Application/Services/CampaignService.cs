using MarketingCampaign.Application.DTOs.Campaigns;
using MarketingCampaign.Domain.Entities;
using MarketingCampaign.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace MarketingCampaign.Application.Services;

public interface ICampaignService
{
    Task<List<CampaignDto>> GetAllAsync();
    Task<CampaignDto?> GetByIdAsync(Guid id);
    Task<CampaignDto> CreateAsync(CreateCampaignDto dto);
    Task<CampaignDto?> UpdateAsync(UpdateCampaignDto dto);
    Task<bool> DeleteAsync(Guid id);
}

public class CampaignService : ICampaignService
{
    private readonly IApplicationDbContext _context;

    public CampaignService(IApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<CampaignDto>> GetAllAsync()
    {
        var campaigns = await _context.Campaigns
            .Include(c => c.CampaignProducts)
                .ThenInclude(cp => cp.Product)
            .Include(c => c.Customers)
                .ThenInclude(c => c.Assignments)
            .OrderByDescending(c => c.CreatedAt)
            .ToListAsync();

        return campaigns.Select(MapToDto).ToList();
    }

    public async Task<CampaignDto?> GetByIdAsync(Guid id)
    {
        var campaign = await _context.Campaigns
            .Include(c => c.CampaignProducts)
                .ThenInclude(cp => cp.Product)
            .Include(c => c.Customers)
                .ThenInclude(c => c.Assignments)
            .FirstOrDefaultAsync(c => c.Id == id);

        return campaign == null ? null : MapToDto(campaign);
    }

    public async Task<CampaignDto> CreateAsync(CreateCampaignDto dto)
    {
        var campaign = new Campaign
        {
            Name = dto.Name,
            Description = dto.Description,
            StartDate = dto.StartDate,
            EndDate = dto.EndDate,
            Status = CampaignStatus.Draft
        };

        _context.Campaigns.Add(campaign);

        // Add products to campaign
        foreach (var productId in dto.ProductIds)
        {
            var campaignProduct = new CampaignProduct
            {
                CampaignId = campaign.Id,
                ProductId = productId
            };
            _context.CampaignProducts.Add(campaignProduct);
        }

        await _context.SaveChangesAsync();

        return (await GetByIdAsync(campaign.Id))!;
    }

    public async Task<CampaignDto?> UpdateAsync(UpdateCampaignDto dto)
    {
        var campaign = await _context.Campaigns
            .Include(c => c.CampaignProducts)
            .FirstOrDefaultAsync(c => c.Id == dto.Id);

        if (campaign == null) return null;

        campaign.Name = dto.Name;
        campaign.Description = dto.Description;
        campaign.StartDate = dto.StartDate;
        campaign.EndDate = dto.EndDate;
        campaign.Status = dto.Status;
        campaign.UpdatedAt = DateTime.UtcNow;

        // Update products
        _context.CampaignProducts.RemoveRange(campaign.CampaignProducts);
        
        foreach (var productId in dto.ProductIds)
        {
            var campaignProduct = new CampaignProduct
            {
                CampaignId = campaign.Id,
                ProductId = productId
            };
            _context.CampaignProducts.Add(campaignProduct);
        }

        await _context.SaveChangesAsync();

        return await GetByIdAsync(campaign.Id);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var campaign = await _context.Campaigns.FindAsync(id);
        if (campaign == null) return false;

        _context.Campaigns.Remove(campaign);
        await _context.SaveChangesAsync();
        return true;
    }

    private static CampaignDto MapToDto(Campaign campaign)
    {
        return new CampaignDto
        {
            Id = campaign.Id,
            Name = campaign.Name,
            Description = campaign.Description,
            StartDate = campaign.StartDate,
            EndDate = campaign.EndDate,
            Status = campaign.Status,
            CreatedAt = campaign.CreatedAt,
            UpdatedAt = campaign.UpdatedAt,
            Products = campaign.CampaignProducts.Select(cp => new ProductDto
            {
                Id = cp.Product.Id,
                Name = cp.Product.Name,
                Description = cp.Product.Description,
                Price = cp.Product.Price
            }).ToList(),
            TotalCustomers = campaign.Customers.Count,
            AssignedCustomers = campaign.Customers.Count(c => c.Assignments.Any())
        };
    }
}
