using MarketingCampaign.Application.DTOs.Customers;
using MarketingCampaign.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace MarketingCampaign.Application.Services;

public interface ICustomerService
{
    Task<List<TargetListDto>> GetAllTargetListsAsync();
    Task<List<TargetListDto>> GetTargetListsByCampaignAsync(Guid campaignId);
    Task<TargetListDto?> GetTargetListByIdAsync(Guid id);
    Task<TargetListDto> CreateTargetListAsync(CreateTargetListDto dto);
    Task<bool> DeleteTargetListAsync(Guid id);
    
    Task<List<CustomerDto>> GetCustomersByTargetListAsync(Guid targetListId);
    Task<CustomerDto> CreateCustomerAsync(CreateCustomerDto dto);
    Task<List<CustomerDto>> BulkCreateCustomersAsync(BulkCreateCustomersDto dto);
    Task<bool> DeleteCustomerAsync(Guid id);
}

public class CustomerService : ICustomerService
{
    private readonly IApplicationDbContext _context;

    public CustomerService(IApplicationDbContext context)
    {
        _context = context;
    }

    // Target List Methods
    public async Task<List<TargetListDto>> GetAllTargetListsAsync()
    {
        var targetLists = await _context.TargetLists
            .Include(tl => tl.Campaign)
            .Include(tl => tl.Customers)
                .ThenInclude(c => c.Assignments)
            .OrderByDescending(tl => tl.CreatedAt)
            .ToListAsync();

        return targetLists.Select(MapTargetListToDto).ToList();
    }

    public async Task<List<TargetListDto>> GetTargetListsByCampaignAsync(Guid campaignId)
    {
        var targetLists = await _context.TargetLists
            .Include(tl => tl.Campaign)
            .Include(tl => tl.Customers)
                .ThenInclude(c => c.Assignments)
            .Where(tl => tl.CampaignId == campaignId)
            .OrderByDescending(tl => tl.CreatedAt)
            .ToListAsync();

        return targetLists.Select(MapTargetListToDto).ToList();
    }

    public async Task<TargetListDto?> GetTargetListByIdAsync(Guid id)
    {
        var targetList = await _context.TargetLists
            .Include(tl => tl.Campaign)
            .Include(tl => tl.Customers)
                .ThenInclude(c => c.Assignments)
            .FirstOrDefaultAsync(tl => tl.Id == id);

        return targetList == null ? null : MapTargetListToDto(targetList);
    }

    public async Task<TargetListDto> CreateTargetListAsync(CreateTargetListDto dto)
    {
        var targetList = new TargetList
        {
            Name = dto.Name,
            Description = dto.Description,
            CampaignId = dto.CampaignId
        };

        _context.TargetLists.Add(targetList);
        await _context.SaveChangesAsync();

        return (await GetTargetListByIdAsync(targetList.Id))!;
    }

    public async Task<bool> DeleteTargetListAsync(Guid id)
    {
        var targetList = await _context.TargetLists.FindAsync(id);
        if (targetList == null) return false;

        _context.TargetLists.Remove(targetList);
        await _context.SaveChangesAsync();
        return true;
    }

    // Customer Methods
    public async Task<List<CustomerDto>> GetCustomersByTargetListAsync(Guid targetListId)
    {
        var customers = await _context.Customers
            .Include(c => c.Campaign)
            .Include(c => c.TargetList)
            .Include(c => c.Assignments)
            .Where(c => c.TargetListId == targetListId)
            .OrderByDescending(c => c.CreatedAt)
            .ToListAsync();

        return customers.Select(MapCustomerToDto).ToList();
    }

    public async Task<CustomerDto> CreateCustomerAsync(CreateCustomerDto dto)
    {
        var targetList = await _context.TargetLists
            .Include(tl => tl.Campaign)
            .FirstOrDefaultAsync(tl => tl.Id == dto.TargetListId);

        if (targetList == null)
            throw new InvalidOperationException("Target list not found");

        var customer = new Customer
        {
            Name = dto.Name,
            Phone = dto.Phone,
            Email = dto.Email,
            TargetListId = dto.TargetListId,
            CampaignId = targetList.CampaignId
        };

        _context.Customers.Add(customer);
        await _context.SaveChangesAsync();

        return MapCustomerToDto(customer);
    }

    public async Task<List<CustomerDto>> BulkCreateCustomersAsync(BulkCreateCustomersDto dto)
    {
        var targetList = await _context.TargetLists
            .Include(tl => tl.Campaign)
            .FirstOrDefaultAsync(tl => tl.Id == dto.TargetListId);

        if (targetList == null)
            throw new InvalidOperationException("Target list not found");

        var customers = dto.Customers.Select(c => new Customer
        {
            Name = c.Name,
            Phone = c.Phone,
            Email = c.Email,
            TargetListId = dto.TargetListId,
            CampaignId = targetList.CampaignId
        }).ToList();

        _context.Customers.AddRange(customers);
        await _context.SaveChangesAsync();

        return customers.Select(MapCustomerToDto).ToList();
    }

    public async Task<bool> DeleteCustomerAsync(Guid id)
    {
        var customer = await _context.Customers.FindAsync(id);
        if (customer == null) return false;

        _context.Customers.Remove(customer);
        await _context.SaveChangesAsync();
        return true;
    }

    private static TargetListDto MapTargetListToDto(TargetList targetList)
    {
        return new TargetListDto
        {
            Id = targetList.Id,
            Name = targetList.Name,
            Description = targetList.Description,
            CampaignId = targetList.CampaignId,
            CampaignName = targetList.Campaign.Name,
            TotalCustomers = targetList.Customers.Count,
            AssignedCustomers = targetList.Customers.Count(c => c.Assignments.Any()),
            CreatedAt = targetList.CreatedAt
        };
    }

    private static CustomerDto MapCustomerToDto(Customer customer)
    {
        return new CustomerDto
        {
            Id = customer.Id,
            Name = customer.Name,
            Phone = customer.Phone,
            Email = customer.Email,
            CampaignId = customer.CampaignId,
            TargetListId = customer.TargetListId,
            CampaignName = customer.Campaign?.Name ?? "",
            TargetListName = customer.TargetList?.Name ?? "",
            IsAssigned = customer.Assignments.Any(),
            CreatedAt = customer.CreatedAt
        };
    }
}
