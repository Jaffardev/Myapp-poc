using MarketingCampaign.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace MarketingCampaign.Application.Services;

/// <summary>
/// Database context interface for application services
/// Follows ABP pattern - Application layer depends on abstraction, not implementation
/// </summary>
public interface IApplicationDbContext
{
    DbSet<Campaign> Campaigns { get; }
    DbSet<Product> Products { get; }
    DbSet<CampaignProduct> CampaignProducts { get; }
    DbSet<TargetList> TargetLists { get; }
    DbSet<Customer> Customers { get; }
    DbSet<CallCenterAgent> CallCenterAgents { get; }
    DbSet<CustomerAssignment> CustomerAssignments { get; }
    
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
