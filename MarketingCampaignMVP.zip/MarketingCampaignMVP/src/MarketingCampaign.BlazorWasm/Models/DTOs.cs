// Campaign DTOs
namespace MarketingCampaign.BlazorWasm.Models;

public enum CampaignStatus
{
    Draft = 0,
    Active = 1,
    Completed = 2,
    Cancelled = 3
}

public enum ContactStatus
{
    NotContacted = 0,
    Contacted = 1,
    Interested = 2,
    NotInterested = 3,
    NoResponse = 4
}

public enum ContactMethod
{
    Phone = 0,
    SMS = 1,
    Email = 2
}

public class CampaignDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public CampaignStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
    public List<ProductDto> Products { get; set; } = new();
    public int TotalCustomers { get; set; }
    public int AssignedCustomers { get; set; }
}

public class CreateCampaignDto
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime StartDate { get; set; } = DateTime.Now;
    public DateTime EndDate { get; set; } = DateTime.Now.AddMonths(3);
    public List<Guid> ProductIds { get; set; } = new();
}

public class ProductDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal? Price { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateProductDto
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal? Price { get; set; }
}

public class TargetListDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
    public string CampaignName { get; set; } = string.Empty;
    public int TotalCustomers { get; set; }
    public int AssignedCustomers { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateTargetListDto
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
}

public class CustomerDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
    public Guid TargetListId { get; set; }
    public string CampaignName { get; set; } = string.Empty;
    public string TargetListName { get; set; } = string.Empty;
    public bool IsAssigned { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateCustomerDto
{
    public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public Guid TargetListId { get; set; }
}

public class BulkCreateCustomersDto
{
    public Guid TargetListId { get; set; }
    public List<CreateCustomerDto> Customers { get; set; } = new();
}

public class CallCenterAgentDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public int TotalAssignments { get; set; }
    public int CompletedContacts { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateCallCenterAgentDto
{
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
}

public class CustomerAssignmentDto
{
    public Guid Id { get; set; }
    public Guid CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public Guid AgentId { get; set; }
    public string AgentName { get; set; } = string.Empty;
    public DateTime AssignedAt { get; set; }
    public ContactStatus ContactStatus { get; set; }
    public ContactMethod? ContactMethod { get; set; }
    public DateTime? LastContactedAt { get; set; }
    public string Notes { get; set; } = string.Empty;
    public bool IsWonLead { get; set; }
    public DateTime? WonLeadAt { get; set; }
    public string CampaignName { get; set; } = string.Empty;
}

public class AssignCustomersDto
{
    public Guid TargetListId { get; set; }
    public List<Guid> AgentIds { get; set; } = new();
    public bool DistributeEvenly { get; set; } = true;
}

public class UpdateAssignmentDto
{
    public Guid AssignmentId { get; set; }
    public ContactStatus ContactStatus { get; set; }
    public ContactMethod? ContactMethod { get; set; }
    public string Notes { get; set; } = string.Empty;
    public bool MarkAsWonLead { get; set; }
}
