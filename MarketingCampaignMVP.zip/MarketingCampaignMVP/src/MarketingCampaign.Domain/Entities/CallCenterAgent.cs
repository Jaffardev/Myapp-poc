using MarketingCampaign.Domain.Common;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Represents a call center agent who handles customer contacts
/// </summary>
public class CallCenterAgent : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    
    // Navigation properties
    public virtual ICollection<CustomerAssignment> Assignments { get; set; } = new List<CustomerAssignment>();
    
    // Future: When adding authentication, link to User entity
    // public Guid? UserId { get; set; }
}
