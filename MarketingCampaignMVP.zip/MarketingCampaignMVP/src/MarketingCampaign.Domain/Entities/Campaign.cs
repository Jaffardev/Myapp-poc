using MarketingCampaign.Domain.Common;
using MarketingCampaign.Domain.Enums;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Represents a marketing campaign
/// </summary>
public class Campaign : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public CampaignStatus Status { get; set; }
    
    // Navigation properties
    public virtual ICollection<CampaignProduct> CampaignProducts { get; set; } = new List<CampaignProduct>();
    public virtual ICollection<TargetList> TargetLists { get; set; } = new List<TargetList>();
    public virtual ICollection<Customer> Customers { get; set; } = new List<Customer>();
}
