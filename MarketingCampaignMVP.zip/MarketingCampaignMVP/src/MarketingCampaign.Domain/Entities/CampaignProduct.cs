using MarketingCampaign.Domain.Common;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Junction table for Campaign-Product many-to-many relationship
/// </summary>
public class CampaignProduct : BaseEntity
{
    public Guid CampaignId { get; set; }
    public Guid ProductId { get; set; }
    
    // Navigation properties
    public virtual Campaign Campaign { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}
