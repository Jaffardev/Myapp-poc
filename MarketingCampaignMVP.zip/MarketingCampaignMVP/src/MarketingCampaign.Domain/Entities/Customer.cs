using MarketingCampaign.Domain.Common;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Represents a customer in a target list
/// </summary>
public class Customer : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    
    public Guid CampaignId { get; set; }
    public Guid TargetListId { get; set; }
    
    // Navigation properties
    public virtual Campaign Campaign { get; set; } = null!;
    public virtual TargetList TargetList { get; set; } = null!;
    public virtual ICollection<CustomerAssignment> Assignments { get; set; } = new List<CustomerAssignment>();
}
