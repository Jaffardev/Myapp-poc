using MarketingCampaign.Domain.Common;
using MarketingCampaign.Domain.Enums;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Represents the assignment of a customer to a call center agent with follow-up tracking
/// </summary>
public class CustomerAssignment : BaseEntity
{
    public Guid CustomerId { get; set; }
    public Guid AgentId { get; set; }
    public DateTime AssignedAt { get; set; }
    
    // Contact tracking
    public ContactStatus ContactStatus { get; set; }
    public ContactMethod? ContactMethod { get; set; }
    public DateTime? LastContactedAt { get; set; }
    public string Notes { get; set; } = string.Empty;
    
    // Sales handoff
    public bool IsWonLead { get; set; }
    public DateTime? WonLeadAt { get; set; }
    
    // Navigation properties
    public virtual Customer Customer { get; set; } = null!;
    public virtual CallCenterAgent Agent { get; set; } = null!;
    
    public CustomerAssignment()
    {
        AssignedAt = DateTime.UtcNow;
        ContactStatus = ContactStatus.NotContacted;
        IsWonLead = false;
    }
}
