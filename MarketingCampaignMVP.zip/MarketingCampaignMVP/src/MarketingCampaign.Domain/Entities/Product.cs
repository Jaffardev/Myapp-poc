using MarketingCampaign.Domain.Common;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Represents a product that can be associated with campaigns
/// </summary>
public class Product : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal? Price { get; set; } // Optional for MVP
    
    // Navigation properties
    public virtual ICollection<CampaignProduct> CampaignProducts { get; set; } = new List<CampaignProduct>();
}
