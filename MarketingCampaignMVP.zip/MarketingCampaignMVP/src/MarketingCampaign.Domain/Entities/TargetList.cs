using MarketingCampaign.Domain.Common;

namespace MarketingCampaign.Domain.Entities;

/// <summary>
/// Represents a target customer list for a campaign
/// </summary>
public class TargetList : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid CampaignId { get; set; }
    
    // Navigation properties
    public virtual Campaign Campaign { get; set; } = null!;
    public virtual ICollection<Customer> Customers { get; set; } = new List<Customer>();
}
