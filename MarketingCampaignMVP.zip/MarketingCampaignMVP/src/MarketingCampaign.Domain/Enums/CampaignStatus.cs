namespace MarketingCampaign.Domain.Enums;

/// <summary>
/// Status of a marketing campaign
/// </summary>
public enum CampaignStatus
{
    Draft = 0,
    Active = 1,
    Completed = 2,
    Cancelled = 3
}
