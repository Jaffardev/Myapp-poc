namespace MarketingCampaign.Domain.Enums;

/// <summary>
/// Method used to contact the customer
/// </summary>
public enum ContactMethod
{
    Phone = 0,
    SMS = 1,
    Email = 2,
    // Future: Add WhatsApp when integration is implemented
    // WhatsApp = 3
}
