namespace MarketingCampaign.Domain.Enums;

/// <summary>
/// Status of customer contact attempt
/// </summary>
public enum ContactStatus
{
    NotContacted = 0,
    Contacted = 1,
    Interested = 2,
    NotInterested = 3,
    NoResponse = 4
}
