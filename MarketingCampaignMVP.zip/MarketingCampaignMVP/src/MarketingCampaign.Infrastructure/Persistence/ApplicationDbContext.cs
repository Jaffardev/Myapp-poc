using MarketingCampaign.Application.Services;
using MarketingCampaign.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace MarketingCampaign.Infrastructure.Persistence;

public class ApplicationDbContext : DbContext, IApplicationDbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Campaign> Campaigns => Set<Campaign>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<CampaignProduct> CampaignProducts => Set<CampaignProduct>();
    public DbSet<TargetList> TargetLists => Set<TargetList>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<CallCenterAgent> CallCenterAgents => Set<CallCenterAgent>();
    public DbSet<CustomerAssignment> CustomerAssignments => Set<CustomerAssignment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Campaign Configuration
        modelBuilder.Entity<Campaign>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Description).HasMaxLength(1000);
            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.StartDate);
        });

        // Product Configuration
        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Description).HasMaxLength(1000);
            entity.Property(e => e.Price).HasPrecision(18, 2);
        });

        // CampaignProduct Configuration (Many-to-Many)
        modelBuilder.Entity<CampaignProduct>(entity =>
        {
            entity.HasKey(e => e.Id);
            
            entity.HasOne(e => e.Campaign)
                .WithMany(c => c.CampaignProducts)
                .HasForeignKey(e => e.CampaignId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.Product)
                .WithMany(p => p.CampaignProducts)
                .HasForeignKey(e => e.ProductId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.CampaignId, e.ProductId }).IsUnique();
        });

        // TargetList Configuration
        modelBuilder.Entity<TargetList>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Description).HasMaxLength(1000);

            entity.HasOne(e => e.Campaign)
                .WithMany(c => c.TargetLists)
                .HasForeignKey(e => e.CampaignId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Customer Configuration
        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Phone).HasMaxLength(50);
            entity.Property(e => e.Email).HasMaxLength(200);

            entity.HasOne(e => e.Campaign)
                .WithMany(c => c.Customers)
                .HasForeignKey(e => e.CampaignId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.TargetList)
                .WithMany(tl => tl.Customers)
                .HasForeignKey(e => e.TargetListId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => e.Email);
            entity.HasIndex(e => e.Phone);
        });

        // CallCenterAgent Configuration
        modelBuilder.Entity<CallCenterAgent>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Email).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Phone).HasMaxLength(50);

            entity.HasIndex(e => e.Email).IsUnique();
        });

        // CustomerAssignment Configuration
        modelBuilder.Entity<CustomerAssignment>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Notes).HasMaxLength(2000);

            entity.HasOne(e => e.Customer)
                .WithMany(c => c.Assignments)
                .HasForeignKey(e => e.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.Agent)
                .WithMany(a => a.Assignments)
                .HasForeignKey(e => e.AgentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(e => e.ContactStatus);
            entity.HasIndex(e => e.IsWonLead);
            entity.HasIndex(e => new { e.CustomerId, e.AgentId });
        });
    }
}
