using MarketingCampaign.Domain.Entities;
using MarketingCampaign.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace MarketingCampaign.Infrastructure.Persistence;

public static class DatabaseSeeder
{
    public static async Task SeedAsync(IServiceProvider serviceProvider)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        // Ensure database is created
        await context.Database.MigrateAsync();

        // Check if data already exists
        if (await context.Products.AnyAsync())
            return; // Data already seeded

        // Seed Products
        var products = new List<Product>
        {
            new Product { Name = "Premium CRM Software", Description = "Advanced customer relationship management solution", Price = 999.99m },
            new Product { Name = "Email Marketing Suite", Description = "Complete email automation and marketing platform", Price = 499.99m },
            new Product { Name = "Analytics Dashboard Pro", Description = "Real-time analytics and reporting dashboard", Price = 299.99m },
            new Product { Name = "Social Media Manager", Description = "Multi-platform social media management tool", Price = 199.99m },
            new Product { Name = "SEO Optimization Package", Description = "Search engine optimization and monitoring", Price = 149.99m }
        };
        context.Products.AddRange(products);
        await context.SaveChangesAsync();

        // Seed Campaigns
        var campaigns = new List<Campaign>
        {
            new Campaign
            {
                Name = "Q1 2026 Tech Solutions Campaign",
                Description = "Targeting small to medium businesses with our tech solutions",
                StartDate = new DateTime(2026, 1, 1),
                EndDate = new DateTime(2026, 3, 31),
                Status = CampaignStatus.Active
            },
            new Campaign
            {
                Name = "Enterprise CRM Rollout",
                Description = "Focus on enterprise clients for premium CRM adoption",
                StartDate = new DateTime(2026, 2, 1),
                EndDate = new DateTime(2026, 5, 31),
                Status = CampaignStatus.Active
            },
            new Campaign
            {
                Name = "Spring Marketing Automation",
                Description = "Email and social media automation for growing businesses",
                StartDate = new DateTime(2026, 3, 1),
                EndDate = new DateTime(2026, 6, 30),
                Status = CampaignStatus.Draft
            }
        };
        context.Campaigns.AddRange(campaigns);
        await context.SaveChangesAsync();

        // Associate Products with Campaigns
        var campaignProducts = new List<CampaignProduct>
        {
            // Campaign 1: Tech Solutions
            new CampaignProduct { CampaignId = campaigns[0].Id, ProductId = products[0].Id },
            new CampaignProduct { CampaignId = campaigns[0].Id, ProductId = products[2].Id },
            new CampaignProduct { CampaignId = campaigns[0].Id, ProductId = products[4].Id },
            
            // Campaign 2: Enterprise CRM
            new CampaignProduct { CampaignId = campaigns[1].Id, ProductId = products[0].Id },
            
            // Campaign 3: Marketing Automation
            new CampaignProduct { CampaignId = campaigns[2].Id, ProductId = products[1].Id },
            new CampaignProduct { CampaignId = campaigns[2].Id, ProductId = products[3].Id }
        };
        context.CampaignProducts.AddRange(campaignProducts);
        await context.SaveChangesAsync();

        // Seed Target Lists
        var targetLists = new List<TargetList>
        {
            new TargetList
            {
                Name = "Small Business Tech Leads",
                Description = "Compiled list of small businesses in tech sector",
                CampaignId = campaigns[0].Id
            },
            new TargetList
            {
                Name = "Enterprise Decision Makers",
                Description = "C-level executives at enterprise companies",
                CampaignId = campaigns[1].Id
            }
        };
        context.TargetLists.AddRange(targetLists);
        await context.SaveChangesAsync();

        // Seed Customers
        var customers = new List<Customer>
        {
            // Target List 1
            new Customer { Name = "John Smith", Phone = "+1-555-0101", Email = "john.smith@techcorp.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "Sarah Johnson", Phone = "+1-555-0102", Email = "sarah.j@innovate.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "Michael Brown", Phone = "+1-555-0103", Email = "mbrown@digitalstart.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "Emily Davis", Phone = "+1-555-0104", Email = "emily.davis@techsolutions.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "David Wilson", Phone = "+1-555-0105", Email = "dwilson@cloudventures.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "Jennifer Martinez", Phone = "+1-555-0106", Email = "jmartinez@startuplab.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "Robert Taylor", Phone = "+1-555-0107", Email = "rtaylor@nextech.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            new Customer { Name = "Lisa Anderson", Phone = "+1-555-0108", Email = "landerson@biztech.com", CampaignId = campaigns[0].Id, TargetListId = targetLists[0].Id },
            
            // Target List 2
            new Customer { Name = "James Wilson", Phone = "+1-555-0201", Email = "jwilson@megacorp.com", CampaignId = campaigns[1].Id, TargetListId = targetLists[1].Id },
            new Customer { Name = "Patricia Moore", Phone = "+1-555-0202", Email = "pmoore@globalenterprises.com", CampaignId = campaigns[1].Id, TargetListId = targetLists[1].Id },
            new Customer { Name = "Christopher Lee", Phone = "+1-555-0203", Email = "clee@worldwideinc.com", CampaignId = campaigns[1].Id, TargetListId = targetLists[1].Id },
            new Customer { Name = "Barbara White", Phone = "+1-555-0204", Email = "bwhite@conglomerate.com", CampaignId = campaigns[1].Id, TargetListId = targetLists[1].Id }
        };
        context.Customers.AddRange(customers);
        await context.SaveChangesAsync();

        // Seed Call Center Agents
        var agents = new List<CallCenterAgent>
        {
            new CallCenterAgent { Name = "Agent Alice Cooper", Email = "alice.cooper@callcenter.com", Phone = "+1-555-1001", IsActive = true },
            new CallCenterAgent { Name = "Agent Bob Miller", Email = "bob.miller@callcenter.com", Phone = "+1-555-1002", IsActive = true },
            new CallCenterAgent { Name = "Agent Carol Zhang", Email = "carol.zhang@callcenter.com", Phone = "+1-555-1003", IsActive = true },
            new CallCenterAgent { Name = "Agent Dan Rodriguez", Email = "dan.rodriguez@callcenter.com", Phone = "+1-555-1004", IsActive = true }
        };
        context.CallCenterAgents.AddRange(agents);
        await context.SaveChangesAsync();

        // Seed some Customer Assignments (simulate distribution)
        var assignments = new List<CustomerAssignment>
        {
            // Agent 1 - 2 customers
            new CustomerAssignment
            {
                CustomerId = customers[0].Id,
                AgentId = agents[0].Id,
                ContactStatus = ContactStatus.Contacted,
                ContactMethod = ContactMethod.Phone,
                LastContactedAt = DateTime.UtcNow.AddDays(-2),
                Notes = "Left voicemail, will follow up tomorrow"
            },
            new CustomerAssignment
            {
                CustomerId = customers[1].Id,
                AgentId = agents[0].Id,
                ContactStatus = ContactStatus.Interested,
                ContactMethod = ContactMethod.Email,
                LastContactedAt = DateTime.UtcNow.AddDays(-1),
                Notes = "Very interested in CRM solution, scheduled demo for next week",
                IsWonLead = true,
                WonLeadAt = DateTime.UtcNow.AddDays(-1)
            },
            
            // Agent 2 - 2 customers
            new CustomerAssignment
            {
                CustomerId = customers[2].Id,
                AgentId = agents[1].Id,
                ContactStatus = ContactStatus.NotInterested,
                ContactMethod = ContactMethod.Phone,
                LastContactedAt = DateTime.UtcNow.AddDays(-3),
                Notes = "Already using competitor product, not interested in switching"
            },
            new CustomerAssignment
            {
                CustomerId = customers[3].Id,
                AgentId = agents[1].Id,
                ContactStatus = ContactStatus.NoResponse,
                ContactMethod = ContactMethod.Phone,
                LastContactedAt = DateTime.UtcNow.AddHours(-6),
                Notes = "No answer, tried 3 times"
            },
            
            // Agent 3 - 2 customers
            new CustomerAssignment
            {
                CustomerId = customers[4].Id,
                AgentId = agents[2].Id,
                ContactStatus = ContactStatus.Contacted,
                ContactMethod = ContactMethod.Email,
                LastContactedAt = DateTime.UtcNow.AddHours(-12),
                Notes = "Sent initial email with product info"
            },
            new CustomerAssignment
            {
                CustomerId = customers[5].Id,
                AgentId = agents[2].Id,
                ContactStatus = ContactStatus.NotContacted,
                Notes = "Assigned today, will contact tomorrow"
            }
        };
        context.CustomerAssignments.AddRange(assignments);
        await context.SaveChangesAsync();

        Console.WriteLine("✅ Database seeded successfully!");
    }
}
