# Architecture Documentation

## Overview

This POC implements a clean, layered architecture following the AppService pattern (similar to ABP Framework) without using ABP NuGet packages.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Blazor WebAssembly Client                │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                  Razor Pages/Components               │   │
│  │  - Products.razor                                     │   │
│  │  - Home.razor                                         │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│  ┌────────────────────▼─────────────────────────────────┐   │
│  │              Refit HTTP Client                        │   │
│  │  - IProductAppService (interface)                     │   │
│  │  - Type-safe HTTP calls                              │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│  ┌────────────────────▼─────────────────────────────────┐   │
│  │            SignatureHandler (DelegatingHandler)       │   │
│  │  - Generates HMAC-SHA256 signature                   │   │
│  │  - Adds X-Signature & X-Timestamp headers            │   │
│  └────────────────────┬─────────────────────────────────┘   │
└───────────────────────┼──────────────────────────────────────┘
                        │ HTTPS
                        │
┌───────────────────────▼──────────────────────────────────────┐
│                      ASP.NET Core Web API                    │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                  Middleware Pipeline                  │   │
│  │                                                       │   │
│  │  1. ApiSignatureValidationMiddleware                 │   │
│  │     - Validates HMAC-SHA256 signature                │   │
│  │     - Checks timestamp (5-min window)                │   │
│  │     - Returns 401 if invalid                         │   │
│  │                                                       │   │
│  │  2. InputSanitizationMiddleware                      │   │
│  │     - Removes <script> tags                          │   │
│  │     - Filters XSS patterns                           │   │
│  │     - Logs sanitization events                       │   │
│  │                                                       │   │
│  │  3. CORS Middleware                                  │   │
│  │  4. Authorization Middleware                         │   │
│  │  5. Routing Middleware                               │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│  ┌────────────────────▼─────────────────────────────────┐   │
│  │                 Global Filters                        │   │
│  │                                                       │   │
│  │  - GlobalModelValidationFilter                       │   │
│  │    * Validates Data Annotations                      │   │
│  │    * Returns 400 with validation errors              │   │
│  │                                                       │   │
│  │  - GlobalExceptionFilter                             │   │
│  │    * Handles all exceptions                          │   │
│  │    * Returns proper HTTP status codes                │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│  ┌────────────────────▼─────────────────────────────────┐   │
│  │            Controllers (Auto-generated)               │   │
│  │                                                       │   │
│  │  ProductController : AppServiceController             │   │
│  │    - Inherits from base controller                   │   │
│  │    - Defines HTTP endpoints (POST, GET, PUT, DELETE) │   │
│  │    - Delegates to AppService                         │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
└───────────────────────┼──────────────────────────────────────┘
                        │
┌───────────────────────▼──────────────────────────────────────┐
│                   Application Layer                          │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Application Services                     │   │
│  │                                                       │   │
│  │  ProductAppService : ApplicationService               │   │
│  │    - Business logic                                   │   │
│  │    - Data validation                                  │   │
│  │    - Uses AutoMapper                                  │   │
│  │    - Logging                                          │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
└───────────────────────┼──────────────────────────────────────┘
                        │
┌───────────────────────▼──────────────────────────────────────┐
│                      Core/Domain Layer                       │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                    Entities                           │   │
│  │  - Product                                            │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                     DTOs                              │   │
│  │  - CreateProductDto (with validation attributes)     │   │
│  │  - UpdateProductDto                                   │   │
│  │  - ProductDto                                         │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │            Validation Attributes                      │   │
│  │  - SanitizedStringAttribute                          │   │
│  │  - NoSqlInjectionAttribute                           │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                  Interfaces                           │   │
│  │  - IApplicationService (base)                        │   │
│  │  - IProductAppService                                │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                 DbContext                             │   │
│  │  - AppDbContext (Entity Framework Core)              │   │
│  └────────────────────┬─────────────────────────────────┘   │
└───────────────────────┼──────────────────────────────────────┘
                        │
                        ▼
              ┌─────────────────┐
              │  SQL Server DB  │
              │   (LocalDB)     │
              └─────────────────┘
```

## Request Flow

### 1. Valid Request Flow

```
Client (Blazor)
    │
    ├─► Generate signature (HMAC-SHA256)
    │
    ├─► Add headers (X-Signature, X-Timestamp)
    │
    ▼
API Middleware Pipeline
    │
    ├─► ApiSignatureValidationMiddleware
    │   └─► Validate signature ✓
    │   └─► Validate timestamp ✓
    │
    ├─► InputSanitizationMiddleware
    │   └─► Check for XSS patterns ✓
    │   └─► Sanitize if needed
    │
    ▼
Model Binding & Validation
    │
    ├─► Bind JSON to DTO
    │
    ├─► GlobalModelValidationFilter
    │   └─► Validate Data Annotations ✓
    │   └─► Check SanitizedString attribute ✓
    │
    ▼
Controller Action
    │
    ├─► ProductController.Create(dto)
    │
    ▼
Application Service
    │
    ├─► ProductAppService.CreateAsync(dto)
    │   └─► Business logic
    │   └─► Create entity
    │   └─► Save to database
    │   └─► Map to DTO
    │
    ▼
Response
    │
    └─► 201 Created + ProductDto
```

### 2. Validation Error Flow

```
Client (Blazor)
    │
    ├─► Send invalid data (XSS attempt)
    │
    ▼
API Middleware Pipeline
    │
    ├─► ApiSignatureValidationMiddleware ✓
    │
    ├─► InputSanitizationMiddleware ✓
    │
    ▼
Model Binding & Validation
    │
    ├─► Bind JSON to DTO
    │
    ├─► GlobalModelValidationFilter
    │   └─► Validate Data Annotations
    │   └─► SanitizedStringAttribute FAILS ✗
    │       └─► "contains malicious content"
    │
    ▼
Response
    │
    └─► 400 Bad Request
        {
          "error": {
            "code": "VALIDATION_FAILED",
            "validationErrors": {
              "Name": ["contains potentially malicious content"]
            }
          }
        }
```

### 3. Signature Validation Error Flow

```
Client (Blazor)
    │
    ├─► Generate WRONG signature
    │
    ▼
API Middleware Pipeline
    │
    ├─► ApiSignatureValidationMiddleware
    │   └─► Calculate expected signature
    │   └─► Compare signatures
    │   └─► MISMATCH ✗
    │
    ▼
Response (short-circuit)
    │
    └─► 401 Unauthorized
        {
          "error": {
            "code": "INVALID_SIGNATURE",
            "message": "Request signature is invalid"
          }
        }
```

## Layer Responsibilities

### 1. Core Layer (MyApp.Core)
**Purpose:** Contains domain entities, DTOs, and interfaces

**Responsibilities:**
- Define domain entities (Product)
- Define DTOs with validation attributes
- Define service interfaces (IProductAppService)
- Define custom validation attributes
- Define database context

**Dependencies:** None (except EF Core)

### 2. Application Layer (MyApp.Application)
**Purpose:** Contains business logic and application services

**Responsibilities:**
- Implement AppService interfaces
- Execute business logic
- Coordinate between layers
- Use AutoMapper for entity-DTO mapping
- Log important events

**Dependencies:** MyApp.Core, AutoMapper

### 3. WebApi Layer (MyApp.WebApi)
**Purpose:** HTTP API endpoint layer

**Responsibilities:**
- Define HTTP endpoints
- Handle HTTP concerns (routing, status codes)
- Apply middleware
- Apply global filters
- Configure dependency injection

**Dependencies:** MyApp.Application, MyApp.Core

### 4. Client Layer (MyApp.Client.Blazor)
**Purpose:** Frontend SPA application

**Responsibilities:**
- User interface
- Client-side validation
- HTTP communication via Refit
- Request signing

**Dependencies:** MyApp.Core (for DTOs and interfaces), Refit

## Security Layers

```
┌─────────────────────────────────────────────────────┐
│  Layer 1: API Signature Validation                  │
│  - HMAC-SHA256 signature                            │
│  - Prevents request tampering                       │
│  - Prevents replay attacks (timestamp check)        │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────┐
│  Layer 2: Input Sanitization                        │
│  - Removes malicious patterns                       │
│  - XSS prevention                                   │
│  - Applied before model binding                     │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────┐
│  Layer 3: Model Validation                          │
│  - Data Annotations                                 │
│  - Custom validators (SanitizedString)              │
│  - Range and required checks                        │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────┐
│  Layer 4: Business Logic Validation                 │
│  - AppService validates business rules              │
│  - Database constraints                             │
└─────────────────────────────────────────────────────┘
```

## Design Patterns Used

### 1. Repository Pattern
- Implemented via EF Core DbContext
- `AppDbContext` acts as repository
- `DbSet<Product>` provides CRUD operations

### 2. Service Layer Pattern
- `ApplicationService` base class
- `ProductAppService` implements business logic
- Separates business logic from controllers

### 3. DTO Pattern
- `CreateProductDto` - for creating products
- `UpdateProductDto` - for updating products
- `ProductDto` - for returning data
- Prevents over-posting attacks
- Decouples API contract from domain entities

### 4. Dependency Injection
- Constructor injection throughout
- Services registered in `Program.cs`
- Promotes testability and loose coupling

### 5. Middleware Pipeline
- Custom middleware for cross-cutting concerns
- Signature validation
- Input sanitization

### 6. Filter Pattern
- Global filters for validation
- Global filters for exception handling
- Centralized error handling

### 7. Proxy Pattern
- Refit generates proxy for IProductAppService
- Type-safe HTTP communication
- Automatic serialization/deserialization

## Validation Strategy

### Three-Tier Validation

#### 1. Client-Side (Blazor)
```
EditForm + DataAnnotationsValidator
    │
    ├─► Immediate feedback
    ├─► Prevents unnecessary API calls
    └─► Uses same DTOs as server
```

#### 2. API-Level (Middleware + Filters)
```
Middleware Layer
    │
    ├─► Signature validation
    └─► Input sanitization

Filter Layer
    │
    ├─► Model state validation
    └─► Data annotation validation
```

#### 3. Business Logic (AppService)
```
Application Service
    │
    ├─► Business rule validation
    ├─► Database constraint checks
    └─► Domain-specific validation
```

## Error Handling Strategy

```
Exception Occurs
    │
    ├─► GlobalExceptionFilter catches
    │
    ├─► Determine error type:
    │   ├─► KeyNotFoundException → 404
    │   ├─► ArgumentException → 400
    │   ├─► UnauthorizedAccessException → 401
    │   └─► Other → 500
    │
    └─► Return JSON error response
        {
          "error": {
            "code": "ERROR_TYPE",
            "message": "Error description"
          }
        }
```

## Database Design

```sql
CREATE TABLE Products (
    Id UNIQUEIDENTIFIER PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL,
    Price DECIMAL(18,2) NOT NULL,
    Stock INT NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NULL
);
```

## Configuration Management

### API Configuration (appsettings.json)
```json
{
  "ConnectionStrings": {
    "Default": "..."
  },
  "ApiSignature": {
    "Enabled": true,
    "Secret": "shared-secret-key"
  }
}
```

### Client Configuration (wwwroot/appsettings.json)
```json
{
  "ApiSettings": {
    "BaseUrl": "https://localhost:7001"
  },
  "ApiSignature": {
    "Enabled": true,
    "Secret": "same-shared-secret-key"
  }
}
```

## Performance Considerations

1. **Async/Await** - All I/O operations are asynchronous
2. **EF Core Tracking** - Uses no-tracking queries where appropriate
3. **AutoMapper** - Efficient object mapping
4. **Middleware Pipeline** - Short-circuits on validation failure
5. **Connection Pooling** - EF Core connection pooling enabled

## Scalability Considerations

### Current State (POC)
- Single server deployment
- LocalDB database
- In-memory state

### Production Recommendations
- Add caching (Redis)
- Use proper SQL Server
- Add load balancing
- Implement rate limiting
- Add health checks
- Use distributed logging

## Testing Strategy

1. **Unit Tests** - Test AppServices in isolation
2. **Integration Tests** - Test API endpoints
3. **Validation Tests** - Test all validation scenarios
4. **Security Tests** - Test signature validation, XSS prevention
5. **Manual Tests** - Browser-based testing

---

**This architecture provides:**
- ✅ Clean separation of concerns
- ✅ Testable components
- ✅ Secure by design
- ✅ Scalable foundation
- ✅ Maintainable codebase
