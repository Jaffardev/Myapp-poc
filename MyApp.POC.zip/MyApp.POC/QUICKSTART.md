# Quick Start Guide

Get the POC running in 5 minutes!

## Prerequisites

- .NET 8.0 SDK installed
- SQL Server LocalDB (comes with Visual Studio)

## Steps

### 1. Restore Packages

```bash
cd MyApp.POC
dotnet restore
```

### 2. Setup Database

```bash
cd src/MyApp.WebApi
dotnet ef migrations add InitialCreate
dotnet ef database update
```

### 3. Run API

```bash
# In terminal 1 (from MyApp.POC root)
cd src/MyApp.WebApi
dotnet run
```

**API running at:** `https://localhost:7001`

### 4. Run Blazor Client

```bash
# In terminal 2 (from MyApp.POC root)
cd src/MyApp.Client.Blazor
dotnet run
```

**Client running at:** `https://localhost:5001`

### 5. Test the Application

1. Open browser: `https://localhost:5001`
2. Navigate to "Products"
3. Create a test product:
   - Name: "Test Product"
   - Description: "My first product"
   - Price: 99.99
   - Stock: 50
4. Click "Create Product"

✅ **Success!** You should see the product in the list.

## Test Validation

Try creating a product with XSS:
- Name: `<script>alert('test')</script>`

**Expected:** Validation error message

## API Documentation

Visit Swagger UI: `https://localhost:7001/swagger`

## Troubleshooting

### Cannot connect to database
```bash
# Use SQL Server Express connection string instead
# Edit src/MyApp.WebApi/appsettings.json
"ConnectionStrings": {
  "Default": "Server=.\\SQLEXPRESS;Database=MyAppDb;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

### Port already in use
Edit `src/MyApp.WebApi/Properties/launchSettings.json` and change ports.

### CORS error
Make sure API CORS includes your client URL in `Program.cs`.

## Next Steps

- Read [README.md](README.md) for full documentation
- See [TESTING.md](TESTING.md) for comprehensive testing scenarios
- Explore the code to understand the architecture

**Happy coding! 🚀**
