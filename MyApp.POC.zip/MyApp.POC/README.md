# MyApp POC - API Validation, Sanitization & Signature

A complete Proof of Concept demonstrating global model validation, input sanitization, and API signature verification in ASP.NET Core without using ABP Framework, while following the ABP AppService pattern.

## 🎯 Features

- ✅ **Global Model Validation** - Data Annotations with custom validators
- 🛡️ **Input Sanitization** - XSS and SQL injection prevention
- 🔐 **API Signature Validation** - HMAC-SHA256 request signing
- 🏗️ **AppService Pattern** - Similar to ABP Framework but without dependencies
- 🔄 **Auto-Generated Controllers** - Controllers automatically inherit from AppServices
- 📡 **Refit Integration** - Type-safe HTTP client for Blazor WASM
- 🎨 **Blazor WebAssembly** - Modern SPA frontend

## 📁 Project Structure

```
MyApp.POC/
├── src/
│   ├── MyApp.Core/                    # Domain layer
│   │   ├── Entities/                  # Domain entities
│   │   ├── DTOs/                      # Data Transfer Objects
│   │   ├── Validation/                # Custom validation attributes
│   │   ├── Interfaces/                # Service interfaces
│   │   └── AppDbContext.cs            # EF Core DbContext
│   │
│   ├── MyApp.Application/             # Application layer
│   │   ├── Services/                  # AppService implementations
│   │   └── Mapping/                   # AutoMapper profiles
│   │
│   ├── MyApp.WebApi/                  # Web API layer
│   │   ├── Controllers/               # Auto-generated controllers
│   │   ├── Middleware/                # Custom middleware
│   │   ├── Filters/                   # Global filters
│   │   └── Extensions/                # Service extensions
│   │
│   └── MyApp.Client.Blazor/           # Blazor WASM client
│       ├── Pages/                     # Razor pages
│       ├── Services/                  # HTTP client services
│       └── wwwroot/                   # Static files
│
└── MyApp.sln
```

## 🚀 Getting Started

### Prerequisites

- .NET 8.0 SDK
- SQL Server (LocalDB or Express)
- Visual Studio 2022 or VS Code
- Optional: SQL Server Management Studio

### Installation Steps

1. **Clone or extract the project**
   ```bash
   cd MyApp.POC
   ```

2. **Restore NuGet packages**
   ```bash
   dotnet restore
   ```

3. **Update connection string** (if needed)
   
   Edit `src/MyApp.WebApi/appsettings.json`:
   ```json
   "ConnectionStrings": {
     "Default": "Server=(localdb)\\mssqllocaldb;Database=MyAppDb;Trusted_Connection=True;"
   }
   ```

4. **Create database migration**
   ```bash
   cd src/MyApp.WebApi
   dotnet ef migrations add InitialCreate
   ```

5. **Update database**
   ```bash
   dotnet ef database update
   ```

6. **Run the API**
   ```bash
   cd src/MyApp.WebApi
   dotnet run
   ```
   API will be available at: `https://localhost:7001`

7. **Run the Blazor WASM Client** (in a new terminal)
   ```bash
   cd src/MyApp.Client.Blazor
   dotnet run
   ```
   Client will be available at: `https://localhost:5001`

## 🧪 Testing the Features

### 1. Valid Product Creation

**Test Data:**
```json
{
  "name": "Test Product",
  "description": "A valid product description",
  "price": 99.99,
  "stock": 100
}
```
**Expected:** ✅ Product created successfully

### 2. XSS Attack Prevention

**Test Data:**
```json
{
  "name": "<script>alert('XSS')</script>Malicious Product",
  "description": "Test",
  "price": 99.99,
  "stock": 100
}
```
**Expected:** ❌ Validation error - "contains potentially malicious content"

### 3. SQL Injection Prevention

**Test Data:**
```json
{
  "name": "Product'; DROP TABLE Products; --",
  "description": "Test",
  "price": 99.99,
  "stock": 100
}
```
**Expected:** ❌ Validation error - "contains potentially dangerous SQL patterns"

### 4. Required Field Validation

**Test Data:**
```json
{
  "description": "Missing name field",
  "price": 99.99,
  "stock": 100
}
```
**Expected:** ❌ Validation error - "Product name is required"

### 5. Range Validation

**Test Data:**
```json
{
  "name": "Invalid Price Product",
  "description": "Test",
  "price": -10.00,
  "stock": 100
}
```
**Expected:** ❌ Validation error - "Price must be between 0.01 and 999999.99"

### 6. String Length Validation

**Test Data:**
```json
{
  "name": "AB",
  "description": "Test",
  "price": 99.99,
  "stock": 100
}
```
**Expected:** ❌ Validation error - "Name must be between 3 and 100 characters"

### 7. API Signature Testing

**To test signature validation:**

1. Open `src/MyApp.Client.Blazor/wwwroot/appsettings.json`
2. Change the secret to something different:
   ```json
   "ApiSignature": {
     "Enabled": true,
     "Secret": "WrongSecret123"
   }
   ```
3. Try creating a product
   
**Expected:** ❌ 401 Unauthorized - "Request signature is invalid"

**To disable signature validation for testing:**

Edit both:
- `src/MyApp.WebApi/appsettings.json`
- `src/MyApp.Client.Blazor/wwwroot/appsettings.json`

Set:
```json
"ApiSignature": {
  "Enabled": false,
  "Secret": "..."
}
```

## 📋 Architecture Details

### AppService Pattern (Without ABP)

This POC replicates ABP's AppService pattern without using ABP Framework:

1. **IApplicationService** - Base interface for all app services
2. **ApplicationService** - Base class with common functionality
3. **AppServiceController** - Auto-generates API endpoints from AppServices

**Example:**
```csharp
// Interface in MyApp.Core
public interface IProductAppService : IApplicationService
{
    Task<ProductDto> CreateAsync(CreateProductDto input);
}

// Implementation in MyApp.Application
public class ProductAppService : ApplicationService, IProductAppService
{
    public async Task<ProductDto> CreateAsync(CreateProductDto input)
    {
        // Business logic here
    }
}

// Auto-generated controller in MyApp.WebApi
public class ProductController : AppServiceController<IProductAppService>
{
    [HttpPost]
    public async Task<ActionResult<ProductDto>> Create([FromBody] CreateProductDto input)
    {
        return await AppService.CreateAsync(input);
    }
}
```

### Validation Pipeline

1. **Client-Side Validation** (Blazor)
   - Data Annotations on DTOs
   - EditForm with DataAnnotationsValidator

2. **API Signature Middleware**
   - Validates HMAC-SHA256 signature
   - Prevents request tampering
   - Timestamp validation (5-minute window)

3. **Input Sanitization Middleware**
   - Removes malicious scripts
   - Filters dangerous patterns
   - Applied before model binding

4. **Global Model Validation Filter**
   - Validates Data Annotations
   - Returns consistent error format
   - Logs validation failures

5. **Custom Validation Attributes**
   - `SanitizedStringAttribute` - XSS prevention
   - `NoSqlInjectionAttribute` - SQL injection prevention

### Security Features

#### API Signature (HMAC-SHA256)

**How it works:**
1. Client generates signature: `HMAC-SHA256(body + timestamp, secret)`
2. Client sends headers: `X-Signature`, `X-Timestamp`
3. Server validates signature using same algorithm
4. Server checks timestamp is within 5-minute window

**Benefits:**
- Prevents request tampering
- Prevents replay attacks
- Ensures request authenticity

#### Input Sanitization

**Patterns Detected:**
- `<script>` tags
- `javascript:` protocol
- Event handlers (`onclick=`, etc.)
- `<iframe>` tags
- SQL keywords and injection patterns

## 🔧 Configuration

### API Settings (appsettings.json)

```json
{
  "ConnectionStrings": {
    "Default": "Server=(localdb)\\mssqllocaldb;Database=MyAppDb;..."
  },
  "ApiSignature": {
    "Enabled": true,
    "Secret": "YourSecretKeyHere-MustBe32CharsOrMore"
  }
}
```

### Blazor Client Settings (wwwroot/appsettings.json)

```json
{
  "ApiSettings": {
    "BaseUrl": "https://localhost:7001"
  },
  "ApiSignature": {
    "Enabled": true,
    "Secret": "SameSecretAsAPI"
  }
}
```

## 📊 API Endpoints

### Products

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/app/product` | Get all products |
| GET | `/api/app/product/{id}` | Get product by ID |
| POST | `/api/app/product` | Create new product |
| PUT | `/api/app/product` | Update product |
| DELETE | `/api/app/product/{id}` | Delete product |

### Swagger UI

Access API documentation at: `https://localhost:7001/swagger`

## 🐛 Troubleshooting

### Database Issues

**Error:** "Cannot open database"
```bash
# Delete existing database and recreate
dotnet ef database drop
dotnet ef database update
```

### Port Conflicts

**Error:** "Address already in use"

Edit `src/MyApp.WebApi/Properties/launchSettings.json` and change ports:
```json
"applicationUrl": "https://localhost:7001;http://localhost:7000"
```

### CORS Errors

Ensure API CORS settings in `Program.cs` include your Blazor URL:
```csharp
policy.WithOrigins("https://localhost:5001", "http://localhost:5000")
```

## 📦 NuGet Packages Used

### MyApp.Core
- Microsoft.EntityFrameworkCore (8.0.0)
- Microsoft.EntityFrameworkCore.SqlServer (8.0.0)

### MyApp.Application
- AutoMapper (12.0.1)

### MyApp.WebApi
- Microsoft.EntityFrameworkCore.Design (8.0.0)
- Microsoft.EntityFrameworkCore.Tools (8.0.0)
- Swashbuckle.AspNetCore (6.5.0)

### MyApp.Client.Blazor
- Microsoft.AspNetCore.Components.WebAssembly (8.0.0)
- Refit.HttpClientFactory (7.0.0)

## 🎓 Learning Resources

This POC demonstrates:
- Clean Architecture principles
- Separation of Concerns
- Dependency Injection
- Repository Pattern (via EF Core)
- DTO Pattern
- Middleware Pipeline
- Global Exception Handling
- Async/Await best practices
- Type-safe HTTP clients with Refit

## 📝 License

This is a proof of concept for educational purposes.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the validation error messages
3. Check browser console for client-side errors
4. Check API logs for server-side errors

## ✅ Checklist for Deployment

- [ ] Change API signature secret in production
- [ ] Use proper connection string
- [ ] Enable HTTPS in production
- [ ] Add authentication/authorization
- [ ] Add rate limiting
- [ ] Add logging (Serilog, Application Insights)
- [ ] Add health checks
- [ ] Configure CORS for production domains
- [ ] Add caching where appropriate
- [ ] Set up CI/CD pipeline

---

**Built with ❤️ using ASP.NET Core 8.0 and Blazor WebAssembly**
