# Testing Guide

This document provides comprehensive testing scenarios for the POC.

## 🧪 Manual Testing Scenarios

### Scenario 1: Valid Product Creation

**Steps:**
1. Navigate to `https://localhost:5001/products`
2. Fill in the form:
   - Name: "Laptop"
   - Description: "High-performance laptop"
   - Price: 1299.99
   - Stock: 50
3. Click "Create Product"

**Expected Result:**
- ✅ Success message appears
- Product appears in the list
- Form clears

---

### Scenario 2: XSS Attack Prevention

**Steps:**
1. Navigate to products page
2. Fill in the form:
   - Name: `<script>alert('XSS')</script>Hacked`
   - Description: "Test"
   - Price: 99.99
   - Stock: 10
3. Click "Create Product"

**Expected Result:**
- ❌ Validation error: "The field Name contains potentially malicious content."
- Product NOT created
- Error displayed in red alert box

**Variations to Test:**
- `javascript:alert('XSS')` in name
- `<iframe src="evil.com">` in description
- `onclick=alert('XSS')` in any text field

---

### Scenario 3: SQL Injection Prevention

**Steps:**
1. Fill in the form:
   - Name: `Product'; DROP TABLE Products; --`
   - Description: "Test"
   - Price: 99.99
   - Stock: 10
2. Click "Create Product"

**Expected Result:**
- ❌ Validation error: "The field Name contains potentially dangerous SQL patterns."
- Product NOT created

**Variations to Test:**
- `1' OR '1'='1` in name
- `SELECT * FROM Users` in description

---

### Scenario 4: Required Field Validation

**Steps:**
1. Leave "Name" field empty
2. Fill other fields
3. Click "Create Product"

**Expected Result:**
- ❌ Client-side validation error under Name field
- Submit button may be disabled
- Red outline on Name input

**Test Each Required Field:**
- Name (required)
- Price (required)

---

### Scenario 5: Range Validation

**Test A: Negative Price**
- Name: "Test Product"
- Price: -10.00
- Stock: 10
- Expected: ❌ "Price must be between 0.01 and 999999.99"

**Test B: Zero Price**
- Price: 0.00
- Expected: ❌ "Price must be between 0.01 and 999999.99"

**Test C: Excessive Price**
- Price: 9999999.00
- Expected: ❌ "Price must be between 0.01 and 999999.99"

**Test D: Negative Stock**
- Stock: -5
- Expected: ❌ "Stock must be a positive number"

---

### Scenario 6: String Length Validation

**Test A: Name Too Short**
- Name: "AB" (only 2 characters)
- Expected: ❌ "Name must be between 3 and 100 characters"

**Test B: Name Too Long**
- Name: (101 characters - copy this)
  `AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`
- Expected: ❌ "Name must be between 3 and 100 characters"

**Test C: Description Too Long**
- Description: (501 characters)
- Expected: ❌ "Description cannot exceed 500 characters"

---

### Scenario 7: API Signature Validation

**Test A: Valid Signature**
1. Ensure both API and Client have same secret
2. Create a product
3. Expected: ✅ Success

**Test B: Invalid Signature**
1. Open `src/MyApp.Client.Blazor/wwwroot/appsettings.json`
2. Change secret to: `"WrongSecret123"`
3. Try to create a product
4. Expected: ❌ 401 Unauthorized
5. Error: "Request signature is invalid"

**Test C: Missing Signature**
1. Temporarily comment out signature header in `SignatureHandler.cs`:
   ```csharp
   // request.Headers.Add("X-Signature", signature);
   ```
2. Try to create a product
3. Expected: ❌ 401 Unauthorized
4. Error: "Request signature is required"

**Test D: Expired Timestamp**
1. In `SignatureHandler.cs`, modify timestamp:
   ```csharp
   var timestamp = DateTimeOffset.UtcNow.AddMinutes(-10).ToUnixTimeSeconds().ToString();
   ```
2. Try to create a product
3. Expected: ❌ 401 Unauthorized
4. Error: "Request has expired"

---

### Scenario 8: Input Sanitization Middleware

**Test A: Script Tag Removal**
1. Use browser dev tools or Postman
2. Send POST request to `https://localhost:7001/api/app/product`
3. Body:
   ```json
   {
     "name": "Product<script>alert('test')</script>Name",
     "price": 99.99,
     "stock": 10
   }
   ```
4. Check server logs
5. Expected: Warning log "Potentially malicious input detected and sanitized"
6. Script tags removed from input

---

### Scenario 9: Multiple Validation Errors

**Steps:**
1. Fill form with multiple invalid values:
   - Name: "AB" (too short)
   - Price: -10 (negative)
   - Stock: -5 (negative)
2. Click "Create Product"

**Expected Result:**
- ❌ Multiple validation errors displayed
- Each field shows its specific error
- No product created

---

### Scenario 10: Update and Delete

**Update Test:**
1. Create a valid product
2. Note the product ID
3. Use Swagger UI or modify the code to test update
4. Expected: ✅ Product updated successfully

**Delete Test:**
1. Click "Delete" button on a product
2. Expected: ✅ Product removed from list

---

## 🔍 API Testing with Swagger

### Access Swagger UI
Navigate to: `https://localhost:7001/swagger`

### Test Create Product
1. Expand `POST /api/app/product`
2. Click "Try it out"
3. Modify the request body
4. Click "Execute"
5. Check response

**Valid Request:**
```json
{
  "name": "Test Product",
  "description": "Test Description",
  "price": 99.99,
  "stock": 100
}
```

**Invalid Request (XSS):**
```json
{
  "name": "<script>alert('XSS')</script>",
  "description": "Test",
  "price": 99.99,
  "stock": 100
}
```

---

## 🔧 Testing with Postman

### Setup

1. Create a new collection "MyApp POC"
2. Base URL: `https://localhost:7001`
3. Add environment variable: `baseUrl` = `https://localhost:7001`

### Add Signature Headers (Pre-request Script)

```javascript
const crypto = require('crypto-js');

const secret = 'MySecretKey12345678901234567890123456789012';
const timestamp = Math.floor(Date.now() / 1000).toString();
const body = request.data || '';

const message = body + timestamp;
const signature = crypto.HmacSHA256(message, secret).toString(crypto.enc.Base64);

pm.request.headers.add({
    key: 'X-Signature',
    value: signature
});

pm.request.headers.add({
    key: 'X-Timestamp',
    value: timestamp
});
```

### Request: Create Product

**Method:** POST
**URL:** `{{baseUrl}}/api/app/product`
**Headers:**
- Content-Type: `application/json`
**Body (raw JSON):**
```json
{
  "name": "Postman Test Product",
  "description": "Created via Postman",
  "price": 299.99,
  "stock": 25
}
```

### Request: Get All Products

**Method:** GET
**URL:** `{{baseUrl}}/api/app/product`

### Request: Get Product by ID

**Method:** GET
**URL:** `{{baseUrl}}/api/app/product/{{productId}}`

### Request: Delete Product

**Method:** DELETE
**URL:** `{{baseUrl}}/api/app/product/{{productId}}`

---

## 🧰 Testing with cURL

### Create Product (with signature disabled)

```bash
curl -X POST "https://localhost:7001/api/app/product" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "cURL Test Product",
    "description": "Created via cURL",
    "price": 149.99,
    "stock": 75
  }' \
  --insecure
```

### Get All Products

```bash
curl -X GET "https://localhost:7001/api/app/product" \
  -H "accept: application/json" \
  --insecure
```

---

## 📊 Expected Error Responses

### Validation Error (400 Bad Request)

```json
{
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "One or more validation errors occurred.",
    "validationErrors": {
      "Name": [
        "The field Name contains potentially malicious content."
      ],
      "Price": [
        "Price must be between 0.01 and 999999.99"
      ]
    }
  }
}
```

### Signature Error (401 Unauthorized)

```json
{
  "error": {
    "code": "INVALID_SIGNATURE",
    "message": "Request signature is invalid"
  }
}
```

### Not Found (404)

```json
{
  "error": {
    "code": "KEYNOTFOUND",
    "message": "Product with ID {guid} not found"
  }
}
```

---

## ✅ Test Checklist

- [ ] Create product with valid data
- [ ] XSS attack prevention (script tags)
- [ ] XSS attack prevention (javascript:)
- [ ] XSS attack prevention (event handlers)
- [ ] SQL injection prevention
- [ ] Required field validation (Name)
- [ ] Required field validation (Price)
- [ ] Range validation (negative price)
- [ ] Range validation (zero price)
- [ ] Range validation (excessive price)
- [ ] Range validation (negative stock)
- [ ] String length (name too short)
- [ ] String length (name too long)
- [ ] String length (description too long)
- [ ] API signature validation (valid)
- [ ] API signature validation (invalid secret)
- [ ] API signature validation (missing headers)
- [ ] API signature validation (expired timestamp)
- [ ] Input sanitization (script removal)
- [ ] Multiple validation errors
- [ ] Get all products
- [ ] Get product by ID
- [ ] Delete product
- [ ] Update product

---

## 🎯 Performance Testing

### Load Testing with Apache Bench

```bash
# Test GET endpoint
ab -n 1000 -c 10 https://localhost:7001/api/app/product

# Expected: All requests should succeed (200 OK)
```

### Stress Testing

1. Create 100 products rapidly
2. Monitor memory usage
3. Check for memory leaks
4. Verify all validations still work under load

---

## 🐛 Debugging Tips

### Enable Detailed Logging

In `appsettings.Development.json`:
```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Debug",
      "Microsoft": "Debug",
      "MyApp": "Trace"
    }
  }
}
```

### Check Browser Console

- F12 → Console tab
- Look for network errors
- Check API response status codes

### Check Server Logs

Watch the terminal where the API is running for:
- Validation warnings
- Sanitization warnings
- Signature validation logs
- Exception stack traces

### Common Issues

1. **CORS errors**: Check API CORS configuration
2. **Signature mismatch**: Verify secrets match in both projects
3. **Database errors**: Ensure migrations are applied
4. **Port conflicts**: Change ports in launchSettings.json

---

**Happy Testing! 🚀**
