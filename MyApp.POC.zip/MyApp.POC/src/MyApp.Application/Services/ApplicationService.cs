using AutoMapper;
using Microsoft.Extensions.Logging;
using MyApp.Core.Interfaces;

namespace MyApp.Application.Services;

/// <summary>
/// Base class for all application services (similar to ABP's ApplicationService)
/// </summary>
public abstract class ApplicationService : IApplicationService
{
    protected ILogger Logger { get; }
    protected IMapper Mapper { get; }

    protected ApplicationService(ILogger logger, IMapper mapper)
    {
        Logger = logger;
        Mapper = mapper;
    }
}
