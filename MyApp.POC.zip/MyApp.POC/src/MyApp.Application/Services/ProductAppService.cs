using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MyApp.Core;
using MyApp.Core.DTOs;
using MyApp.Core.Entities;
using MyApp.Core.Interfaces;

namespace MyApp.Application.Services;

public class ProductAppService : ApplicationService, IProductAppService
{
    private readonly AppDbContext _dbContext;

    public ProductAppService(
        ILogger<ProductAppService> logger,
        IMapper mapper,
        AppDbContext dbContext) : base(logger, mapper)
    {
        _dbContext = dbContext;
    }

    public async Task<ProductDto> CreateAsync(CreateProductDto input)
    {
        Logger.LogInformation("Creating product: {Name}", input.Name);

        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = input.Name,
            Description = input.Description,
            Price = input.Price,
            Stock = input.Stock,
            CreatedAt = DateTime.UtcNow
        };

        _dbContext.Products.Add(product);
        await _dbContext.SaveChangesAsync();

        Logger.LogInformation("Product created successfully with ID: {Id}", product.Id);

        return Mapper.Map<ProductDto>(product);
    }

    public async Task<ProductDto> UpdateAsync(UpdateProductDto input)
    {
        Logger.LogInformation("Updating product: {Id}", input.Id);

        var product = await _dbContext.Products.FindAsync(input.Id);
        if (product == null)
        {
            throw new KeyNotFoundException($"Product with ID {input.Id} not found");
        }

        product.Name = input.Name;
        product.Description = input.Description;
        product.Price = input.Price;
        product.Stock = input.Stock;
        product.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync();

        Logger.LogInformation("Product updated successfully: {Id}", product.Id);

        return Mapper.Map<ProductDto>(product);
    }

    public async Task DeleteAsync(Guid id)
    {
        Logger.LogInformation("Deleting product: {Id}", id);

        var product = await _dbContext.Products.FindAsync(id);
        if (product == null)
        {
            throw new KeyNotFoundException($"Product with ID {id} not found");
        }

        _dbContext.Products.Remove(product);
        await _dbContext.SaveChangesAsync();

        Logger.LogInformation("Product deleted successfully: {Id}", id);
    }

    public async Task<ProductDto> GetAsync(Guid id)
    {
        Logger.LogInformation("Getting product: {Id}", id);

        var product = await _dbContext.Products.FindAsync(id);
        if (product == null)
        {
            throw new KeyNotFoundException($"Product with ID {id} not found");
        }

        return Mapper.Map<ProductDto>(product);
    }

    public async Task<List<ProductDto>> GetListAsync()
    {
        Logger.LogInformation("Getting all products");

        var products = await _dbContext.Products
            .OrderByDescending(p => p.CreatedAt)
            .ToListAsync();

        return Mapper.Map<List<ProductDto>>(products);
    }
}
