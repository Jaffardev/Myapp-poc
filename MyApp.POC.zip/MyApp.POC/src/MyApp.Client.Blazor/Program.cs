using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using MyApp.Client.Blazor;
using MyApp.Client.Blazor.Services;
using MyApp.Core.Interfaces;
using Refit;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// Register SignatureHandler
builder.Services.AddTransient<SignatureHandler>();

// Configure Refit client with signature handler
var apiBaseUrl = builder.Configuration["ApiSettings:BaseUrl"] ?? "https://localhost:7001";

builder.Services.AddRefitClient<IProductAppService>()
    .ConfigureHttpClient(client =>
    {
        client.BaseAddress = new Uri(apiBaseUrl);
    })
    .AddHttpMessageHandler<SignatureHandler>();

await builder.Build().RunAsync();
