using System.Security.Cryptography;
using System.Text;

namespace MyApp.Client.Blazor.Services;

public class SignatureHandler : DelegatingHandler
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<SignatureHandler> _logger;

    public SignatureHandler(IConfiguration configuration, ILogger<SignatureHandler> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        var signatureEnabled = _configuration.GetValue<bool>("ApiSignature:Enabled");

        if (signatureEnabled && request.RequestUri?.AbsolutePath.StartsWith("/api") == true)
        {
            var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
            var body = request.Content != null
                ? await request.Content.ReadAsStringAsync(cancellationToken)
                : string.Empty;

            var secret = _configuration["ApiSignature:Secret"] ?? string.Empty;
            var signature = GenerateSignature(body, timestamp, secret);

            request.Headers.Add("X-Signature", signature);
            request.Headers.Add("X-Timestamp", timestamp);

            _logger.LogDebug("Added signature to request: {Uri}", request.RequestUri);
        }

        return await base.SendAsync(request, cancellationToken);
    }

    private string GenerateSignature(string body, string timestamp, string secret)
    {
        var message = $"{body}{timestamp}";
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
        return Convert.ToBase64String(hash);
    }
}
