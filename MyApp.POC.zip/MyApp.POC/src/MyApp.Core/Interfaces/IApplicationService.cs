namespace MyApp.Core.Interfaces;

/// <summary>
/// Base interface for all application services (similar to ABP's IApplicationService)
/// </summary>
public interface IApplicationService
{
}
