using MyApp.Core.DTOs;

namespace MyApp.Core.Interfaces;

public interface IProductAppService : IApplicationService
{
    Task<ProductDto> CreateAsync(CreateProductDto input);
    Task<ProductDto> UpdateAsync(UpdateProductDto input);
    Task DeleteAsync(Guid id);
    Task<ProductDto> GetAsync(Guid id);
    Task<List<ProductDto>> GetListAsync();
}
