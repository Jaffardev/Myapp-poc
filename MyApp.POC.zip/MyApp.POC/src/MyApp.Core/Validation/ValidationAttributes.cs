using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace MyApp.Core.Validation;

public class SanitizedStringAttribute : ValidationAttribute
{
    private static readonly Regex DangerousPattern = new(
        @"<script|</script|javascript:|on\w+\s*=|<iframe|eval\(|expression\(",
        RegexOptions.IgnoreCase | RegexOptions.Compiled
    );

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is string str && !string.IsNullOrEmpty(str))
        {
            if (DangerousPattern.IsMatch(str))
            {
                return new ValidationResult(
                    $"The field {validationContext.DisplayName} contains potentially malicious content."
                );
            }
        }

        return ValidationResult.Success;
    }
}

public class NoSqlInjectionAttribute : ValidationAttribute
{
    private static readonly Regex SqlPattern = new(
        @"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)|('|--|\*|;)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled
    );

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is string str && !string.IsNullOrEmpty(str))
        {
            if (SqlPattern.IsMatch(str))
            {
                return new ValidationResult(
                    $"The field {validationContext.DisplayName} contains potentially dangerous SQL patterns."
                );
            }
        }

        return ValidationResult.Success;
    }
}
