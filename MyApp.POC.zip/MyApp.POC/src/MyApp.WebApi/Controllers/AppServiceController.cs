using Microsoft.AspNetCore.Mvc;
using MyApp.Core.Interfaces;

namespace MyApp.WebApi.Controllers;

/// <summary>
/// Base controller that auto-generates API endpoints from AppService
/// Similar to ABP's auto-controller generation
/// </summary>
[ApiController]
[Route("api/app/[controller]")]
public abstract class AppServiceController<TAppService> : ControllerBase
    where TAppService : IApplicationService
{
    protected TAppService AppService { get; }

    protected AppServiceController(TAppService appService)
    {
        AppService = appService;
    }
}
