using Microsoft.AspNetCore.Mvc;
using MyApp.Core.DTOs;
using MyApp.Core.Interfaces;

namespace MyApp.WebApi.Controllers;

/// <summary>
/// Product API Controller - auto-generated from IProductAppService
/// This follows the ABP pattern where controllers are automatically created from AppServices
/// </summary>
public class ProductController : AppServiceController<IProductAppService>
{
    public ProductController(IProductAppService appService) : base(appService)
    {
    }

    [HttpPost]
    public async Task<ActionResult<ProductDto>> Create([FromBody] CreateProductDto input)
    {
        var result = await AppService.CreateAsync(input);
        return CreatedAtAction(nameof(Get), new { id = result.Id }, result);
    }

    [HttpPut]
    public async Task<ActionResult<ProductDto>> Update([FromBody] UpdateProductDto input)
    {
        var result = await AppService.UpdateAsync(input);
        return Ok(result);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        await AppService.DeleteAsync(id);
        return NoContent();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProductDto>> Get(Guid id)
    {
        var result = await AppService.GetAsync(id);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<List<ProductDto>>> GetList()
    {
        var result = await AppService.GetListAsync();
        return Ok(result);
    }
}
