using MyApp.Application.Mapping;
using MyApp.Application.Services;
using MyApp.Core;
using MyApp.Core.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MyApp.WebApi.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Database
        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("Default")));

        // AutoMapper
        services.AddAutoMapper(typeof(ApplicationMappingProfile));

        // Application Services (similar to ABP's auto-registration)
        services.AddScoped<IProductAppService, ProductAppService>();

        return services;
    }
}
