using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace MyApp.WebApi.Filters;

public class GlobalModelValidationFilter : IAsyncActionFilter
{
    private readonly ILogger<GlobalModelValidationFilter> _logger;

    public GlobalModelValidationFilter(ILogger<GlobalModelValidationFilter> logger)
    {
        _logger = logger;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        if (!context.ModelState.IsValid)
        {
            var errors = context.ModelState
                .Where(x => x.Value!.Errors.Count > 0)
                .ToDictionary(
                    kvp => kvp.Key,
                    kvp => kvp.Value!.Errors.Select(e => e.ErrorMessage).ToArray()
                );

            _logger.LogWarning(
                "Model validation failed for {Action}. Errors: {@Errors}",
                context.ActionDescriptor.DisplayName,
                errors
            );

            context.Result = new BadRequestObjectResult(new
            {
                Error = new
                {
                    Code = "VALIDATION_FAILED",
                    Message = "One or more validation errors occurred.",
                    ValidationErrors = errors
                }
            });
            return;
        }

        await next();
    }
}
