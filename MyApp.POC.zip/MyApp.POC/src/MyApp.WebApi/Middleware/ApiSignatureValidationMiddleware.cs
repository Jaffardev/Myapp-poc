using System.Security.Cryptography;
using System.Text;

namespace MyApp.WebApi.Middleware;

public class ApiSignatureValidationMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IConfiguration _configuration;
    private readonly ILogger<ApiSignatureValidationMiddleware> _logger;

    // Paths that don't require signature validation
    private readonly string[] _excludedPaths = new[]
    {
        "/swagger",
        "/health"
    };

    public ApiSignatureValidationMiddleware(
        RequestDelegate next,
        IConfiguration configuration,
        ILogger<ApiSignatureValidationMiddleware> logger)
    {
        _next = next;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Skip signature validation for excluded paths
        if (_excludedPaths.Any(path => context.Request.Path.StartsWithSegments(path)))
        {
            await _next(context);
            return;
        }

        // Only validate API calls
        if (context.Request.Path.StartsWithSegments("/api"))
        {
            var signatureEnabled = _configuration.GetValue<bool>("ApiSignature:Enabled");

            if (signatureEnabled)
            {
                if (!context.Request.Headers.TryGetValue("X-Signature", out var signature) ||
                    !context.Request.Headers.TryGetValue("X-Timestamp", out var timestamp))
                {
                    _logger.LogWarning("Missing signature headers for {Path}", context.Request.Path);
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsJsonAsync(new
                    {
                        Error = new
                        {
                            Code = "MISSING_SIGNATURE",
                            Message = "Request signature is required"
                        }
                    });
                    return;
                }

                context.Request.EnableBuffering();
                using var reader = new StreamReader(context.Request.Body, Encoding.UTF8, leaveOpen: true);
                var body = await reader.ReadToEndAsync();
                context.Request.Body.Position = 0;

                var secret = _configuration["ApiSignature:Secret"] ?? string.Empty;
                var expectedSignature = GenerateSignature(body, timestamp!, secret);

                if (signature != expectedSignature)
                {
                    _logger.LogWarning("Invalid signature for {Path}", context.Request.Path);
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsJsonAsync(new
                    {
                        Error = new
                        {
                            Code = "INVALID_SIGNATURE",
                            Message = "Request signature is invalid"
                        }
                    });
                    return;
                }

                // Validate timestamp (prevent replay attacks)
                if (!ValidateTimestamp(timestamp!))
                {
                    _logger.LogWarning("Expired timestamp for {Path}", context.Request.Path);
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsJsonAsync(new
                    {
                        Error = new
                        {
                            Code = "REQUEST_EXPIRED",
                            Message = "Request has expired"
                        }
                    });
                    return;
                }

                _logger.LogInformation("Signature validated successfully for {Path}", context.Request.Path);
            }
        }

        await _next(context);
    }

    private string GenerateSignature(string body, string timestamp, string secret)
    {
        var message = $"{body}{timestamp}";
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
        return Convert.ToBase64String(hash);
    }

    private bool ValidateTimestamp(string timestamp)
    {
        if (!long.TryParse(timestamp, out var timestampValue))
        {
            return false;
        }

        var requestTime = DateTimeOffset.FromUnixTimeSeconds(timestampValue);
        var now = DateTimeOffset.UtcNow;

        // Allow 5 minutes window
        var diff = Math.Abs((now - requestTime).TotalMinutes);
        return diff <= 5;
    }
}
