using System.Text;
using System.Text.RegularExpressions;

namespace MyApp.WebApi.Middleware;

public class InputSanitizationMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<InputSanitizationMiddleware> _logger;

    private static readonly Regex ScriptPattern = new(
        @"<script[^>]*>.*?</script>",
        RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.Singleline
    );

    private static readonly Regex JavaScriptPattern = new(
        @"javascript:",
        RegexOptions.IgnoreCase | RegexOptions.Compiled
    );

    private static readonly Regex EventHandlerPattern = new(
        @"on\w+\s*=",
        RegexOptions.IgnoreCase | RegexOptions.Compiled
    );

    public InputSanitizationMiddleware(RequestDelegate next, ILogger<InputSanitizationMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Method == "POST" || context.Request.Method == "PUT")
        {
            if (context.Request.ContentType?.Contains("application/json") == true)
            {
                context.Request.EnableBuffering();

                using var reader = new StreamReader(context.Request.Body, Encoding.UTF8, leaveOpen: true);
                var body = await reader.ReadToEndAsync();
                context.Request.Body.Position = 0;

                var sanitized = SanitizeInput(body);

                if (body != sanitized)
                {
                    _logger.LogWarning(
                        "Potentially malicious input detected and sanitized for {Path}",
                        context.Request.Path
                    );

                    var bytes = Encoding.UTF8.GetBytes(sanitized);
                    context.Request.Body = new MemoryStream(bytes);
                    context.Request.ContentLength = bytes.Length;
                }
            }
        }

        await _next(context);
    }

    private string SanitizeInput(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;

        input = ScriptPattern.Replace(input, string.Empty);
        input = JavaScriptPattern.Replace(input, string.Empty);
        input = EventHandlerPattern.Replace(input, string.Empty);

        return input;
    }
}
