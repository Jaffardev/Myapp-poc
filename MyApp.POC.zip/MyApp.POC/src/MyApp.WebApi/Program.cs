using Microsoft.AspNetCore.Mvc;
using MyApp.WebApi.Extensions;
using MyApp.WebApi.Filters;
using MyApp.WebApi.Middleware;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers(options =>
{
    // Add global filters
    options.Filters.Add<GlobalModelValidationFilter>();
    options.Filters.Add<GlobalExceptionFilter>();
});

// Configure API behavior
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState
            .Where(x => x.Value!.Errors.Count > 0)
            .ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value!.Errors.Select(e => e.ErrorMessage).ToArray()
            );

        return new BadRequestObjectResult(new
        {
            Error = new
            {
                Code = "VALIDATION_FAILED",
                Message = "One or more validation errors occurred.",
                ValidationErrors = errors
            }
        });
    };
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add application services
builder.Services.AddApplicationServices(builder.Configuration);

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.WithOrigins("https://localhost:5001", "http://localhost:5000")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Add custom middleware (order matters!)
app.UseMiddleware<ApiSignatureValidationMiddleware>();
app.UseMiddleware<InputSanitizationMiddleware>();

app.UseCors();
app.UseAuthorization();
app.MapControllers();

app.Run();
