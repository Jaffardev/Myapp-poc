# Quick Start Guide

## Step-by-Step Installation

### 1. Install NuGet Packages

Open your terminal in the Blazor project directory and run:

```bash
dotnet add package MiniExcel
dotnet add package System.Linq.Dynamic.Core
```

### 2. Copy Component Files

Copy the following files to your project:

**Components folder:**
- `Components/UltimateGrid.razor`
- `Components/UltimateGrid.razor.css`
- `Components/GridColumn.razor`

**Models/Root folder:**
- `GridReadEventArgs.cs`

**wwwroot folder:**
- `wwwroot/js/ultimateGrid.js`

### 3. Add JavaScript Reference

**For Blazor WebAssembly** - Edit `wwwroot/index.html`:
```html
<!DOCTYPE html>
<html>
<head>
    <!-- ... existing head content ... -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <!-- ... existing body content ... -->
    
    <script src="_framework/blazor.webassembly.js"></script>
    <script src="js/ultimateGrid.js"></script> <!-- Add this line -->
</body>
</html>
```

**For Blazor Server** - Edit `Pages/_Host.cshtml` or `Pages/_Layout.cshtml`:
```html
<!DOCTYPE html>
<html>
<head>
    <!-- ... existing head content ... -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <!-- ... existing body content ... -->
    
    <script src="_framework/blazor.server.js"></script>
    <script src="js/ultimateGrid.js"></script> <!-- Add this line -->
</body>
</html>
```

### 4. Add Using Statement (Optional)

Edit `_Imports.razor` to add the component namespace globally:

```razor
@using YourProjectName.Components
```

Replace `YourProjectName` with your actual project namespace.

### 5. Create Your First Grid

Create a new Blazor page or component:

```razor
@page "/mygrid"

<h3>My First Grid</h3>

<UltimateGrid TItem="MyDataModel" OnRead="LoadData" PageSize="10">
    <Columns>
        <GridColumn TItem="MyDataModel" Title="ID" Property="@(x => x.Id)" />
        <GridColumn TItem="MyDataModel" Title="Name" Property="@(x => x.Name)" />
    </Columns>
</UltimateGrid>

@code {
    private UltimateGrid<MyDataModel> _grid;

    private async Task LoadData(GridReadEventArgs args)
    {
        // Your data loading logic
        var data = await GetYourDataAsync(args.Page, args.PageSize);
        _grid.LoadData(data);
    }

    private async Task<List<MyDataModel>> GetYourDataAsync(int page, int pageSize)
    {
        // Replace with your actual data source
        return await Task.FromResult(new List<MyDataModel>
        {
            new MyDataModel { Id = 1, Name = "Item 1" },
            new MyDataModel { Id = 2, Name = "Item 2" }
        });
    }

    public class MyDataModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
```

### 6. Test It!

Run your application:

```bash
dotnet run
```

Navigate to your grid page and you should see:
- ✅ Search box with debouncing
- ✅ Filter toggle button
- ✅ Export to Excel button
- ✅ Dark-themed grid
- ✅ Pagination controls

## Troubleshooting

### JavaScript not found
- Make sure `ultimateGrid.js` is in `wwwroot/js/`
- Verify the script tag is added to your HTML file
- Try hard-refresh (Ctrl+F5) to clear browser cache

### Icons not showing
- Verify Bootstrap Icons CDN link is in your HTML `<head>`
- Check browser console for 404 errors

### Excel export not working
- Confirm MiniExcel package is installed
- Check browser console for JavaScript errors
- Verify the `downloadFile` function is defined

### Styles not applying
- Make sure `UltimateGrid.razor.css` is in the same folder as `UltimateGrid.razor`
- Rebuild the project to regenerate scoped CSS
- Check that CSS isolation is enabled (default in Blazor)

## Next Steps

Check out `ExampleUsage.razor` for advanced features:
- Custom cell templates
- Badge styling
- Action buttons
- Conditional formatting

## Need Help?

Refer to `README.md` for complete API documentation and advanced examples.
