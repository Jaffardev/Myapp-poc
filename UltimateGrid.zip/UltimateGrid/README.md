# UltimateGrid - Blazor Data Grid Component

A modern, feature-rich Blazor data grid component with dark mode styling, search, filtering, pagination, and Excel export capabilities.

## Features

- 🔍 **Global Search** with debouncing (450ms)
- 🎯 **Column-specific Filtering**
- 📄 **Pagination** with navigation controls
- 📊 **Excel Export** with template support
- 🌙 **Dark Mode** professional UI
- ⚡ **Performance Optimized** with async operations
- 🎨 **Customizable** templates and styling

## Installation

### 1. NuGet Packages Required

```bash
dotnet add package MiniExcel
dotnet add package System.Linq.Dynamic.Core
```

### 2. File Structure

Copy the files to your Blazor project:

```
YourBlazorProject/
├── Components/
│   ├── UltimateGrid.razor
│   ├── UltimateGrid.razor.css
│   └── GridColumn.razor
├── Models/
│   └── GridReadEventArgs.cs
└── wwwroot/
    ├── js/
    │   └── ultimateGrid.js
    └── templates/  (optional - for Excel templates)
        └── YourTemplate.xlsx
```

### 3. Add JavaScript Reference

Add to your `index.html` (Blazor WebAssembly) or `_Host.cshtml` (Blazor Server):

```html
<script src="js/ultimateGrid.js"></script>
```

Or for Bootstrap Icons:
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
```

### 4. Excel Template Setup (Optional)

If using Excel templates:
1. Place your `.xlsx` template in `wwwroot/templates/`
2. Right-click the file → Properties → Copy to Output Directory: **Copy if newer**

## Usage Example

### Basic Implementation

```razor
@page "/products"
@using YourNamespace.Components

<UltimateGrid TItem="Product" OnRead="LoadData" PageSize="10">
    <Columns>
        <GridColumn TItem="Product" Title="ID" Property="@(p => p.Id)" />
        <GridColumn TItem="Product" Title="Name" Property="@(p => p.Name)" />
        <GridColumn TItem="Product" Title="Price">
            <ChildContent Context="product">
                <span class="badge bg-success">$@product.Price.ToString("F2")</span>
            </ChildContent>
        </GridColumn>
        <GridColumn TItem="Product" Title="Actions">
            <ChildContent Context="product">
                <button class="btn btn-sm btn-primary" @onclick="() => EditProduct(product)">
                    <i class="bi bi-pencil"></i>
                </button>
            </ChildContent>
        </GridColumn>
    </Columns>
</UltimateGrid>

@code {
    private UltimateGrid<Product> _grid;
    
    private async Task LoadData(GridReadEventArgs args)
    {
        // Your data loading logic here
        var query = GetProductsQuery();
        
        // Apply search
        if (!string.IsNullOrEmpty(args.SearchTerm))
        {
            query = query.Where(p => 
                p.Name.Contains(args.SearchTerm, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(args.SearchTerm, StringComparison.OrdinalIgnoreCase)
            );
        }
        
        // Apply column filters
        foreach (var filter in args.ColumnFilters)
        {
            if (!string.IsNullOrEmpty(filter.Value))
            {
                // Apply filter based on column name
                query = filter.Key switch
                {
                    "Name" => query.Where(p => p.Name.Contains(filter.Value)),
                    "Category" => query.Where(p => p.Category.Contains(filter.Value)),
                    _ => query
                };
            }
        }
        
        // Apply pagination
        var data = await query
            .Skip((args.Page - 1) * args.PageSize)
            .Take(args.PageSize)
            .ToListAsync();
        
        _grid.LoadData(data);
    }
}
```

### Advanced: Excel Export with Template

```razor
<UltimateGrid TItem="Product" 
              OnRead="LoadData" 
              TemplatePath="templates/ProductTemplate.xlsx"
              GetDynamicFileName="@(() => $"Products_{DateTime.Now:yyyyMMdd}.xlsx")">
    <Columns>
        <!-- Your columns -->
    </Columns>
</UltimateGrid>
```

### Custom Header Template

```razor
<GridColumn TItem="Product" Title="Status">
    <HeaderTemplate>
        <i class="bi bi-flag-fill"></i> Status
    </HeaderTemplate>
    <ChildContent Context="product">
        @product.Status
    </ChildContent>
</GridColumn>
```

## Component Parameters

### UltimateGrid

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `OnRead` | `EventCallback<GridReadEventArgs>` | - | Callback when data needs to be loaded |
| `Columns` | `RenderFragment` | - | Column definitions |
| `TemplatePath` | `string?` | `null` | Path to Excel template (relative to wwwroot) |
| `GetDynamicFileName` | `Func<string>?` | `null` | Function to generate export filename |
| `PageSize` | `int` | `10` | Number of items per page |

### GridColumn

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `Title` | `string` | `""` | Column header text |
| `Property` | `Func<TItem, object>?` | `null` | Property accessor for simple display |
| `ChildContent` | `RenderFragment<TItem>?` | `null` | Custom content template |
| `HeaderTemplate` | `RenderFragment?` | `null` | Custom header template |

## Public Methods

### UltimateGrid

- `Task Refresh()` - Manually trigger data refresh
- `void LoadData(IEnumerable<TItem> data)` - Load data into grid

## Styling Customization

Override CSS variables in your global stylesheet:

```css
.ultimate-grid {
    --grid-bg: #1a1a1b;
    --grid-border: #333;
    --header-bg: #121212;
    --row-hover: #252526;
    --accent-color: #00ffcc;
}
```

## Browser Support

- Chrome/Edge (recommended)
- Firefox
- Safari
- Modern browsers with ES6+ support

## License

This component is provided as-is for use in your projects.

## Support

For issues or questions, please refer to the documentation or create an issue in the repository.
