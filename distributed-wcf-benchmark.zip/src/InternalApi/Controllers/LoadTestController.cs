using System.Diagnostics;
using InternalApi.Infrastructure;
using InternalApi.Services;
using Microsoft.AspNetCore.Mvc;
using Shared.Models;

namespace InternalApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class LoadTestController : ControllerBase
{
    private readonly GoodOrderService _goodService;
    private readonly BadOrderService _badService;
    private readonly BenchmarkMetrics _metrics;
    private readonly ILogger<LoadTestController> _logger;

    public LoadTestController(
        GoodOrderService goodService,
        BadOrderService badService,
        BenchmarkMetrics metrics,
        ILogger<LoadTestController> logger)
    {
        _goodService = goodService;
        _badService = badService;
        _metrics = metrics;
        _logger = logger;
    }

    /// <summary>
    /// Runs a configurable load test in either good or bad mode.
    /// Returns aggregated latency statistics.
    /// </summary>
    [HttpPost("run")]
    [ProducesResponseType(typeof(LoadTestResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> RunLoadTestAsync(
        [FromBody] LoadTestRequest loadRequest,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation(
            "Load test started: Mode={Mode}, Concurrent={Concurrent}, Total={Total}",
            loadRequest.Mode, loadRequest.ConcurrentRequests, loadRequest.TotalRequests);

        // Cap to reasonable limits to protect the server
        var totalRequests = Math.Min(loadRequest.TotalRequests, 1000);
        var concurrentRequests = Math.Min(loadRequest.ConcurrentRequests, 100);

        var sw = Stopwatch.StartNew();
        var latencies = new System.Collections.Concurrent.ConcurrentBag<long>();
        var successCount = 0;
        var failureCount = 0;

        var semaphore = new SemaphoreSlim(concurrentRequests, concurrentRequests);
        var tasks = new List<Task>();

        for (int i = 0; i < totalRequests; i++)
        {
            int requestIndex = i;
            tasks.Add(Task.Run(async () =>
            {
                await semaphore.WaitAsync(cancellationToken);
                try
                {
                    var reqSw = Stopwatch.StartNew();
                    var baseRequest = new BenchmarkRequest
                    {
                        CustomerId = $"CUST-{requestIndex % 100:D3}",
                        Amount = 100m + (requestIndex % 50),
                        ProductCode = $"PROD-{(char)('A' + requestIndex % 26)}"
                    };

                    string? idempotencyKey = loadRequest.UseIdempotency
                        ? $"loadtest-{requestIndex % (totalRequests / 2)}" // 50% will be duplicates
                        : null;

                    if (loadRequest.Mode.Equals("good", StringComparison.OrdinalIgnoreCase))
                        await _goodService.ProcessOrderAsync(baseRequest, idempotencyKey, cancellationToken);
                    else
                        await _badService.ProcessOrderAsync(baseRequest, cancellationToken);

                    reqSw.Stop();
                    latencies.Add(reqSw.ElapsedMilliseconds);
                    Interlocked.Increment(ref successCount);
                }
                catch (Exception ex)
                {
                    _logger.LogDebug("Load test request failed: {Error}", ex.Message);
                    Interlocked.Increment(ref failureCount);
                    latencies.Add(-1); // Mark as failed
                }
                finally
                {
                    semaphore.Release();
                }
            }, cancellationToken));
        }

        await Task.WhenAll(tasks);
        sw.Stop();

        var validLatencies = latencies.Where(l => l >= 0).OrderBy(l => l).ToList();

        var result = new LoadTestResult
        {
            TotalRequests = totalRequests,
            SuccessCount = successCount,
            FailureCount = failureCount,
            Mode = loadRequest.Mode,
            TotalDurationMs = sw.ElapsedMilliseconds,
            Latencies = validLatencies,
            AvgLatencyMs = validLatencies.Count > 0 ? validLatencies.Average() : 0,
            MinLatencyMs = validLatencies.Count > 0 ? validLatencies.Min() : 0,
            MaxLatencyMs = validLatencies.Count > 0 ? validLatencies.Max() : 0,
            P95LatencyMs = validLatencies.Count > 0
                ? validLatencies[(int)(validLatencies.Count * 0.95)]
                : 0,
            P99LatencyMs = validLatencies.Count > 0
                ? validLatencies[(int)(validLatencies.Count * 0.99)]
                : 0,
            RequestsPerSecond = sw.ElapsedMilliseconds > 0
                ? totalRequests / (sw.ElapsedMilliseconds / 1000.0)
                : 0
        };

        _logger.LogInformation(
            "Load test complete: Mode={Mode}, Success={Success}/{Total}, " +
            "AvgMs={Avg:F0}, P95={P95:F0}, RPS={RPS:F1}",
            result.Mode, result.SuccessCount, result.TotalRequests,
            result.AvgLatencyMs, result.P95LatencyMs, result.RequestsPerSecond);

        return Ok(result);
    }
}
