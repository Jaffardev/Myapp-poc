using System.Diagnostics;
using InternalApi.Infrastructure;
using InternalApi.Services;
using Microsoft.AspNetCore.Mvc;
using Shared.Models;

namespace InternalApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class OrderController : ControllerBase
{
    private readonly GoodOrderService _goodService;
    private readonly BadOrderService _badService;
    private readonly ResiliencePolicies _resilience;
    private readonly BenchmarkMetrics _metrics;
    private readonly ILogger<OrderController> _logger;

    public OrderController(
        GoodOrderService goodService,
        BadOrderService badService,
        ResiliencePolicies resilience,
        BenchmarkMetrics metrics,
        ILogger<OrderController> logger)
    {
        _goodService = goodService;
        _badService = badService;
        _resilience = resilience;
        _metrics = metrics;
        _logger = logger;
    }

    /// <summary>
    /// GOOD MODE: Process an order with all resilience patterns applied.
    /// Supports Idempotency-Key header to prevent duplicate processing.
    /// </summary>
    [HttpPost("good")]
    [ProducesResponseType(typeof(BenchmarkResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> ProcessGoodAsync(
        [FromBody] BenchmarkRequest request,
        [FromHeader(Name = "Idempotency-Key")] string? idempotencyKey,
        CancellationToken cancellationToken)
    {
        _metrics.ApiRequestsTotal.Add(1,
            new KeyValuePair<string, object?>("mode", "good"),
            new KeyValuePair<string, object?>("endpoint", "/api/order/good"));

        try
        {
            var result = await _goodService.ProcessOrderAsync(request, idempotencyKey, cancellationToken);
            return Ok(result);
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("lock"))
        {
            return StatusCode(StatusCodes.Status429TooManyRequests,
                new { error = "Request already in progress", detail = ex.Message });
        }
        catch (Polly.CircuitBreaker.BrokenCircuitException ex)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable,
                new { error = "Circuit breaker open - WCF service unavailable", detail = ex.Message });
        }
        catch (TimeoutException ex)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable,
                new { error = "WCF bulkhead full - too many concurrent requests", detail = ex.Message });
        }
    }

    /// <summary>
    /// BAD MODE: Process an order with anti-patterns (new WCF client per request, no caching).
    /// This intentionally demonstrates poor architecture for benchmarking comparison.
    /// </summary>
    [HttpPost("bad")]
    [ProducesResponseType(typeof(BenchmarkResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ProcessBadAsync(
        [FromBody] BenchmarkRequest request,
        CancellationToken cancellationToken)
    {
        _metrics.ApiRequestsTotal.Add(1,
            new KeyValuePair<string, object?>("mode", "bad"),
            new KeyValuePair<string, object?>("endpoint", "/api/order/bad"));

        try
        {
            var result = await _badService.ProcessOrderAsync(request, cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { error = "BAD MODE failure (expected under load)", detail = ex.Message });
        }
    }

    /// <summary>
    /// Returns current system status including circuit breaker state and metrics.
    /// </summary>
    [HttpGet("status")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetStatus()
    {
        return Ok(new
        {
            circuitBreaker = _resilience.CircuitBreakerState,
            timestamp = DateTime.UtcNow,
            version = "1.0.0"
        });
    }
}
