using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace InternalApi.Infrastructure;

/// <summary>
/// OpenTelemetry metrics and tracing instrumentation.
/// Exposes Prometheus-compatible metrics for dashboards.
/// </summary>
public sealed class BenchmarkMetrics : IDisposable
{
    public static readonly ActivitySource ActivitySource = new("InternalApi");
    private static readonly Meter Meter = new("InternalApi", "1.0.0");

    // Counters
    public readonly Counter<long> ApiRequestsTotal;
    public readonly Counter<long> WcfCallsTotal;
    public readonly Counter<long> IdempotencyHitsTotal;
    public readonly Counter<long> LocksAcquiredTotal;
    public readonly Counter<long> LockFailuresTotal;
    public readonly Counter<long> CircuitBreakerTripsTotal;
    public readonly Counter<long> RetriesTotal;
    public readonly Counter<long> BadModeRequestsTotal;
    public readonly Counter<long> GoodModeRequestsTotal;

    // Histograms
    public readonly Histogram<double> RequestDurationMs;
    public readonly Histogram<double> WcfCallDurationMs;

    // Gauges (observable)
    private long _activeRequests;
    private long _bulkheadAvailable;

    public BenchmarkMetrics()
    {
        ApiRequestsTotal = Meter.CreateCounter<long>(
            "api_requests_total",
            description: "Total API requests processed");

        WcfCallsTotal = Meter.CreateCounter<long>(
            "wcf_calls_total",
            description: "Total WCF service calls made");

        IdempotencyHitsTotal = Meter.CreateCounter<long>(
            "idempotency_hits_total",
            description: "Total idempotency cache hits (duplicate requests blocked)");

        LocksAcquiredTotal = Meter.CreateCounter<long>(
            "distributed_locks_acquired_total",
            description: "Total distributed locks acquired");

        LockFailuresTotal = Meter.CreateCounter<long>(
            "distributed_lock_failures_total",
            description: "Total distributed lock acquisition failures");

        CircuitBreakerTripsTotal = Meter.CreateCounter<long>(
            "circuit_breaker_trips_total",
            description: "Total circuit breaker open events");

        RetriesTotal = Meter.CreateCounter<long>(
            "polly_retries_total",
            description: "Total Polly retry attempts");

        BadModeRequestsTotal = Meter.CreateCounter<long>(
            "bad_mode_requests_total",
            description: "Total requests handled in BAD mode");

        GoodModeRequestsTotal = Meter.CreateCounter<long>(
            "good_mode_requests_total",
            description: "Total requests handled in GOOD mode");

        RequestDurationMs = Meter.CreateHistogram<double>(
            "request_duration_ms",
            unit: "ms",
            description: "API request duration in milliseconds");

        WcfCallDurationMs = Meter.CreateHistogram<double>(
            "wcf_call_duration_ms",
            unit: "ms",
            description: "WCF call duration in milliseconds");

        // Observable gauge for active requests
        Meter.CreateObservableGauge(
            "active_requests",
            () => Interlocked.Read(ref _activeRequests),
            description: "Currently active API requests");
    }

    public void IncrementActiveRequests() => Interlocked.Increment(ref _activeRequests);
    public void DecrementActiveRequests() => Interlocked.Decrement(ref _activeRequests);
    public void SetBulkheadAvailable(long value) => Interlocked.Exchange(ref _bulkheadAvailable, value);

    public void Dispose() => Meter.Dispose();
}
