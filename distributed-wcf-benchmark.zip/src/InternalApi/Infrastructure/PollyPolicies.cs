using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;
using Polly.Wrap;
using System.ServiceModel;

namespace InternalApi.Infrastructure;

/// <summary>
/// Polly resilience policies for WCF service calls.
/// Implements retry (idempotent only), circuit breaker, and bulkhead patterns.
/// </summary>
public static class PollyPolicies
{
    private static ILogger? _logger;

    public static void SetLogger(ILogger logger) => _logger = logger;

    /// <summary>
    /// Retry policy for idempotent operations only.
    /// Retries on transient failures with exponential backoff + jitter.
    /// </summary>
    public static AsyncRetryPolicy CreateRetryPolicy(int maxRetries = 3)
    {
        return Policy
            .Handle<CommunicationException>()
            .Or<TimeoutException>()
            .Or<FaultException>(ex => IsTransient(ex))
            .WaitAndRetryAsync(
                maxRetries,
                attempt => TimeSpan.FromMilliseconds(
                    Math.Pow(2, attempt) * 100 + Random.Shared.Next(0, 100)),
                onRetry: (exception, timeSpan, attempt, context) =>
                {
                    _logger?.LogWarning(
                        "WCF retry {Attempt}/{Max} after {Delay}ms. Error: {Error}",
                        attempt, maxRetries, timeSpan.TotalMilliseconds, exception.Message);
                });
    }

    /// <summary>
    /// Circuit breaker to prevent cascading failures.
    /// Opens after 5 consecutive failures, stays open for 30 seconds.
    /// </summary>
    public static AsyncCircuitBreakerPolicy CreateCircuitBreakerPolicy()
    {
        return Policy
            .Handle<CommunicationException>()
            .Or<TimeoutException>()
            .Or<FaultException>(ex => IsTransient(ex))
            .CircuitBreakerAsync(
                exceptionsAllowedBeforeBreaking: 5,
                durationOfBreak: TimeSpan.FromSeconds(30),
                onBreak: (exception, breakDelay) =>
                {
                    _logger?.LogError(
                        "Circuit breaker OPENED for {Delay}s. Cause: {Error}",
                        breakDelay.TotalSeconds, exception.Message);
                },
                onReset: () =>
                {
                    _logger?.LogInformation("Circuit breaker RESET - service recovered");
                },
                onHalfOpen: () =>
                {
                    _logger?.LogInformation("Circuit breaker HALF-OPEN - testing service");
                });
    }

    /// <summary>
    /// Combined policy: Retry wrapped around Circuit Breaker.
    /// Circuit breaker is outermost so retries don't reset it.
    /// </summary>
    public static AsyncPolicyWrap CreateCombinedPolicy(int maxRetries = 3)
    {
        var retry = CreateRetryPolicy(maxRetries);
        var circuitBreaker = CreateCircuitBreakerPolicy();
        return Policy.WrapAsync(retry, circuitBreaker);
    }

    private static bool IsTransient(FaultException ex)
    {
        return ex.Message.Contains("overload", StringComparison.OrdinalIgnoreCase)
            || ex.Message.Contains("timeout", StringComparison.OrdinalIgnoreCase)
            || ex.Message.Contains("unavailable", StringComparison.OrdinalIgnoreCase);
    }
}

/// <summary>
/// Singleton holder for circuit breaker state (shared across requests).
/// </summary>
public sealed class ResiliencePolicies
{
    public AsyncPolicyWrap CombinedPolicy { get; }
    public AsyncRetryPolicy RetryPolicy { get; }
    public AsyncCircuitBreakerPolicy CircuitBreakerPolicy { get; }

    public ResiliencePolicies(ILogger<ResiliencePolicies> logger)
    {
        PollyPolicies.SetLogger(logger);
        RetryPolicy = PollyPolicies.CreateRetryPolicy();
        CircuitBreakerPolicy = PollyPolicies.CreateCircuitBreakerPolicy();
        CombinedPolicy = PollyPolicies.CreateCombinedPolicy();
    }

    public string CircuitBreakerState =>
        CircuitBreakerPolicy.CircuitState switch
        {
            CircuitState.Closed => "Closed (Healthy)",
            CircuitState.Open => "Open (Failing)",
            CircuitState.HalfOpen => "Half-Open (Testing)",
            _ => "Unknown"
        };
}
