using StackExchange.Redis;

namespace InternalApi.Infrastructure;

/// <summary>
/// Redis-based distributed lock using SET NX pattern.
/// Prevents concurrent processing of the same idempotency key across multiple instances.
/// </summary>
public sealed class RedisDistributedLock : IAsyncDisposable
{
    private readonly IDatabase _db;
    private readonly string _lockKey;
    private readonly string _lockValue;
    private bool _acquired;
    private bool _disposed;

    private const string LockPrefix = "lock:";

    private RedisDistributedLock(IDatabase db, string lockKey, string lockValue, bool acquired)
    {
        _db = db;
        _lockKey = lockKey;
        _lockValue = lockValue;
        _acquired = acquired;
    }

    public bool IsAcquired => _acquired;

    /// <summary>
    /// Attempts to acquire a distributed lock using SET NX (SET if Not eXists).
    /// </summary>
    public static async Task<RedisDistributedLock> AcquireAsync(
        IDatabase db,
        string resource,
        TimeSpan lockTtl,
        TimeSpan waitTimeout,
        CancellationToken cancellationToken = default)
    {
        var lockKey = $"{LockPrefix}{resource}";
        var lockValue = Guid.NewGuid().ToString("N");
        var deadline = DateTime.UtcNow.Add(waitTimeout);

        while (DateTime.UtcNow < deadline && !cancellationToken.IsCancellationRequested)
        {
            // SET NX pattern: Set only if key does not exist
            var acquired = await db.StringSetAsync(
                lockKey,
                lockValue,
                lockTtl,
                When.NotExists);

            if (acquired)
                return new RedisDistributedLock(db, lockKey, lockValue, true);

            // Wait before retrying (exponential backoff with jitter)
            var delay = TimeSpan.FromMilliseconds(50 + Random.Shared.Next(0, 50));
            await Task.Delay(delay, cancellationToken);
        }

        return new RedisDistributedLock(db, lockKey, lockValue, false);
    }

    /// <summary>
    /// Releases the lock only if we own it (checks lock value).
    /// Uses Lua script for atomic check-and-delete.
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        if (_disposed || !_acquired) return;
        _disposed = true;

        // Lua script: only delete if the value matches (we own the lock)
        const string luaScript = @"
            if redis.call('get', KEYS[1]) == ARGV[1] then
                return redis.call('del', KEYS[1])
            else
                return 0
            end";

        try
        {
            await _db.ScriptEvaluateAsync(luaScript,
                new RedisKey[] { _lockKey },
                new RedisValue[] { _lockValue });
        }
        catch
        {
            // Best effort release - lock will expire via TTL anyway
        }
    }
}

/// <summary>
/// Factory for creating distributed locks.
/// </summary>
public sealed class RedisDistributedLockFactory
{
    private readonly IConnectionMultiplexer _redis;
    private readonly ILogger<RedisDistributedLockFactory> _logger;

    public RedisDistributedLockFactory(
        IConnectionMultiplexer redis,
        ILogger<RedisDistributedLockFactory> logger)
    {
        _redis = redis;
        _logger = logger;
    }

    public async Task<RedisDistributedLock> AcquireAsync(
        string resource,
        TimeSpan? lockTtl = null,
        TimeSpan? waitTimeout = null,
        CancellationToken cancellationToken = default)
    {
        var db = _redis.GetDatabase();
        var ttl = lockTtl ?? TimeSpan.FromSeconds(30);
        var timeout = waitTimeout ?? TimeSpan.FromSeconds(5);

        _logger.LogDebug("Acquiring lock: {Resource}", resource);

        var @lock = await RedisDistributedLock.AcquireAsync(db, resource, ttl, timeout, cancellationToken);

        if (!@lock.IsAcquired)
            _logger.LogWarning("Failed to acquire lock: {Resource}", resource);
        else
            _logger.LogDebug("Lock acquired: {Resource}", resource);

        return @lock;
    }
}
