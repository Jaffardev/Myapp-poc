using StackExchange.Redis;
using System.Text.Json;

namespace InternalApi.Infrastructure;

/// <summary>
/// Redis-backed idempotency store to prevent duplicate WCF calls.
/// Stores results by idempotency key with TTL.
/// </summary>
public sealed class RedisIdempotencyStore
{
    private readonly IDatabase _db;
    private readonly ILogger<RedisIdempotencyStore> _logger;
    private static readonly TimeSpan DefaultTtl = TimeSpan.FromHours(24);
    private const string KeyPrefix = "idempotency:";

    public RedisIdempotencyStore(IConnectionMultiplexer redis, ILogger<RedisIdempotencyStore> logger)
    {
        _db = redis.GetDatabase();
        _logger = logger;
    }

    public async Task<T?> GetAsync<T>(string idempotencyKey) where T : class
    {
        var redisKey = $"{KeyPrefix}{idempotencyKey}";
        try
        {
            var value = await _db.StringGetAsync(redisKey);
            if (value.IsNullOrEmpty)
                return null;

            _logger.LogDebug("Idempotency cache hit: {Key}", idempotencyKey);
            return JsonSerializer.Deserialize<T>(value!);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Redis read error for key {Key}", idempotencyKey);
            return null; // Fail open - don't block the request
        }
    }

    public async Task SetAsync<T>(string idempotencyKey, T value, TimeSpan? ttl = null) where T : class
    {
        var redisKey = $"{KeyPrefix}{idempotencyKey}";
        try
        {
            var json = JsonSerializer.Serialize(value);
            await _db.StringSetAsync(redisKey, json, ttl ?? DefaultTtl);
            _logger.LogDebug("Stored idempotency result: {Key}", idempotencyKey);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Redis write error for key {Key}", idempotencyKey);
            // Fail open - result may be processed again, but don't crash
        }
    }

    public async Task<bool> ExistsAsync(string idempotencyKey)
    {
        var redisKey = $"{KeyPrefix}{idempotencyKey}";
        try
        {
            return await _db.KeyExistsAsync(redisKey);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Redis exists check error for key {Key}", idempotencyKey);
            return false;
        }
    }
}
