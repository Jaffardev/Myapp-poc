using System.Diagnostics;
using System.ServiceModel;
using Shared.Contracts;

namespace InternalApi.Infrastructure;

/// <summary>
/// Centralized WCF client manager with connection pooling and lifecycle management.
/// GOOD PATTERN: Single managed client with proper channel factory reuse.
/// </summary>
public sealed class WcfClientManager : IAsyncDisposable
{
    private readonly ILogger<WcfClientManager> _logger;
    private readonly string _endpointAddress;
    private readonly SemaphoreSlim _bulkhead;
    private ChannelFactory<IOrderService>? _channelFactory;
    private readonly object _factoryLock = new();
    private volatile bool _disposed;

    // Metrics
    private static long _activeConnections = 0;
    private static long _totalCreated = 0;

    public WcfClientManager(ILogger<WcfClientManager> logger, IConfiguration configuration)
    {
        _logger = logger;
        _endpointAddress = configuration["WcfService:Endpoint"]
            ?? "http://wcf-service:8080/OrderService";

        // GOOD: Bulkhead pattern - limit concurrent WCF calls
        int maxConcurrent = configuration.GetValue<int>("WcfService:MaxConcurrentCalls", 50);
        _bulkhead = new SemaphoreSlim(maxConcurrent, maxConcurrent);

        _logger.LogInformation("WcfClientManager initialized. Endpoint={Endpoint}, MaxConcurrent={Max}",
            _endpointAddress, maxConcurrent);
    }

    /// <summary>
    /// Acquires a WCF channel from the shared factory (bulkhead-protected).
    /// </summary>
    public async Task<T> ExecuteAsync<T>(
        Func<IOrderService, Task<T>> operation,
        CancellationToken cancellationToken = default)
    {
        // GOOD: Bulkhead - wait for available slot
        bool acquired = await _bulkhead.WaitAsync(TimeSpan.FromSeconds(10), cancellationToken);
        if (!acquired)
            throw new TimeoutException("WCF bulkhead is full. Too many concurrent requests.");

        IOrderService? channel = null;
        Interlocked.Increment(ref _activeConnections);

        try
        {
            channel = GetOrCreateChannel();
            var result = await operation(channel);
            CloseChannel(channel);
            return result;
        }
        catch (FaultException ex)
        {
            _logger.LogWarning("WCF FaultException: {Message}", ex.Message);
            AbortChannel(channel);
            throw;
        }
        catch (CommunicationException ex)
        {
            _logger.LogError(ex, "WCF CommunicationException - channel aborted");
            AbortChannel(channel);
            // Invalidate factory on communication errors
            InvalidateFactory();
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected WCF error");
            AbortChannel(channel);
            throw;
        }
        finally
        {
            Interlocked.Decrement(ref _activeConnections);
            _bulkhead.Release();
        }
    }

    private IOrderService GetOrCreateChannel()
    {
        var factory = EnsureFactory();
        var channel = factory.CreateChannel();
        Interlocked.Increment(ref _totalCreated);
        return channel;
    }

    private ChannelFactory<IOrderService> EnsureFactory()
    {
        if (_channelFactory != null &&
            _channelFactory.State != CommunicationState.Faulted &&
            _channelFactory.State != CommunicationState.Closed)
            return _channelFactory;

        lock (_factoryLock)
        {
            if (_channelFactory != null &&
                _channelFactory.State != CommunicationState.Faulted &&
                _channelFactory.State != CommunicationState.Closed)
                return _channelFactory;

            _logger.LogInformation("Creating new ChannelFactory<IOrderService>");
            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = 10_000_000,
                SendTimeout = TimeSpan.FromSeconds(30),
                ReceiveTimeout = TimeSpan.FromSeconds(30),
                OpenTimeout = TimeSpan.FromSeconds(10),
                CloseTimeout = TimeSpan.FromSeconds(10)
            };

            var endpoint = new EndpointAddress(_endpointAddress);
            _channelFactory = new ChannelFactory<IOrderService>(binding, endpoint);
            _channelFactory.Open();
            return _channelFactory;
        }
    }

    private void InvalidateFactory()
    {
        lock (_factoryLock)
        {
            try { _channelFactory?.Abort(); } catch { /* ignore */ }
            _channelFactory = null;
        }
    }

    private static void CloseChannel(IOrderService? channel)
    {
        if (channel is IClientChannel clientChannel)
        {
            try
            {
                if (clientChannel.State == CommunicationState.Opened)
                    clientChannel.Close();
            }
            catch
            {
                clientChannel.Abort();
            }
        }
    }

    private static void AbortChannel(IOrderService? channel)
    {
        if (channel is IClientChannel clientChannel)
        {
            try { clientChannel.Abort(); } catch { /* ignore */ }
        }
    }

    public long ActiveConnections => Interlocked.Read(ref _activeConnections);
    public long TotalChannelsCreated => Interlocked.Read(ref _totalCreated);

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        _disposed = true;

        try
        {
            _channelFactory?.Close();
        }
        catch
        {
            _channelFactory?.Abort();
        }

        _bulkhead.Dispose();
        await Task.CompletedTask;
    }
}
