using InternalApi.Infrastructure;
using InternalApi.Services;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using StackExchange.Redis;

var builder = WebApplication.CreateBuilder(args);

// ─── Logging ──────────────────────────────────────────────────────────────────
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// ─── Controllers + Swagger ────────────────────────────────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title = "Distributed WCF Benchmark API",
        Version = "v1",
        Description = "Compare BAD vs GOOD architecture patterns for WCF service calls"
    });
});

// ─── CORS (for Blazor client) ─────────────────────────────────────────────────
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// ─── Redis ────────────────────────────────────────────────────────────────────
var redisConnectionString = builder.Configuration.GetConnectionString("Redis")
    ?? "redis:6379";

builder.Services.AddSingleton<IConnectionMultiplexer>(sp =>
{
    var logger = sp.GetRequiredService<ILogger<Program>>();
    var maxRetries = 5;
    Exception? lastEx = null;

    for (int i = 0; i < maxRetries; i++)
    {
        try
        {
            var config = ConfigurationOptions.Parse(redisConnectionString);
            config.AbortOnConnectFail = false;
            config.ConnectTimeout = 5000;
            config.SyncTimeout = 5000;
            var multiplexer = ConnectionMultiplexer.Connect(config);
            logger.LogInformation("Redis connected: {Connection}", redisConnectionString);
            return multiplexer;
        }
        catch (Exception ex)
        {
            lastEx = ex;
            logger.LogWarning("Redis connection attempt {Attempt}/{Max} failed: {Error}",
                i + 1, maxRetries, ex.Message);
            if (i < maxRetries - 1)
                Thread.Sleep(TimeSpan.FromSeconds(2 * (i + 1)));
        }
    }

    throw new InvalidOperationException(
        $"Could not connect to Redis after {maxRetries} attempts", lastEx);
});

// ─── Infrastructure Services ─────────────────────────────────────────────────
builder.Services.AddSingleton<WcfClientManager>();
builder.Services.AddSingleton<ResiliencePolicies>();
builder.Services.AddSingleton<RedisIdempotencyStore>();
builder.Services.AddSingleton<RedisDistributedLockFactory>();
builder.Services.AddSingleton<BenchmarkMetrics>();

// ─── Business Services ────────────────────────────────────────────────────────
builder.Services.AddScoped<GoodOrderService>();
builder.Services.AddScoped<BadOrderService>();

// ─── OpenTelemetry ────────────────────────────────────────────────────────────
builder.Services.AddOpenTelemetry()
    .ConfigureResource(r => r.AddService(
        serviceName: "InternalApi",
        serviceVersion: "1.0.0"))
    .WithTracing(t => t
        .AddAspNetCoreInstrumentation(o =>
        {
            o.RecordException = true;
            o.Filter = ctx => !ctx.Request.Path.StartsWithSegments("/metrics")
                           && !ctx.Request.Path.StartsWithSegments("/health");
        })
        .AddHttpClientInstrumentation()
        .AddSource("InternalApi"))
    .WithMetrics(m => m
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddRuntimeInstrumentation()
        .AddMeter("InternalApi")
        .AddPrometheusExporter());

// ─── Health Checks ────────────────────────────────────────────────────────────
builder.Services.AddHealthChecks()
    .AddCheck("redis", () =>
    {
        // Basic connectivity check
        return Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy();
    });

var app = builder.Build();

// ─── Middleware Pipeline ──────────────────────────────────────────────────────
if (app.Environment.IsDevelopment() || app.Environment.IsEnvironment("Docker"))
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Distributed WCF Benchmark v1");
        c.RoutePrefix = "swagger";
    });
}

app.UseCors("AllowAll");
app.UseRouting();
app.UseAuthorization();
app.MapControllers();
app.MapPrometheusScrapingEndpoint("/metrics");
app.MapHealthChecks("/health");

app.MapGet("/", () => Results.Ok(new
{
    service = "InternalApi - Distributed WCF Benchmark",
    version = "1.0.0",
    swagger = "/swagger",
    health = "/health",
    metrics = "/metrics",
    endpoints = new[]
    {
        "POST /api/order/good   → GOOD mode (resilient)",
        "POST /api/order/bad    → BAD mode (anti-patterns)",
        "POST /api/loadtest/run → Run load test",
        "GET  /api/order/status → Circuit breaker status"
    }
}));

app.Run();
