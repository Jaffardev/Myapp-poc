using System.Diagnostics;
using System.ServiceModel;
using InternalApi.Infrastructure;
using Shared.Contracts;
using Shared.Models;

namespace InternalApi.Services;

/// <summary>
/// BAD MODE: Anti-patterns that cause performance issues under load.
/// - Creates a new WCF ChannelFactory + Channel per request (expensive!)
/// - No connection pooling
/// - No caching
/// - No retry logic
/// - No circuit breaker
/// - No throttling / bulkhead
/// - Causes CPU spike and connection exhaustion under load
/// </summary>
public sealed class BadOrderService
{
    private readonly BenchmarkMetrics _metrics;
    private readonly IConfiguration _configuration;
    private readonly ILogger<BadOrderService> _logger;

    public BadOrderService(
        BenchmarkMetrics metrics,
        IConfiguration configuration,
        ILogger<BadOrderService> logger)
    {
        _metrics = metrics;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<BenchmarkResponse> ProcessOrderAsync(
        BenchmarkRequest request,
        CancellationToken cancellationToken = default)
    {
        using var activity = BenchmarkMetrics.ActivitySource.StartActivity("BadMode.ProcessOrder");
        var sw = Stopwatch.StartNew();

        _metrics.IncrementActiveRequests();
        _metrics.BadModeRequestsTotal.Add(1, new KeyValuePair<string, object?>("mode", "bad"));

        // ── BAD PATTERN #1: No idempotency check ────────────────────────────
        // Every request goes through, even duplicates

        // ── BAD PATTERN #2: No distributed lock ─────────────────────────────
        // Concurrent requests with same key all execute simultaneously

        // ── BAD PATTERN #3: New ChannelFactory per request ──────────────────
        // ChannelFactory creation is expensive (parses WSDL, creates proxies, etc.)
        // Under load this causes CPU spikes and GC pressure
        ChannelFactory<IOrderService>? channelFactory = null;
        IOrderService? channel = null;

        try
        {
            var endpoint = _configuration["WcfService:Endpoint"]
                ?? "http://wcf-service:8080/OrderService";

            _logger.LogDebug("BAD MODE: Creating new ChannelFactory per request (anti-pattern!)");

            // This is the anti-pattern: creating a new ChannelFactory for every single request
            // In production, this causes:
            // 1. High CPU usage (WSDL parsing, proxy generation)
            // 2. Memory pressure (each factory holds resources)
            // 3. Connection pool exhaustion
            // 4. GC pressure from frequent allocations
            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = 10_000_000,
                SendTimeout = TimeSpan.FromSeconds(30),
                ReceiveTimeout = TimeSpan.FromSeconds(30)
            };

            channelFactory = new ChannelFactory<IOrderService>(
                binding,
                new EndpointAddress(endpoint));

            channelFactory.Open();
            channel = channelFactory.CreateChannel();

            var orderId = Guid.NewGuid().ToString("N")[..12].ToUpper();

            var wcfRequest = new OrderRequest
            {
                OrderId = orderId,
                CustomerId = request.CustomerId,
                Amount = request.Amount,
                ProductCode = request.ProductCode,
                IdempotencyKey = null // BAD: No idempotency key passed
            };

            // ── BAD PATTERN #4: No retry, no circuit breaker ─────────────────
            // A single transient failure = total request failure
            _metrics.WcfCallsTotal.Add(1, new KeyValuePair<string, object?>("mode", "bad"));

            var wcfResult = await ((IOrderService)channel).ProcessOrderAsync(wcfRequest);

            sw.Stop();

            var response = new BenchmarkResponse
            {
                OrderId = wcfResult.OrderId,
                Status = wcfResult.Status,
                Message = wcfResult.Message,
                LatencyMs = sw.ElapsedMilliseconds,
                WasCached = false,
                WasIdempotent = false,
                Mode = "bad",
                Timestamp = DateTime.UtcNow
            };

            _metrics.RequestDurationMs.Record(sw.ElapsedMilliseconds,
                new KeyValuePair<string, object?>("mode", "bad"),
                new KeyValuePair<string, object?>("cached", "false"));

            // ── BAD PATTERN #5: Not properly closing channels ────────────────
            // (We do close here to avoid hanging connections, but no error handling)
            try { ((IClientChannel)channel).Close(); } catch { /* swallowed */ }
            try { channelFactory.Close(); } catch { /* swallowed */ }

            return response;
        }
        catch (Exception ex)
        {
            sw.Stop();
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            _logger.LogError(ex, "BAD MODE request failed after {Ms}ms", sw.ElapsedMilliseconds);

            // ── BAD PATTERN #6: No fault handling on channels ────────────────
            try { ((IClientChannel?)channel)?.Abort(); } catch { /* ignore */ }
            try { channelFactory?.Abort(); } catch { /* ignore */ }

            throw;
        }
        finally
        {
            _metrics.DecrementActiveRequests();
        }
    }
}
