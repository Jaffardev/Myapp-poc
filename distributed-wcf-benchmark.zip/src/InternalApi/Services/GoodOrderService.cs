using System.Diagnostics;
using InternalApi.Infrastructure;
using Shared.Contracts;
using Shared.Models;

namespace InternalApi.Services;

/// <summary>
/// GOOD MODE: Proper enterprise architecture with all resilience patterns.
/// - WcfClientManager (centralized, pooled)
/// - Polly (retry + circuit breaker)
/// - Redis Idempotency Store
/// - Redis Distributed Lock
/// - Bulkhead (SemaphoreSlim inside WcfClientManager)
/// </summary>
public sealed class GoodOrderService
{
    private readonly WcfClientManager _wcfClientManager;
    private readonly ResiliencePolicies _resilience;
    private readonly RedisIdempotencyStore _idempotencyStore;
    private readonly RedisDistributedLockFactory _lockFactory;
    private readonly BenchmarkMetrics _metrics;
    private readonly ILogger<GoodOrderService> _logger;

    public GoodOrderService(
        WcfClientManager wcfClientManager,
        ResiliencePolicies resilience,
        RedisIdempotencyStore idempotencyStore,
        RedisDistributedLockFactory lockFactory,
        BenchmarkMetrics metrics,
        ILogger<GoodOrderService> logger)
    {
        _wcfClientManager = wcfClientManager;
        _resilience = resilience;
        _idempotencyStore = idempotencyStore;
        _lockFactory = lockFactory;
        _metrics = metrics;
        _logger = logger;
    }

    public async Task<BenchmarkResponse> ProcessOrderAsync(
        BenchmarkRequest request,
        string? idempotencyKey,
        CancellationToken cancellationToken = default)
    {
        using var activity = BenchmarkMetrics.ActivitySource.StartActivity("GoodMode.ProcessOrder");
        var sw = Stopwatch.StartNew();

        _metrics.IncrementActiveRequests();
        _metrics.GoodModeRequestsTotal.Add(1, new KeyValuePair<string, object?>("mode", "good"));

        try
        {
            var orderId = Guid.NewGuid().ToString("N")[..12].ToUpper();
            activity?.SetTag("order.id", orderId);
            activity?.SetTag("idempotency.key", idempotencyKey ?? "none");

            // ── STEP 1: Check idempotency store ─────────────────────────────
            if (!string.IsNullOrEmpty(idempotencyKey))
            {
                var cached = await _idempotencyStore.GetAsync<BenchmarkResponse>(idempotencyKey);
                if (cached != null)
                {
                    _logger.LogInformation("Idempotency hit: {Key}", idempotencyKey);
                    _metrics.IdempotencyHitsTotal.Add(1);
                    sw.Stop();
                    _metrics.RequestDurationMs.Record(sw.ElapsedMilliseconds,
                        new KeyValuePair<string, object?>("mode", "good"),
                        new KeyValuePair<string, object?>("cached", "true"));
                    return cached with { WasIdempotent = true, LatencyMs = sw.ElapsedMilliseconds };
                }
            }

            // ── STEP 2: Acquire distributed lock ────────────────────────────
            var lockResource = !string.IsNullOrEmpty(idempotencyKey)
                ? $"order:{idempotencyKey}"
                : $"order:{orderId}";

            await using var distributedLock = await _lockFactory.AcquireAsync(
                lockResource,
                lockTtl: TimeSpan.FromSeconds(30),
                waitTimeout: TimeSpan.FromSeconds(5),
                cancellationToken);

            if (!distributedLock.IsAcquired)
            {
                _metrics.LockFailuresTotal.Add(1);
                throw new InvalidOperationException(
                    $"Could not acquire distributed lock for {lockResource}. Request may already be processing.");
            }

            _metrics.LocksAcquiredTotal.Add(1);
            activity?.SetTag("lock.acquired", true);

            // ── STEP 3: Double-check idempotency after lock ──────────────────
            if (!string.IsNullOrEmpty(idempotencyKey))
            {
                var cachedAfterLock = await _idempotencyStore.GetAsync<BenchmarkResponse>(idempotencyKey);
                if (cachedAfterLock != null)
                {
                    _logger.LogInformation("Idempotency hit (post-lock): {Key}", idempotencyKey);
                    _metrics.IdempotencyHitsTotal.Add(1);
                    sw.Stop();
                    return cachedAfterLock with { WasIdempotent = true, LatencyMs = sw.ElapsedMilliseconds };
                }
            }

            // ── STEP 4: Execute WCF call with Polly resilience ───────────────
            var wcfRequest = new OrderRequest
            {
                OrderId = orderId,
                CustomerId = request.CustomerId,
                Amount = request.Amount,
                ProductCode = request.ProductCode,
                IdempotencyKey = idempotencyKey
            };

            var wcfSw = Stopwatch.StartNew();
            OrderResult wcfResult;

            try
            {
                wcfResult = await _resilience.CombinedPolicy.ExecuteAsync(async () =>
                {
                    _metrics.WcfCallsTotal.Add(1,
                        new KeyValuePair<string, object?>("mode", "good"));

                    return await _wcfClientManager.ExecuteAsync(
                        async client => await client.ProcessOrderAsync(wcfRequest),
                        cancellationToken);
                });
            }
            finally
            {
                wcfSw.Stop();
                _metrics.WcfCallDurationMs.Record(wcfSw.ElapsedMilliseconds,
                    new KeyValuePair<string, object?>("mode", "good"));
            }

            // ── STEP 5: Build response ───────────────────────────────────────
            sw.Stop();
            var response = new BenchmarkResponse
            {
                OrderId = wcfResult.OrderId,
                Status = wcfResult.Status,
                Message = wcfResult.Message,
                LatencyMs = sw.ElapsedMilliseconds,
                WasCached = wcfResult.WasCached,
                WasIdempotent = false,
                Mode = "good",
                Timestamp = DateTime.UtcNow
            };

            // ── STEP 6: Store in idempotency store ──────────────────────────
            if (!string.IsNullOrEmpty(idempotencyKey))
            {
                await _idempotencyStore.SetAsync(idempotencyKey, response);
            }

            _metrics.RequestDurationMs.Record(sw.ElapsedMilliseconds,
                new KeyValuePair<string, object?>("mode", "good"),
                new KeyValuePair<string, object?>("cached", "false"));

            activity?.SetTag("response.status", response.Status);
            activity?.SetTag("response.latency_ms", response.LatencyMs);

            return response;
        }
        catch (Exception ex)
        {
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            _logger.LogError(ex, "GoodMode ProcessOrder failed");
            throw;
        }
        finally
        {
            _metrics.DecrementActiveRequests();
        }
    }
}
