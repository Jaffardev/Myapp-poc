using System.Runtime.Serialization;
using System.ServiceModel;

namespace Shared.Contracts;

[ServiceContract(Namespace = "http://distributed-wcf-benchmark/IOrderService")]
public interface IOrderService
{
    [OperationContract]
    Task<OrderResult> ProcessOrderAsync(OrderRequest request);

    [OperationContract]
    Task<OrderResult> GetOrderStatusAsync(string orderId);

    [OperationContract]
    Task<HealthResult> PingAsync();
}

[DataContract]
public class OrderRequest
{
    [DataMember] public string OrderId { get; set; } = string.Empty;
    [DataMember] public string CustomerId { get; set; } = string.Empty;
    [DataMember] public decimal Amount { get; set; }
    [DataMember] public string ProductCode { get; set; } = string.Empty;
    [DataMember] public string? IdempotencyKey { get; set; }
}

[DataContract]
public class OrderResult
{
    [DataMember] public string OrderId { get; set; } = string.Empty;
    [DataMember] public string Status { get; set; } = string.Empty;
    [DataMember] public string Message { get; set; } = string.Empty;
    [DataMember] public DateTime ProcessedAt { get; set; }
    [DataMember] public bool WasCached { get; set; }
    [DataMember] public long ProcessingTimeMs { get; set; }
}

[DataContract]
public class HealthResult
{
    [DataMember] public bool IsHealthy { get; set; }
    [DataMember] public string ServiceName { get; set; } = string.Empty;
    [DataMember] public DateTime Timestamp { get; set; }
}
