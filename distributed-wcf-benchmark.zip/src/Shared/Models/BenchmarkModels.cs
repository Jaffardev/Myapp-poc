namespace Shared.Models;

public class BenchmarkRequest
{
    public string CustomerId { get; set; } = "CUST-001";
    public decimal Amount { get; set; } = 100.00m;
    public string ProductCode { get; set; } = "PROD-ABC";
    public string? IdempotencyKey { get; set; }
}

public record class BenchmarkResponse
{
    public string OrderId { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public long LatencyMs { get; set; }
    public bool WasCached { get; set; }
    public bool WasIdempotent { get; set; }
    public string Mode { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

public class LoadTestRequest
{
    public int ConcurrentRequests { get; set; } = 10;
    public int TotalRequests { get; set; } = 100;
    public string Mode { get; set; } = "good"; // "good" or "bad"
    public bool UseIdempotency { get; set; } = false;
}

public class LoadTestResult
{
    public int TotalRequests { get; set; }
    public int SuccessCount { get; set; }
    public int FailureCount { get; set; }
    public double AvgLatencyMs { get; set; }
    public double P95LatencyMs { get; set; }
    public double P99LatencyMs { get; set; }
    public double MinLatencyMs { get; set; }
    public double MaxLatencyMs { get; set; }
    public double RequestsPerSecond { get; set; }
    public long TotalDurationMs { get; set; }
    public string Mode { get; set; } = string.Empty;
    public List<long> Latencies { get; set; } = new();
}
