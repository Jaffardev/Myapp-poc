using CoreWCF;
using CoreWCF.Configuration;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using WcfService.Services;

var builder = WebApplication.CreateBuilder(args);

// ─── Logging ─────────────────────────────────────────────────────────────────
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// ─── CoreWCF ─────────────────────────────────────────────────────────────────
builder.Services.AddServiceModelServices();
builder.Services.AddSingleton<OrderService>();

// ─── OpenTelemetry ────────────────────────────────────────────────────────────
builder.Services.AddOpenTelemetry()
    .ConfigureResource(r => r.AddService("WcfService"))
    .WithTracing(t => t
        .AddAspNetCoreInstrumentation()
        .AddSource("WcfService"))
    .WithMetrics(m => m
        .AddAspNetCoreInstrumentation()
        .AddRuntimeInstrumentation()
        .AddPrometheusExporter());

var app = builder.Build();

// ─── CoreWCF Middleware ───────────────────────────────────────────────────────
app.UseServiceModel(serviceBuilder =>
{
    serviceBuilder.AddService<OrderService>(options =>
    {
        options.DebugBehavior.IncludeExceptionDetailInFaults = true;
    });

    serviceBuilder.AddServiceEndpoint<OrderService, Shared.Contracts.IOrderService>(
        new BasicHttpBinding
        {
            MaxReceivedMessageSize = 10_000_000,
            SendTimeout = TimeSpan.FromSeconds(30),
            ReceiveTimeout = TimeSpan.FromSeconds(30)
        },
        "/OrderService");
});

// ─── Prometheus metrics endpoint ─────────────────────────────────────────────
app.MapPrometheusScrapingEndpoint("/metrics");

// ─── Health check ─────────────────────────────────────────────────────────────
app.MapGet("/health", () => Results.Ok(new
{
    status = "healthy",
    service = "WcfService",
    timestamp = DateTime.UtcNow
}));

app.MapGet("/", () => Results.Ok(new
{
    service = "WCF Order Service (CoreWCF)",
    version = "1.0.0",
    endpoints = new[]
    {
        "POST /OrderService  → WCF SOAP endpoint",
        "GET  /health        → Health check",
        "GET  /metrics       → Prometheus metrics"
    }
}));

app.Run();
