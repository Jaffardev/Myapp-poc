using System.Collections.Concurrent;
using System.Diagnostics;
using CoreWCF;
using Shared.Contracts;

namespace WcfService.Services;

[ServiceBehavior(
    ConcurrencyMode = ConcurrencyMode.Multiple,
    InstanceContextMode = InstanceContextMode.Single)]
public class OrderService : IOrderService
{
    private readonly ILogger<OrderService> _logger;
    private readonly ConcurrentDictionary<string, OrderResult> _idempotencyStore = new();
    private readonly ConcurrentDictionary<string, OrderResult> _orderStore = new();
    private static long _totalProcessed = 0;
    private static long _totalCacheHits = 0;

    public OrderService(ILogger<OrderService> logger)
    {
        _logger = logger;
    }

    public async Task<OrderResult> ProcessOrderAsync(OrderRequest request)
    {
        var sw = Stopwatch.StartNew();
        _logger.LogInformation("ProcessOrder called: OrderId={OrderId}, IdempotencyKey={Key}",
            request.OrderId, request.IdempotencyKey);

        // Check idempotency key first (enterprise pattern for WCF services)
        if (!string.IsNullOrEmpty(request.IdempotencyKey))
        {
            if (_idempotencyStore.TryGetValue(request.IdempotencyKey, out var cached))
            {
                Interlocked.Increment(ref _totalCacheHits);
                _logger.LogInformation("Cache hit for IdempotencyKey={Key}", request.IdempotencyKey);
                cached.WasCached = true;
                return cached;
            }
        }

        // Simulate real enterprise WCF service processing delay
        await Task.Delay(1000); // 1 second processing time

        // Simulate occasional transient failures (5% chance)
        if (Random.Shared.NextDouble() < 0.05)
        {
            throw new FaultException("Transient processing error - service overloaded");
        }

        var result = new OrderResult
        {
            OrderId = request.OrderId,
            Status = "Processed",
            Message = $"Order {request.OrderId} processed successfully for customer {request.CustomerId}",
            ProcessedAt = DateTime.UtcNow,
            WasCached = false,
            ProcessingTimeMs = sw.ElapsedMilliseconds
        };

        // Store in order store
        _orderStore[request.OrderId] = result;

        // Store in idempotency store
        if (!string.IsNullOrEmpty(request.IdempotencyKey))
        {
            _idempotencyStore[request.IdempotencyKey] = result;
        }

        Interlocked.Increment(ref _totalProcessed);
        sw.Stop();
        result.ProcessingTimeMs = sw.ElapsedMilliseconds;

        _logger.LogInformation("Order processed in {Ms}ms. Total={Total}, CacheHits={Hits}",
            sw.ElapsedMilliseconds, _totalProcessed, _totalCacheHits);

        return result;
    }

    public async Task<OrderResult> GetOrderStatusAsync(string orderId)
    {
        await Task.Delay(100); // Fast read operation

        if (_orderStore.TryGetValue(orderId, out var result))
            return result;

        return new OrderResult
        {
            OrderId = orderId,
            Status = "NotFound",
            Message = $"Order {orderId} not found",
            ProcessedAt = DateTime.UtcNow
        };
    }

    public Task<HealthResult> PingAsync()
    {
        return Task.FromResult(new HealthResult
        {
            IsHealthy = true,
            ServiceName = "WcfOrderService",
            Timestamp = DateTime.UtcNow
        });
    }
}
