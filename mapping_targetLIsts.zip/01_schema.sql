-- ============================================================
-- CRM Ingestion System -- SQL Server Schema
-- Replaces Oracle schema with T-SQL equivalents
-- ============================================================

USE CrmIngestion;
GO

-- ── Data Source ───────────────────────────────────────────────
CREATE TABLE CRM_DATA_SOURCE (
    SOURCE_ID       INT            IDENTITY(1,1) PRIMARY KEY,
    SOURCE_CODE     NVARCHAR(50)   NOT NULL UNIQUE,
    SOURCE_TYPE     NVARCHAR(20)   NOT NULL CHECK (SOURCE_TYPE IN ('EXCEL','QUERY')),
    DESCRIPTION     NVARCHAR(255)  NULL,
    IS_ACTIVE       CHAR(1)        NOT NULL DEFAULT 'Y',
    CREATED_DT      DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

-- ── Field Definition ─────────────────────────────────────────
CREATE TABLE CRM_FIELD_DEFINITION (
    FIELD_DEF_ID    INT            IDENTITY(1,1) PRIMARY KEY,
    FIELD_CODE      NVARCHAR(50)   NOT NULL UNIQUE,
    DISPLAY_NAME    NVARCHAR(100)  NOT NULL,
    DATA_TYPE       NVARCHAR(20)   NOT NULL,
    IS_MANDATORY    CHAR(1)        NOT NULL DEFAULT 'N',
    IS_ACTIVE       CHAR(1)        NOT NULL DEFAULT 'Y'
);
GO

-- ── Field Mapping ─────────────────────────────────────────────
CREATE TABLE CRM_FIELD_MAPPING (
    MAPPING_ID          INT            IDENTITY(1,1) PRIMARY KEY,
    SOURCE_ID           INT            NOT NULL REFERENCES CRM_DATA_SOURCE(SOURCE_ID),
    FIELD_CODE          NVARCHAR(50)   NOT NULL,
    SOURCE_COLUMN_NAME  NVARCHAR(100)  NOT NULL,
    ORDINAL_POSITION    INT            NOT NULL,
    TRANSFORM_EXPR      NVARCHAR(500)  NOT NULL DEFAULT '{VALUE}',
    IS_ACTIVE           CHAR(1)        NOT NULL DEFAULT 'Y',
    CONSTRAINT UQ_MAPPING UNIQUE (SOURCE_ID, FIELD_CODE)
);
GO

-- ── Query Config ─────────────────────────────────────────────
CREATE TABLE CRM_QUERY_CONFIG (
    QUERY_CONFIG_ID INT            IDENTITY(1,1) PRIMARY KEY,
    SOURCE_ID       INT            NOT NULL REFERENCES CRM_DATA_SOURCE(SOURCE_ID),
    QUERY_NAME      NVARCHAR(200)  NOT NULL,
    QUERY_TEXT      NVARCHAR(MAX)  NOT NULL,          -- replaces Oracle CLOB
    STATUS          NVARCHAR(20)   NOT NULL DEFAULT 'DRAFT'
                    CHECK (STATUS IN ('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','RETIRED')),
    CHECKSUM        NVARCHAR(64)   NULL,              -- SHA-256 hex, 64 chars
    SUBMITTED_BY    NVARCHAR(100)  NULL,
    SUBMITTED_DT    DATETIME2      NULL,
    REVIEWED_BY     NVARCHAR(100)  NULL,
    REVIEWED_DT     DATETIME2      NULL,
    REVIEW_COMMENTS NVARCHAR(1000) NULL,
    CREATED_BY      NVARCHAR(100)  NOT NULL,
    CREATED_DT      DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

-- ── Query Approval Log ────────────────────────────────────────
CREATE TABLE CRM_QUERY_APPROVAL_LOG (
    LOG_ID          INT            IDENTITY(1,1) PRIMARY KEY,
    QUERY_CONFIG_ID INT            NOT NULL REFERENCES CRM_QUERY_CONFIG(QUERY_CONFIG_ID),
    ACTION          NVARCHAR(20)   NOT NULL,
    ACTION_BY       NVARCHAR(100)  NOT NULL,
    ACTION_DT       DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    COMMENTS        NVARCHAR(1000) NULL,
    BATCH_ID        INT            NULL
);
GO

-- ── Load Batch ────────────────────────────────────────────────
CREATE TABLE CRM_LOAD_BATCH (
    BATCH_ID            INT            IDENTITY(1,1) PRIMARY KEY,
    SOURCE_ID           INT            NOT NULL REFERENCES CRM_DATA_SOURCE(SOURCE_ID),
    QUERY_CONFIG_ID     INT            NULL REFERENCES CRM_QUERY_CONFIG(QUERY_CONFIG_ID),
    BATCH_STATUS        NVARCHAR(20)   NOT NULL DEFAULT 'INITIATED'
                        CHECK (BATCH_STATUS IN (
                            'INITIATED','LANDING','LANDED','MAPPING','MAPPED',
                            'VALIDATING','VALIDATED','DEDUPLICATING','COMPLETED','FAILED')),
    JOB_NAME            NVARCHAR(200)  NULL,              -- SQL Agent job name
    RAW_ROW_COUNT       INT            NOT NULL DEFAULT 0,
    MAPPED_ROW_COUNT    INT            NOT NULL DEFAULT 0,
    VALID_ROW_COUNT     INT            NOT NULL DEFAULT 0,
    INVALID_ROW_COUNT   INT            NOT NULL DEFAULT 0,
    DUPLICATE_ROW_COUNT INT            NOT NULL DEFAULT 0,
    NET_NEW_ROW_COUNT   INT            NOT NULL DEFAULT 0,
    INITIATED_BY        NVARCHAR(100)  NOT NULL,
    INITIATED_DT        DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    LANDED_DT           DATETIME2      NULL,
    MAPPED_DT           DATETIME2      NULL,
    VALIDATED_DT        DATETIME2      NULL,
    COMPLETED_DT        DATETIME2      NULL,
    LAST_ERROR          NVARCHAR(MAX)  NULL,
    RESTART_COUNT       INT            NOT NULL DEFAULT 0
);
GO

-- ── Raw Landing ──────────────────────────────────────────────
-- No constraints intentionally -- validated in SP_VALIDATE_CUSTOMERS
CREATE TABLE CRM_RAW_LANDING (
    RAW_ROW_ID  INT            IDENTITY(1,1) PRIMARY KEY,
    BATCH_ID    INT            NOT NULL,
    SOURCE_ID   INT            NOT NULL,
    COL_01      NVARCHAR(500)  NULL,
    COL_02      NVARCHAR(500)  NULL,
    COL_03      NVARCHAR(500)  NULL,
    COL_04      NVARCHAR(500)  NULL,
    COL_05      NVARCHAR(500)  NULL,
    COL_06      NVARCHAR(500)  NULL,
    COL_07      NVARCHAR(500)  NULL,
    COL_08      NVARCHAR(500)  NULL,
    LOAD_DT     DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME()
);
-- Filtered index for fast per-batch access
CREATE INDEX IX_RAW_LANDING_BATCH ON CRM_RAW_LANDING (BATCH_ID) INCLUDE (SOURCE_ID);
GO

-- ── Customer (Canonical) ─────────────────────────────────────
CREATE TABLE CRM_CUSTOMER (
    CUSTOMER_ID        INT            IDENTITY(1,1) PRIMARY KEY,
    BATCH_ID           INT            NOT NULL,
    SOURCE_ID          INT            NOT NULL,
    RAW_ROW_ID         INT            NOT NULL,
    MOBILE             NVARCHAR(20)   NULL,
    EMAIL              NVARCHAR(200)  NULL,
    CUSTOMER_NAME      NVARCHAR(200)  NULL,
    NATIONAL_ID        NVARCHAR(50)   NULL,
    DOB                DATE           NULL,
    RECORD_STATUS      NVARCHAR(20)   NOT NULL DEFAULT 'PENDING'
                       CHECK (RECORD_STATUS IN ('PENDING','VALID','INVALID','DUPLICATE')),
    VALIDATION_ERRORS  NVARCHAR(MAX)  NULL,   -- JSON array e.g. ["MOBILE","EMAIL"]
    DEDUP_MASTER_ID    INT            NULL,    -- FK to self for duplicates
    LOAD_DT            DATETIME2      NULL,
    UPDATED_DT         DATETIME2      NULL
);
CREATE INDEX IX_CUSTOMER_BATCH  ON CRM_CUSTOMER (BATCH_ID, RECORD_STATUS);
CREATE INDEX IX_CUSTOMER_MOBILE ON CRM_CUSTOMER (MOBILE) WHERE MOBILE IS NOT NULL;
CREATE INDEX IX_CUSTOMER_EMAIL  ON CRM_CUSTOMER (EMAIL)  WHERE EMAIL  IS NOT NULL;
GO

-- ── Error Log ─────────────────────────────────────────────────
CREATE TABLE CRM_ERROR_LOG (
    ERROR_ID      INT            IDENTITY(1,1) PRIMARY KEY,
    BATCH_ID      INT            NOT NULL,
    RAW_ROW_ID    INT            NOT NULL,
    ERROR_TYPE    NVARCHAR(50)   NOT NULL,
    FIELD_CODE    NVARCHAR(50)   NULL,
    ERROR_MESSAGE NVARCHAR(500)  NULL,
    RAW_VALUE     NVARCHAR(500)  NULL,
    LOGGED_DT     DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX IX_ERROR_LOG_BATCH ON CRM_ERROR_LOG (BATCH_ID);
GO

-- ── Batch Step Log ────────────────────────────────────────────
CREATE TABLE CRM_BATCH_STEP_LOG (
    STEP_LOG_ID   INT            IDENTITY(1,1) PRIMARY KEY,
    BATCH_ID      INT            NOT NULL,
    STEP_NAME     NVARCHAR(100)  NOT NULL,
    STEP_STATUS   NVARCHAR(20)   NOT NULL,
    STARTED_DT    DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    COMPLETED_DT  DATETIME2      NULL,
    ROWS_AFFECTED INT            NULL,
    ERROR_MESSAGE NVARCHAR(MAX)  NULL
);
GO
