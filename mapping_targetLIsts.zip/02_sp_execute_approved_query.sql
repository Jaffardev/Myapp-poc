-- ============================================================
-- SP_EXECUTE_APPROVED_QUERY  (SQL Server version)
-- Replaces Oracle STANDARD_HASH with HASHBYTES('SHA2_256',...)
-- Replaces EXECUTE IMMEDIATE with sp_executesql
-- Replaces FOR UPDATE NOWAIT with sp_getapplock
-- ============================================================
CREATE OR ALTER PROCEDURE SP_EXECUTE_APPROVED_QUERY
    @BatchId        INT,
    @QueryConfigId  INT,
    @InitiatedBy    NVARCHAR(100),
    @RowsInserted   INT           OUTPUT,
    @ErrorMessage   NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @QueryText      NVARCHAR(MAX);
    DECLARE @Status         NVARCHAR(20);
    DECLARE @StoredChecksum NVARCHAR(64);
    DECLARE @ComputedChecksum NVARCHAR(64);
    DECLARE @SourceId       INT;
    DECLARE @InsertSql      NVARCHAR(MAX);
    DECLARE @Params         NVARCHAR(200);
    DECLARE @LockResult     INT;

    -- ── Step A: Exclusive Application Lock (replaces FOR UPDATE NOWAIT) ──────
    -- sp_getapplock acquires a named lock scoped to the transaction.
    -- Resource name combines SP name + query ID to be unique per query.
    -- NOWAIT means fail immediately if the lock is held by another session.
    BEGIN TRANSACTION;

    EXEC @LockResult = sp_getapplock
        @Resource        = N'SP_EXEC_QUERY_' + CAST(@QueryConfigId AS NVARCHAR),
        @LockMode        = N'Exclusive',
        @LockOwner       = N'Transaction',
        @LockTimeout     = 0;      -- 0 = NOWAIT, fail instantly

    IF @LockResult < 0
    BEGIN
        ROLLBACK;
        SET @ErrorMessage = N'Query ' + CAST(@QueryConfigId AS NVARCHAR)
            + N' is already executing in another session. LockResult: '
            + CAST(@LockResult AS NVARCHAR);
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END

    -- ── Step B: Fetch query details ──────────────────────────────────────────
    SELECT
        @QueryText      = qc.QUERY_TEXT,
        @Status         = qc.STATUS,
        @StoredChecksum = qc.CHECKSUM,
        @SourceId       = ds.SOURCE_ID
    FROM CRM_QUERY_CONFIG qc
    JOIN CRM_DATA_SOURCE  ds ON ds.SOURCE_ID = qc.SOURCE_ID
    WHERE qc.QUERY_CONFIG_ID = @QueryConfigId;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK;
        SET @ErrorMessage = N'Query config ' + CAST(@QueryConfigId AS NVARCHAR) + N' not found.';
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END

    -- ── Step C: Approval Status Gate ─────────────────────────────────────────
    IF @Status <> N'APPROVED'
    BEGIN
        ROLLBACK;
        SET @ErrorMessage = N'Query ' + CAST(@QueryConfigId AS NVARCHAR)
            + N' is not APPROVED (status: ' + @Status + N')';
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END

    -- ── Step D: SHA-256 Checksum Re-Validation ───────────────────────────────
    -- HASHBYTES returns VARBINARY(32); CONVERT to hex string for comparison.
    -- Must match ChecksumService.ComputeSha256() in C# which also produces
    -- lowercase hex. LOWER() ensures case-insensitive comparison.
    SET @ComputedChecksum = LOWER(
        CONVERT(NVARCHAR(64),
            HASHBYTES('SHA2_256', CAST(@QueryText AS NVARCHAR(MAX))),
            2)          -- style 2 = hex string without 0x prefix
    );

    IF @ComputedChecksum <> LOWER(@StoredChecksum)
    BEGIN
        ROLLBACK;
        SET @ErrorMessage = N'CHECKSUM MISMATCH for query ' + CAST(@QueryConfigId AS NVARCHAR)
            + N'. Stored: ' + @StoredChecksum
            + N'. Computed: ' + @ComputedChecksum
            + N'. Post-approval tampering detected. Execution aborted.';
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END

    -- ── Step E: Build Dynamic INSERT..SELECT ─────────────────────────────────
    -- User query wrapped as subquery  FROM (...) q
    -- @BatchId and @SourceId passed as parameters, never concatenated.
    SET @InsertSql = N'
        INSERT INTO CRM_RAW_LANDING
            (BATCH_ID, SOURCE_ID, COL_01, COL_02, COL_03, COL_04, COL_05, LOAD_DT)
        SELECT @pBatchId, @pSourceId,
               q.Mobile, q.Email, q.CustomerName, q.NationalID, q.DOB,
               SYSUTCDATETIME()
        FROM (' + @QueryText + N') AS q
        OPTION (MAXDOP 8);';   -- replaces Oracle PARALLEL hint

    SET @Params = N'@pBatchId INT, @pSourceId INT';

    -- ── Step F: Execute with Parameterised sp_executesql ─────────────────────
    -- sp_executesql binds @pBatchId and @pSourceId as typed parameters.
    -- The user query is the subquery alias q -- it CANNOT receive these binds.
    -- This is equivalent to Oracle EXECUTE IMMEDIATE ... USING.
    EXEC sp_executesql
        @InsertSql,
        @Params,
        @pBatchId  = @BatchId,
        @pSourceId = @SourceId;

    SET @RowsInserted = @@ROWCOUNT;

    -- ── Step G: Update batch status and write audit log ──────────────────────
    UPDATE CRM_LOAD_BATCH
    SET BATCH_STATUS    = N'LANDED',
        RAW_ROW_COUNT   = @RowsInserted,
        LANDED_DT       = SYSUTCDATETIME(),
        QUERY_CONFIG_ID = @QueryConfigId
    WHERE BATCH_ID = @BatchId;

    INSERT INTO CRM_QUERY_APPROVAL_LOG (QUERY_CONFIG_ID, ACTION, ACTION_BY, BATCH_ID)
    VALUES (@QueryConfigId, N'EXECUTED', @InitiatedBy, @BatchId);

    COMMIT;
    SET @ErrorMessage = NULL;
END
GO
