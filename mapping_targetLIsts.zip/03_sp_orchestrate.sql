-- ============================================================
-- SP_SUBMIT_INGESTION_JOB  (SQL Server version)
-- Replaces Oracle DBMS_SCHEDULER with SQL Server Agent
-- ============================================================
CREATE OR ALTER PROCEDURE SP_SUBMIT_INGESTION_JOB
    @BatchId    INT,
    @JobName    NVARCHAR(200) OUTPUT,
    @ErrorMsg   NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Name      NVARCHAR(200);
    DECLARE @StepCmd   NVARCHAR(500);
    DECLARE @BatchIdStr NVARCHAR(20) = CAST(@BatchId AS NVARCHAR);

    -- Unique job name: CRM_INGEST_B10042_20240120091832
    SET @Name = N'CRM_INGEST_B' + @BatchIdStr + N'_'
              + CONVERT(NVARCHAR(14), SYSUTCDATETIME(), 112)    -- YYYYMMDD
              + REPLACE(CONVERT(NVARCHAR(8),  SYSUTCDATETIME(), 108), ':', '');  -- HHMMSS

    -- T-SQL command the job step will execute
    SET @StepCmd = N'EXEC SP_ORCHESTRATE_INGESTION ' + @BatchIdStr + N';';

    -- Create SQL Agent job
    EXEC msdb.dbo.sp_add_job
        @job_name              = @Name,
        @enabled               = 1,
        @delete_level          = 1,      -- auto-delete on success (replaces auto_drop)
        @description           = N'CRM ingestion pipeline';

    -- Single job step: calls the orchestrator SP
    EXEC msdb.dbo.sp_add_jobstep
        @job_name      = @Name,
        @step_name     = N'RunPipeline',
        @command       = @StepCmd,
        @database_name = N'CrmIngestion',
        @on_success_action = 1,   -- quit with success
        @on_fail_action    = 2;   -- quit with failure

    -- Schedule: start immediately (one-time)
    EXEC msdb.dbo.sp_add_schedule
        @schedule_name    = @Name + N'_SCHED',
        @freq_type        = 1,     -- 1 = once
        @active_start_date = CONVERT(INT, CONVERT(NVARCHAR(8), SYSUTCDATETIME(), 112)),
        @active_start_time = 0;

    EXEC msdb.dbo.sp_attach_schedule @job_name = @Name, @schedule_name = @Name + N'_SCHED';

    -- Assign to local server and start immediately
    EXEC msdb.dbo.sp_add_jobserver @job_name = @Name;
    EXEC msdb.dbo.sp_start_job @job_name = @Name;

    UPDATE CRM_LOAD_BATCH SET JOB_NAME = @Name WHERE BATCH_ID = @BatchId;
    COMMIT;

    SET @JobName  = @Name;
    SET @ErrorMsg = NULL;
END
GO

-- ============================================================
-- SP_ORCHESTRATE_INGESTION  (SQL Server version)
-- State-machine runner -- same idempotent gate logic as Oracle
-- ============================================================
CREATE OR ALTER PROCEDURE SP_ORCHESTRATE_INGESTION
    @BatchId INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Status  NVARCHAR(20);
    DECLARE @ErrMsg  NVARCHAR(MAX);

    SELECT @Status = BATCH_STATUS FROM CRM_LOAD_BATCH WHERE BATCH_ID = @BatchId;

    BEGIN TRY
        -- GATE 1: Only MAP if status is LANDED
        IF @Status = N'LANDED'
        BEGIN
            EXEC SP_MAP_TO_CANONICAL @BatchId, @ErrMsg OUTPUT;
            IF @ErrMsg IS NOT NULL
                THROW 50100, @ErrMsg, 1;

            SELECT @Status = BATCH_STATUS FROM CRM_LOAD_BATCH WHERE BATCH_ID = @BatchId;
        END

        -- GATE 2: Only VALIDATE if status is MAPPED
        IF @Status = N'MAPPED'
        BEGIN
            EXEC SP_VALIDATE_CUSTOMERS @BatchId, @ErrMsg OUTPUT;
            IF @ErrMsg IS NOT NULL
                THROW 50101, @ErrMsg, 1;

            SELECT @Status = BATCH_STATUS FROM CRM_LOAD_BATCH WHERE BATCH_ID = @BatchId;
        END

        -- GATE 3: Only DEDUP if status is VALIDATED
        IF @Status = N'VALIDATED'
        BEGIN
            EXEC SP_DEDUP_CUSTOMERS @BatchId, @ErrMsg OUTPUT;
            IF @ErrMsg IS NOT NULL
                THROW 50102, @ErrMsg, 1;
        END

        UPDATE CRM_LOAD_BATCH
        SET BATCH_STATUS  = N'COMPLETED',
            COMPLETED_DT  = SYSUTCDATETIME()
        WHERE BATCH_ID    = @BatchId
          AND BATCH_STATUS NOT IN (N'FAILED', N'COMPLETED');

    END TRY
    BEGIN CATCH
        UPDATE CRM_LOAD_BATCH
        SET BATCH_STATUS  = N'FAILED',
            RESTART_COUNT = RESTART_COUNT + 1,
            LAST_ERROR    = ERROR_MESSAGE()
        WHERE BATCH_ID = @BatchId;

        THROW;   -- re-raise so SQL Agent marks the job as failed
    END CATCH
END
GO
