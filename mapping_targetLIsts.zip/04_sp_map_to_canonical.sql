-- ============================================================
-- SP_MAP_TO_CANONICAL  (SQL Server version)
-- Replaces Oracle cursor + EXECUTE IMMEDIATE with
-- sp_executesql parameterised dynamic INSERT..SELECT
-- ============================================================
CREATE OR ALTER PROCEDURE SP_MAP_TO_CANONICAL
    @BatchId  INT,
    @ErrMsg   NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SourceId  INT;
    DECLARE @ColList   NVARCHAR(MAX) = N'';
    DECLARE @InsertSql NVARCHAR(MAX);
    DECLARE @Params    NVARCHAR(100) = N'@pBatchId INT';

    -- Get source for this batch
    SELECT @SourceId = SOURCE_ID FROM CRM_LOAD_BATCH WHERE BATCH_ID = @BatchId;

    -- ── Build the SELECT projection from the mapping config ──────────────────
    -- Cursor over CRM_FIELD_MAPPING ordered by ORDINAL_POSITION.
    -- Replace {VALUE} macro with the actual COL_nn slot reference.
    -- e.g. TRANSFORM_EXPR = "LTRIM(RTRIM({VALUE}))"
    --      COL_SLOT        = "r.COL_01"
    --      Result          = "LTRIM(RTRIM(r.COL_01))"

    DECLARE @FieldCode  NVARCHAR(50);
    DECLARE @ColSlot    NVARCHAR(20);
    DECLARE @Transform  NVARCHAR(500);

    DECLARE map_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT
            FIELD_CODE,
            N'r.COL_' + RIGHT(N'00' + CAST(ORDINAL_POSITION AS NVARCHAR), 2) AS COL_SLOT,
            TRANSFORM_EXPR
        FROM CRM_FIELD_MAPPING
        WHERE SOURCE_ID  = @SourceId
          AND IS_ACTIVE   = N'Y'
        ORDER BY ORDINAL_POSITION;

    OPEN map_cursor;
    FETCH NEXT FROM map_cursor INTO @FieldCode, @ColSlot, @Transform;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Replace {VALUE} placeholder with the actual column reference
        SET @ColList = @ColList
            + REPLACE(@Transform, N'{VALUE}', @ColSlot)
            + N', ';

        FETCH NEXT FROM map_cursor INTO @FieldCode, @ColSlot, @Transform;
    END

    CLOSE map_cursor;
    DEALLOCATE map_cursor;

    -- Strip trailing ", "
    SET @ColList = LEFT(@ColList, LEN(@ColList) - 2);

    -- ── Assemble the final INSERT..SELECT ────────────────────────────────────
    -- TABLOCK hint + ORDER BY NULL improves bulk insert performance.
    -- Equivalent to Oracle APPEND NOLOGGING PARALLEL.
    SET @InsertSql = N'
        INSERT INTO CRM_CUSTOMER WITH (TABLOCK)
            (BATCH_ID, SOURCE_ID, RAW_ROW_ID,
             MOBILE, EMAIL, CUSTOMER_NAME, NATIONAL_ID, DOB,
             RECORD_STATUS, LOAD_DT)
        SELECT
            @pBatchId,
            r.SOURCE_ID,
            r.RAW_ROW_ID,
            ' + @ColList + N',
            N''PENDING'',
            r.LOAD_DT
        FROM CRM_RAW_LANDING r WITH (NOLOCK)
        WHERE r.BATCH_ID = @pBatchId
        OPTION (MAXDOP 8);';

    BEGIN TRY
        EXEC sp_executesql @InsertSql, @Params, @pBatchId = @BatchId;

        UPDATE CRM_LOAD_BATCH
        SET BATCH_STATUS     = N'MAPPED',
            MAPPED_DT        = SYSUTCDATETIME(),
            MAPPED_ROW_COUNT = @@ROWCOUNT
        WHERE BATCH_ID = @BatchId;

        SET @ErrMsg = NULL;
    END TRY
    BEGIN CATCH
        SET @ErrMsg = ERROR_MESSAGE();
        ROLLBACK;
    END CATCH
END
GO
