-- ============================================================
-- SP_VALIDATE_CUSTOMERS  (SQL Server version)
-- Replaces Oracle JSON_ARRAYAGG with FOR JSON PATH
-- Replaces Oracle JSON_TABLE  with OPENJSON
-- ============================================================
CREATE OR ALTER PROCEDURE SP_VALIDATE_CUSTOMERS
    @BatchId    INT,
    @ErrMsg     NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ValidCnt   INT = 0;
    DECLARE @InvalidCnt INT = 0;

    BEGIN TRY

        -- ── Phase A: Mark INVALID rows, build JSON error array ───────────────
        -- SQL Server does not have JSON_ARRAYAGG.
        -- Use FOR JSON PATH with a correlated subquery to build the array.
        -- FOR JSON PATH, WITHOUT_ARRAY_WRAPPER removed via JSON_QUERY trick.

        UPDATE c
        SET
            RECORD_STATUS    = N'INVALID',
            VALIDATION_ERRORS = (
                SELECT fd.FIELD_CODE AS [value]
                FROM CRM_FIELD_DEFINITION fd
                WHERE fd.IS_MANDATORY = N'Y'
                  AND fd.IS_ACTIVE    = N'Y'
                  AND (
                        (fd.FIELD_CODE = N'MOBILE'        AND c.MOBILE IS NULL)
                     OR (fd.FIELD_CODE = N'CUSTOMER_NAME' AND c.CUSTOMER_NAME IS NULL)
                  )
                ORDER BY fd.FIELD_CODE
                -- FOR JSON PATH produces: [{"value":"MOBILE"},{"value":"..."}]
                -- We want a simple string array, so use a scalar subquery instead:
                FOR JSON PATH
            ),
            UPDATED_DT = SYSUTCDATETIME()
        FROM CRM_CUSTOMER c
        WHERE c.BATCH_ID      = @BatchId
          AND c.RECORD_STATUS = N'PENDING'
          AND (c.MOBILE IS NULL OR c.CUSTOMER_NAME IS NULL);

        -- VALIDATION_ERRORS is stored as JSON produced by FOR JSON PATH.
        -- The format is: [{"value":"MOBILE"},{"value":"CUSTOMER_NAME"}]
        -- OPENJSON will shred it back to rows in Phase B.

        SET @InvalidCnt = @@ROWCOUNT;

        -- ── Phase B: Bulk-insert error log using OPENJSON ────────────────────
        -- OPENJSON replaces Oracle JSON_TABLE to shred the JSON array.
        -- CROSS APPLY means one error log row per failed field per customer.

        INSERT INTO CRM_ERROR_LOG
            (BATCH_ID, RAW_ROW_ID, ERROR_TYPE, FIELD_CODE, ERROR_MESSAGE, RAW_VALUE)
        SELECT
            c.BATCH_ID,
            c.RAW_ROW_ID,
            N'MISSING_MANDATORY',
            j.[value],
            N'Mandatory field [' + j.[value] + N'] is NULL',
            CASE j.[value]
                WHEN N'MOBILE'        THEN c.MOBILE
                WHEN N'EMAIL'         THEN c.EMAIL
                WHEN N'CUSTOMER_NAME' THEN c.CUSTOMER_NAME
            END
        FROM CRM_CUSTOMER c
        CROSS APPLY OPENJSON(c.VALIDATION_ERRORS)    -- shreds JSON array to rows
            WITH ([value] NVARCHAR(50) '$.value') j   -- maps {"value":"MOBILE"} -> "MOBILE"
        WHERE c.BATCH_ID      = @BatchId
          AND c.RECORD_STATUS = N'INVALID';

        -- ── Phase C: Mark remaining PENDING rows as VALID ────────────────────
        UPDATE CRM_CUSTOMER
        SET RECORD_STATUS = N'VALID',
            UPDATED_DT    = SYSUTCDATETIME()
        WHERE BATCH_ID      = @BatchId
          AND RECORD_STATUS = N'PENDING';

        SET @ValidCnt = @@ROWCOUNT;

        -- Update batch counters
        UPDATE CRM_LOAD_BATCH
        SET BATCH_STATUS      = N'VALIDATED',
            VALID_ROW_COUNT   = @ValidCnt,
            INVALID_ROW_COUNT = @InvalidCnt,
            VALIDATED_DT      = SYSUTCDATETIME()
        WHERE BATCH_ID = @BatchId;

        SET @ErrMsg = NULL;

    END TRY
    BEGIN CATCH
        SET @ErrMsg = ERROR_MESSAGE();
        ROLLBACK;
    END CATCH
END
GO
