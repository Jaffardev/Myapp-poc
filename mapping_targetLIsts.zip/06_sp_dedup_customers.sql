-- ============================================================
-- SP_DEDUP_CUSTOMERS  (SQL Server version)
-- Same four-pass MERGE + MIN() OVER(PARTITION BY) logic.
-- SQL Server MERGE syntax differs slightly from Oracle MERGE.
-- ============================================================
CREATE OR ALTER PROCEDURE SP_DEDUP_CUSTOMERS
    @BatchId  INT,
    @ErrMsg   NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DupCnt INT = 0;
    DECLARE @Tmp    INT;

    BEGIN TRY

        -- ══════════════════════════════════════════════════════
        -- PASS 1: Intra-batch MOBILE dedup
        -- MIN(CUSTOMER_ID) OVER(PARTITION BY MOBILE) is a T-SQL
        -- window function -- identical syntax to Oracle.
        -- ══════════════════════════════════════════════════════
        -- SQL Server MERGE: source is a subquery, not a table alias
        MERGE CRM_CUSTOMER AS tgt
        USING (
            SELECT
                CUSTOMER_ID,
                MIN(CUSTOMER_ID) OVER (PARTITION BY MOBILE) AS MIN_ID
            FROM CRM_CUSTOMER
            WHERE BATCH_ID      = @BatchId
              AND RECORD_STATUS = N'VALID'
              AND MOBILE        IS NOT NULL
        ) AS src
        ON (tgt.CUSTOMER_ID = src.CUSTOMER_ID AND src.CUSTOMER_ID <> src.MIN_ID)
        WHEN MATCHED THEN UPDATE SET
            tgt.RECORD_STATUS   = N'DUPLICATE',
            tgt.DEDUP_MASTER_ID = src.MIN_ID,
            tgt.UPDATED_DT      = SYSUTCDATETIME();

        SET @Tmp    = @@ROWCOUNT;
        SET @DupCnt = @DupCnt + @Tmp;

        -- ══════════════════════════════════════════════════════
        -- PASS 2: Intra-batch EMAIL dedup (survivors from Pass 1)
        -- ══════════════════════════════════════════════════════
        MERGE CRM_CUSTOMER AS tgt
        USING (
            SELECT
                CUSTOMER_ID,
                MIN(CUSTOMER_ID) OVER (PARTITION BY EMAIL) AS MIN_ID
            FROM CRM_CUSTOMER
            WHERE BATCH_ID      = @BatchId
              AND RECORD_STATUS = N'VALID'
              AND EMAIL         IS NOT NULL
        ) AS src
        ON (tgt.CUSTOMER_ID = src.CUSTOMER_ID AND src.CUSTOMER_ID <> src.MIN_ID)
        WHEN MATCHED THEN UPDATE SET
            tgt.RECORD_STATUS   = N'DUPLICATE',
            tgt.DEDUP_MASTER_ID = src.MIN_ID,
            tgt.UPDATED_DT      = SYSUTCDATETIME();

        SET @Tmp    = @@ROWCOUNT;
        SET @DupCnt = @DupCnt + @Tmp;

        -- ══════════════════════════════════════════════════════
        -- PASS 3: Cross-batch MOBILE dedup
        -- Join new-batch VALID rows against ALL prior VALID rows.
        -- SQL Server: same JOIN logic as Oracle, no syntax difference.
        -- ══════════════════════════════════════════════════════
        MERGE CRM_CUSTOMER AS tgt
        USING (
            SELECT
                c_new.CUSTOMER_ID AS NEW_ID,
                c_old.CUSTOMER_ID AS OLD_ID
            FROM CRM_CUSTOMER c_new
            JOIN CRM_CUSTOMER c_old
                ON  c_old.MOBILE        = c_new.MOBILE
                AND c_old.BATCH_ID     <> @BatchId        -- from a different batch
                AND c_old.RECORD_STATUS = N'VALID'
            WHERE c_new.BATCH_ID      = @BatchId
              AND c_new.RECORD_STATUS = N'VALID'
              AND c_new.MOBILE        IS NOT NULL
        ) AS src
        ON (tgt.CUSTOMER_ID = src.NEW_ID)
        WHEN MATCHED THEN UPDATE SET
            tgt.RECORD_STATUS   = N'DUPLICATE',
            tgt.DEDUP_MASTER_ID = src.OLD_ID,
            tgt.UPDATED_DT      = SYSUTCDATETIME();

        SET @Tmp    = @@ROWCOUNT;
        SET @DupCnt = @DupCnt + @Tmp;

        -- ══════════════════════════════════════════════════════
        -- PASS 4: Cross-batch EMAIL dedup
        -- ══════════════════════════════════════════════════════
        MERGE CRM_CUSTOMER AS tgt
        USING (
            SELECT
                c_new.CUSTOMER_ID AS NEW_ID,
                c_old.CUSTOMER_ID AS OLD_ID
            FROM CRM_CUSTOMER c_new
            JOIN CRM_CUSTOMER c_old
                ON  c_old.EMAIL         = c_new.EMAIL
                AND c_old.BATCH_ID     <> @BatchId
                AND c_old.RECORD_STATUS = N'VALID'
            WHERE c_new.BATCH_ID      = @BatchId
              AND c_new.RECORD_STATUS = N'VALID'
              AND c_new.EMAIL         IS NOT NULL
        ) AS src
        ON (tgt.CUSTOMER_ID = src.NEW_ID)
        WHEN MATCHED THEN UPDATE SET
            tgt.RECORD_STATUS   = N'DUPLICATE',
            tgt.DEDUP_MASTER_ID = src.OLD_ID,
            tgt.UPDATED_DT      = SYSUTCDATETIME();

        SET @Tmp    = @@ROWCOUNT;
        SET @DupCnt = @DupCnt + @Tmp;

        -- ── Write dedup error log entries ────────────────────────────────────
        INSERT INTO CRM_ERROR_LOG
            (BATCH_ID, RAW_ROW_ID, ERROR_TYPE, FIELD_CODE, ERROR_MESSAGE, RAW_VALUE)
        SELECT
            c.BATCH_ID,
            c.RAW_ROW_ID,
            CASE WHEN c.MOBILE IS NOT NULL THEN N'DUPLICATE_MOBILE' ELSE N'DUPLICATE_EMAIL' END,
            CASE WHEN c.MOBILE IS NOT NULL THEN N'MOBILE'           ELSE N'EMAIL'           END,
            N'Duplicate of CUSTOMER_ID = ' + CAST(c.DEDUP_MASTER_ID AS NVARCHAR),
            COALESCE(c.MOBILE, c.EMAIL)
        FROM CRM_CUSTOMER c
        WHERE c.BATCH_ID      = @BatchId
          AND c.RECORD_STATUS = N'DUPLICATE';

        -- ── Update batch counters ─────────────────────────────────────────────
        DECLARE @ValidRemaining INT;
        SELECT @ValidRemaining = COUNT(*)
        FROM CRM_CUSTOMER
        WHERE BATCH_ID = @BatchId AND RECORD_STATUS = N'VALID';

        UPDATE CRM_LOAD_BATCH
        SET BATCH_STATUS        = N'DEDUPED',
            DUPLICATE_ROW_COUNT = @DupCnt,
            NET_NEW_ROW_COUNT   = @ValidRemaining
        WHERE BATCH_ID = @BatchId;

        SET @ErrMsg = NULL;

    END TRY
    BEGIN CATCH
        SET @ErrMsg = ERROR_MESSAGE();
        ROLLBACK;
    END CATCH
END
GO
