// ============================================================
// ChecksumService.cs  (unchanged from Oracle version)
// SHA-256 in C# must match T-SQL HASHBYTES('SHA2_256', ...).
//
// T-SQL:
//   LOWER(CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', @text), 2))
//   -- style 2 = hex without 0x prefix
//
// C#:
//   Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(input))).ToLower()
//
// Both produce the same 64-char lowercase hex string for the
// same UTF-8 encoded input. No changes needed to this service.
// ============================================================
using System.Security.Cryptography;
using System.Text;

namespace CrmIngestion.Server.Services;

public class ChecksumService
{
    public string ComputeSha256(string input)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes).ToLower();
        // e.g. "a3f92bc1d4e87f2109c3ab56de0f1234..."
    }

    public bool VerifyMatch(string input, string expected)
        => ComputeSha256(input).Equals(expected, StringComparison.OrdinalIgnoreCase);
}


// ============================================================
// Program.cs changes for SQL Server
// Swap Oracle registrations for SQL Server equivalents.
// Connection string key changes from "OracleDb" to "SqlServerDb".
// ============================================================

/*
 * BEFORE (Oracle):
 *   builder.Services.AddScoped<ICrmRepository, CrmRepository>();
 *   builder.Services.AddScoped<OracleDbContext>();
 *
 * AFTER (SQL Server):
 *   builder.Services.AddScoped<ICrmRepository, CrmSqlRepository>();
 *   builder.Services.AddScoped<SqlServerDbContext>();
 *
 * ExceptionMiddleware change:
 *   BEFORE: catch (OracleSpException ex)
 *   AFTER:  catch (SqlServerSpException ex)
 *
 * appsettings.json change:
 *   BEFORE: "OracleDb": "Data Source=..."
 *   AFTER:  "SqlServerDb": "Server=.;Database=CrmIngestion;
 *                           Integrated Security=True;
 *                           TrustServerCertificate=True;"
 */


// ============================================================
// ExceptionMiddleware.cs  (SQL Server version)
// Catches SqlServerSpException instead of OracleSpException.
// Everything else is identical.
// ============================================================
namespace CrmIngestion.Server.Middleware;

public class SqlExceptionMiddleware(RequestDelegate next, ILogger<SqlExceptionMiddleware> log)
{
    public async Task InvokeAsync(HttpContext ctx)
    {
        try
        {
            await next(ctx);
        }
        catch (SqlServerSpException ex)
        {
            // T-SQL RAISERROR / THROW surfaced as HTTP 400
            // Message contains the exact text from the SP, e.g.:
            //   "CHECKSUM MISMATCH for query 42. Stored: a3f9... Computed: 9d7e..."
            log.LogWarning("SP error [{SP}]: {Msg}", ex.SpName, ex.Message);
            ctx.Response.StatusCode = 400;
            await ctx.Response.WriteAsync(ex.Message);
        }
        catch (OperationCanceledException)
        {
            // Browser disconnected — ignore
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Unhandled exception");
            ctx.Response.StatusCode = 500;
            await ctx.Response.WriteAsync("Internal server error");
        }
    }
}


// ============================================================
// appsettings.json snippet for SQL Server
// ============================================================
/*
{
  "ConnectionStrings": {
    "SqlServerDb": "Server=YOUR_SERVER;Database=CrmIngestion;Integrated Security=True;TrustServerCertificate=True;"
  },
  "Jwt": {
    "Key":      "YourSuperSecretKey_32CharMin!@#$",
    "Issuer":   "CrmIngestionServer",
    "Audience": "CrmIngestionClient",
    "ExpiryHours": 8
  },
  "SqlServer": {
    "CommandTimeoutSeconds":     3600,
    "BulkCommandTimeoutSeconds": 7200,
    "MaxDop":                    8
  },
  "Serilog": {
    "MinimumLevel": "Information",
    "WriteTo": [
      { "Name": "Console" },
      { "Name": "File", "Args": { "path": "logs/crm-.log", "rollingInterval": "Day" } }
    ]
  }
}
*/
