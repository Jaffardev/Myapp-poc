// ============================================================
// CrmSqlRepository.cs
// SQL Server implementation of ICrmRepository
// Replaces CrmRepository.cs (Oracle / ODP.NET)
// Key differences:
//   OracleException     -> SqlException
//   OracleDbType        -> SqlDbType
//   OracleDecimal       -> no special type needed
//   RAISE_APPLICATION_ERROR(-20011) -> RAISERROR / THROW in T-SQL
//     caught as SqlException with Number > 50000
// ============================================================
using CrmIngestion.Shared.DTOs;
using CrmIngestion.Shared.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace CrmIngestion.Server.SqlServer;

public class CrmSqlRepository : ICrmRepository
{
    private readonly SqlServerDbContext _db;
    private readonly ILogger<CrmSqlRepository> _log;

    public CrmSqlRepository(SqlServerDbContext db, ILogger<CrmSqlRepository> log)
    {
        _db  = db;
        _log = log;
    }

    // ──────────────────────────────────────────────────────────
    // ExecuteApprovedQueryAsync
    // Calls SP_EXECUTE_APPROVED_QUERY via parameterised command.
    // SqlException wraps T-SQL RAISERROR / THROW errors.
    // ──────────────────────────────────────────────────────────
    public async Task<ExecuteQueryResult> ExecuteApprovedQueryAsync(
        int batchId,
        int queryConfigId,
        string user,
        CancellationToken ct)
    {
        await using var conn = _db.CreateConnection();
        await conn.OpenAsync(ct);

        await using var cmd = _db.CreateSpCommand(conn, "SP_EXECUTE_APPROVED_QUERY");

        // IN parameters
        cmd.Parameters.AddIn("@BatchId",       batchId,       SqlDbType.Int);
        cmd.Parameters.AddIn("@QueryConfigId", queryConfigId, SqlDbType.Int);
        cmd.Parameters.AddIn("@InitiatedBy",   user,          SqlDbType.NVarChar);

        // OUT parameters
        cmd.Parameters.AddOut("@RowsInserted", SqlDbType.Int);
        cmd.Parameters.AddOut("@ErrorMessage", SqlDbType.NVarChar, size: -1);

        try
        {
            await cmd.ExecuteNonQueryAsync(ct);

            var errorMsg = cmd.Parameters.GetOutValue<string>("@ErrorMessage");
            if (!string.IsNullOrEmpty(errorMsg))
                throw new SqlServerSpException("SP_EXECUTE_APPROVED_QUERY", errorMsg);

            return new ExecuteQueryResult
            {
                RowsInserted = cmd.Parameters.GetOutValue<int>("@RowsInserted")
            };
        }
        catch (SqlException ex)
        {
            // T-SQL RAISERROR with severity >= 11 surfaces as SqlException.
            // THROW in T-SQL produces SqlException with the message we wrote.
            // SqlException.Number for user RAISERROR is the error number passed.
            _log.LogError(ex,
                "SqlException in SP_EXECUTE_APPROVED_QUERY. Number={N} Message={M}",
                ex.Number, ex.Message);

            throw new SqlServerSpException("SP_EXECUTE_APPROVED_QUERY",
                $"SQL-{ex.Number}: {ex.Message}");
        }
    }

    // ──────────────────────────────────────────────────────────
    // SubmitIngestionJobAsync
    // Calls SP_SUBMIT_INGESTION_JOB which creates a SQL Agent job.
    // ──────────────────────────────────────────────────────────
    public async Task<SubmitJobResult> SubmitIngestionJobAsync(
        int batchId,
        CancellationToken ct)
    {
        await using var conn = _db.CreateConnection();
        await conn.OpenAsync(ct);

        await using var cmd = _db.CreateSpCommand(conn, "SP_SUBMIT_INGESTION_JOB");

        cmd.Parameters.AddIn("@BatchId",  batchId, SqlDbType.Int);
        cmd.Parameters.AddOut("@JobName", SqlDbType.NVarChar, size: 200);
        cmd.Parameters.AddOut("@ErrorMsg", SqlDbType.NVarChar, size: -1);

        try
        {
            await cmd.ExecuteNonQueryAsync(ct);

            var err = cmd.Parameters.GetOutValue<string>("@ErrorMsg");
            if (!string.IsNullOrEmpty(err))
                throw new SqlServerSpException("SP_SUBMIT_INGESTION_JOB", err);

            return new SubmitJobResult
            {
                JobName = cmd.Parameters.GetOutValue<string>("@JobName")
            };
        }
        catch (SqlException ex)
        {
            throw new SqlServerSpException("SP_SUBMIT_INGESTION_JOB",
                $"SQL-{ex.Number}: {ex.Message}");
        }
    }

    // ──────────────────────────────────────────────────────────
    // CreateBatchAsync — INSERT into CRM_LOAD_BATCH
    // Uses OUTPUT INSERTED.BATCH_ID instead of Oracle RETURNING
    // ──────────────────────────────────────────────────────────
    public async Task<CreateBatchResponse> CreateBatchAsync(
        CreateBatchRequest req,
        CancellationToken ct)
    {
        await using var conn = _db.CreateConnection();
        await conn.OpenAsync(ct);

        const string sql = @"
            INSERT INTO CRM_LOAD_BATCH (SOURCE_ID, INITIATED_BY)
            OUTPUT INSERTED.BATCH_ID        -- replaces Oracle RETURNING ... INTO
            VALUES (@SourceId, @InitiatedBy);";

        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddIn("@SourceId",    req.SourceId,    SqlDbType.Int);
        cmd.Parameters.AddIn("@InitiatedBy", req.InitiatedBy, SqlDbType.NVarChar);

        var batchId = (int)(await cmd.ExecuteScalarAsync(ct))!;
        return new CreateBatchResponse { BatchId = batchId };
    }

    // ──────────────────────────────────────────────────────────
    // GetBatchAsync — simple SELECT by BATCH_ID
    // ──────────────────────────────────────────────────────────
    public async Task<LoadBatch?> GetBatchAsync(int batchId, CancellationToken ct)
    {
        await using var conn = _db.CreateConnection();
        await conn.OpenAsync(ct);

        const string sql = @"
            SELECT BATCH_ID, SOURCE_ID, QUERY_CONFIG_ID, BATCH_STATUS,
                   JOB_NAME, RAW_ROW_COUNT, MAPPED_ROW_COUNT,
                   VALID_ROW_COUNT, INVALID_ROW_COUNT,
                   DUPLICATE_ROW_COUNT, NET_NEW_ROW_COUNT,
                   INITIATED_BY, INITIATED_DT,
                   LANDED_DT, MAPPED_DT, VALIDATED_DT, COMPLETED_DT,
                   LAST_ERROR, RESTART_COUNT
            FROM CRM_LOAD_BATCH
            WHERE BATCH_ID = @BatchId;";

        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddIn("@BatchId", batchId, SqlDbType.Int);

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct)) return null;

        return MapBatch(reader);
    }

    // ──────────────────────────────────────────────────────────
    // SubmitQueryForApprovalAsync
    // Note: HASHBYTES SHA-256 in T-SQL returns VARBINARY(32).
    // C# SHA256.HashData().ToHexString().ToLower() matches
    // LOWER(CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', text), 2))
    // ──────────────────────────────────────────────────────────
    public async Task SubmitQueryForApprovalAsync(
        int queryConfigId,
        string submittedBy,
        string checksum,           // pre-computed by ChecksumService in C#
        CancellationToken ct)
    {
        await using var conn = _db.CreateConnection();
        await conn.OpenAsync(ct);

        // Single transaction: update query + insert audit log
        await using var tx = conn.BeginTransaction();

        const string updateSql = @"
            UPDATE CRM_QUERY_CONFIG
            SET STATUS       = N'PENDING_APPROVAL',
                SUBMITTED_BY = @By,
                SUBMITTED_DT = SYSUTCDATETIME(),
                CHECKSUM     = @Checksum
            WHERE QUERY_CONFIG_ID = @Id
              AND STATUS IN (N'DRAFT', N'REJECTED');

            IF @@ROWCOUNT = 0
                THROW 50001, 'Query not in DRAFT or REJECTED status', 1;";

        const string logSql = @"
            INSERT INTO CRM_QUERY_APPROVAL_LOG (QUERY_CONFIG_ID, ACTION, ACTION_BY)
            VALUES (@Id, N'SUBMITTED', @By);";

        await using var cmdUpd = new SqlCommand(updateSql, conn, tx);
        cmdUpd.Parameters.AddIn("@Id",       queryConfigId, SqlDbType.Int);
        cmdUpd.Parameters.AddIn("@By",       submittedBy,   SqlDbType.NVarChar);
        cmdUpd.Parameters.AddIn("@Checksum", checksum,      SqlDbType.NVarChar);
        await cmdUpd.ExecuteNonQueryAsync(ct);

        await using var cmdLog = new SqlCommand(logSql, conn, tx);
        cmdLog.Parameters.AddIn("@Id", queryConfigId, SqlDbType.Int);
        cmdLog.Parameters.AddIn("@By", submittedBy,   SqlDbType.NVarChar);
        await cmdLog.ExecuteNonQueryAsync(ct);

        await tx.CommitAsync(ct);
    }

    // ──────────────────────────────────────────────────────────
    // Mapper helpers
    // ──────────────────────────────────────────────────────────
    private static LoadBatch MapBatch(SqlDataReader r) => new()
    {
        BatchId            = r.GetInt32(r.GetOrdinal("BATCH_ID")),
        SourceId           = r.GetInt32(r.GetOrdinal("SOURCE_ID")),
        BatchStatus        = r.GetString(r.GetOrdinal("BATCH_STATUS")),
        JobName            = r.IsDBNull(r.GetOrdinal("JOB_NAME")) ? null
                             : r.GetString(r.GetOrdinal("JOB_NAME")),
        RawRowCount        = r.GetInt32(r.GetOrdinal("RAW_ROW_COUNT")),
        ValidRowCount      = r.GetInt32(r.GetOrdinal("VALID_ROW_COUNT")),
        InvalidRowCount    = r.GetInt32(r.GetOrdinal("INVALID_ROW_COUNT")),
        DuplicateRowCount  = r.GetInt32(r.GetOrdinal("DUPLICATE_ROW_COUNT")),
        NetNewRowCount     = r.GetInt32(r.GetOrdinal("NET_NEW_ROW_COUNT")),
        LandedDt           = r.IsDBNull(r.GetOrdinal("LANDED_DT")) ? null
                             : r.GetDateTime(r.GetOrdinal("LANDED_DT")),
        CompletedDt        = r.IsDBNull(r.GetOrdinal("COMPLETED_DT")) ? null
                             : r.GetDateTime(r.GetOrdinal("COMPLETED_DT")),
    };
}

// ──────────────────────────────────────────────────────────────
// SqlServerSpException
// Mirrors OracleSpException — thrown when a T-SQL SP raises
// an application error (RAISERROR / THROW with custom message).
// ExceptionMiddleware catches this and returns HTTP 400.
// ──────────────────────────────────────────────────────────────
public class SqlServerSpException : Exception
{
    public string SpName { get; }

    public SqlServerSpException(string spName, string message)
        : base(message) => SpName = spName;
}
