// ============================================================
// SqlServerDbContext.cs
// Replaces OracleDbContext — uses Microsoft.Data.SqlClient
// ============================================================
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace CrmIngestion.Server.SqlServer;

public class SqlServerDbContext
{
    private readonly string _connectionString;

    public SqlServerDbContext(IConfiguration cfg)
    {
        _connectionString = cfg.GetConnectionString("SqlServerDb")
            ?? throw new InvalidOperationException("SqlServerDb connection string not configured.");
    }

    /// <summary>Creates a pooled SqlConnection (not yet opened).</summary>
    public SqlConnection CreateConnection() => new(_connectionString);

    /// <summary>Builds a SqlCommand targeting a stored procedure.</summary>
    public SqlCommand CreateSpCommand(SqlConnection conn, string spName)
        => new(spName, conn)
        {
            CommandType    = CommandType.StoredProcedure,
            CommandTimeout = 3600  // 1 hour for bulk operations
        };
}

// ============================================================
// SqlParameterExtensions.cs
// Fluent helpers for SqlParameterCollection
// Mirrors OracleParameterExtensions from the Oracle version
// ============================================================
public static class SqlParameterExtensions
{
    public static void AddIn(
        this SqlParameterCollection p,
        string name,
        object? value,
        SqlDbType type = SqlDbType.Int)
    {
        p.Add(new SqlParameter
        {
            ParameterName = name,
            Value         = value ?? DBNull.Value,
            SqlDbType     = type,
            Direction     = ParameterDirection.Input
        });
    }

    public static void AddOut(
        this SqlParameterCollection p,
        string name,
        SqlDbType type,
        int size = -1)
    {
        var param = new SqlParameter
        {
            ParameterName = name,
            SqlDbType     = type,
            Direction     = ParameterDirection.Output
        };
        if (size > 0) param.Size = size;
        p.Add(param);
    }

    /// <summary>Reads a typed OUTPUT parameter value.</summary>
    public static T GetOutValue<T>(this SqlParameterCollection p, string name)
    {
        var value = p[name].Value;
        if (value is DBNull || value is null) return default!;
        return (T)Convert.ChangeType(value, typeof(T));
    }
}
